import React from 'react';
import {
  ShoppingBag,
  Utensils,
  Home,
  Zap,
  HeartPulse,
  GraduationCap,
  Bus,
  Gift,
  Film,
  Dumbbell,
  Smartphone,
  ShieldCheck,
  MoreHorizontal,
  Briefcase,
  TrendingUp,
  DollarSign,
  Wallet,
  RefreshCw,
  Repeat,
  Plane,
  Car,
  Fuel,
  Coffee,
  Tag,
  BookOpen,
  Wifi,
  Package,
  Layers,
  Sparkles,
  HelpCircle,
} from 'lucide-react';

export const ICON_MAP: Record<string, React.ComponentType<{ className?: string; style?: React.CSSProperties }>> = {
  ShoppingBag,
  Utensils,
  Home,
  Zap,
  HeartPulse,
  GraduationCap,
  Bus,
  Gift,
  Film,
  Dumbbell,
  Smartphone,
  ShieldCheck,
  MoreHorizontal,
  Briefcase,
  TrendingUp,
  DollarSign,
  Wallet,
  RefreshCw,
  Repeat,
  Plane,
  Car,
  Fuel,
  Coffee,
  Tag,
  BookOpen,
  Wifi,
  Package,
  Layers,
  Sparkles,
};

export const AVAILABLE_CATEGORY_ICONS = Object.keys(ICON_MAP);

export const renderCategoryIcon = (
  iconName?: string,
  classNameOrColor?: string,
  optionalColor?: string
): React.ReactNode => {
  let className = 'w-4 h-4';
  let color: string | undefined = undefined;

  if (optionalColor) {
    className = classNameOrColor || 'w-4 h-4';
    color = optionalColor;
  } else if (classNameOrColor) {
    if (classNameOrColor.startsWith('#') || classNameOrColor.startsWith('rgb')) {
      color = classNameOrColor;
    } else {
      className = classNameOrColor;
    }
  }

  const IconComponent = (iconName && ICON_MAP[iconName]) || HelpCircle;

  return <IconComponent className={className} style={color ? { color } : undefined} />;
};
