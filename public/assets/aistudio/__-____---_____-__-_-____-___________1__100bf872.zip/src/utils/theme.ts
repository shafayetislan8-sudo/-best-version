export type AccentColor = 'blue' | 'emerald' | 'indigo' | 'rose' | 'amber' | 'amoled';

export interface AccentThemeOption {
  id: AccentColor;
  labelBn: string;
  labelEn: string;
  primaryColor: string;
  hoverColor: string;
  lightBg: string;
  darkBg: string;
  textColor: string;
  activeBorder: string;
  previewGradient: string;
}

export const ACCENT_THEMES: AccentThemeOption[] = [
  {
    id: 'blue',
    labelBn: 'রয়্যাল ব্লু',
    labelEn: 'Royal Blue',
    primaryColor: '#2563eb',
    hoverColor: '#1d4ed8',
    lightBg: 'bg-blue-50',
    darkBg: 'dark:bg-blue-950/60',
    textColor: 'text-blue-600 dark:text-blue-400',
    activeBorder: 'border-blue-500',
    previewGradient: 'from-blue-600 to-indigo-600',
  },
  {
    id: 'emerald',
    labelBn: 'পান্না সবুজ (ওয়েলথ)',
    labelEn: 'Emerald Wealth',
    primaryColor: '#059669',
    hoverColor: '#047857',
    lightBg: 'bg-emerald-50',
    darkBg: 'dark:bg-emerald-950/60',
    textColor: 'text-emerald-600 dark:text-emerald-400',
    activeBorder: 'border-emerald-500',
    previewGradient: 'from-emerald-600 to-teal-600',
  },
  {
    id: 'indigo',
    labelBn: 'মডার্ন ইন্ডিগো',
    labelEn: 'Modern Indigo',
    primaryColor: '#6366f1',
    hoverColor: '#4f46e5',
    lightBg: 'bg-indigo-50',
    darkBg: 'dark:bg-indigo-950/60',
    textColor: 'text-indigo-600 dark:text-indigo-400',
    activeBorder: 'border-indigo-500',
    previewGradient: 'from-indigo-600 to-purple-600',
  },
  {
    id: 'rose',
    labelBn: 'সানসেট কোরাল',
    labelEn: 'Sunset Rose',
    primaryColor: '#f43f5e',
    hoverColor: '#e11d48',
    lightBg: 'bg-rose-50',
    darkBg: 'dark:bg-rose-950/60',
    textColor: 'text-rose-600 dark:text-rose-400',
    activeBorder: 'border-rose-500',
    previewGradient: 'from-rose-500 to-pink-600',
  },
  {
    id: 'amber',
    labelBn: 'গোল্ডেন অ্যাম্বার',
    labelEn: 'Golden Amber',
    primaryColor: '#d97706',
    hoverColor: '#b45309',
    lightBg: 'bg-amber-50',
    darkBg: 'dark:bg-amber-950/60',
    textColor: 'text-amber-600 dark:text-amber-400',
    activeBorder: 'border-amber-500',
    previewGradient: 'from-amber-500 to-orange-600',
  },
  {
    id: 'amoled',
    labelBn: 'পিওর অ্যামোলেড',
    labelEn: 'Pure AMOLED',
    primaryColor: '#10b981',
    hoverColor: '#059669',
    lightBg: 'bg-slate-100',
    darkBg: 'dark:bg-zinc-900',
    textColor: 'text-emerald-500 dark:text-emerald-400',
    activeBorder: 'border-emerald-500',
    previewGradient: 'from-zinc-900 via-black to-emerald-950',
  },
];

export function getAccentTheme(accentId?: string): AccentThemeOption {
  return ACCENT_THEMES.find((t) => t.id === accentId) || ACCENT_THEMES[0];
}
