import React, { useState } from 'react';
import {
  Cloud,
  X,
  CheckCircle2,
  AlertCircle,
  Database,
  Lock,
  RefreshCw,
  ShieldCheck,
  Smartphone,
  LogOut,
  Sparkles,
  Copy,
  ExternalLink,
  Wifi,
  WifiOff,
  Zap,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { toBanglaNumber } from '../utils/formatters';

export const FirebaseModal: React.FC = () => {
  const {
    isFirebaseModalOpen,
    setIsFirebaseModalOpen,
    currentUser,
    isAuthLoading,
    isCloudSyncing,
    lastCloudSyncTime,
    cloudSyncStatus,
    isOnline,
    signInWithGoogle,
    signOutUser,
    manualCloudSync,
    transactions,
    persons,
    accounts,
    budgets,
    savings,
    notes,
    settings,
  } = useApp();

  const isEn = settings.language === 'en';
  const [loginError, setLoginError] = useState<string | null>(null);
  const [unauthorizedDomain, setUnauthorizedDomain] = useState<string | null>(null);
  const [copiedDomain, setCopiedDomain] = useState(false);
  const [isOfflineAcknowledged, setIsOfflineAcknowledged] = useState(false);
  const [successToast, setSuccessToast] = useState<string | null>(null);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  if (!isFirebaseModalOpen) return null;

  const handleGoogleLogin = async () => {
    setLoginError(null);
    setUnauthorizedDomain(null);
    try {
      await signInWithGoogle();
      setSuccessToast(
        isEn
          ? 'Google login & Cloud Sync connected successfully!'
          : 'গুগল লগইন ও ক্লাউড সিঙ্ক সফলভাবে সম্পন্ন হয়েছে!'
      );
      setTimeout(() => setSuccessToast(null), 4000);
    } catch (err: any) {
      if (err?.code === 'auth/unauthorized-domain' || err?.message?.includes('unauthorized-domain')) {
        const domain = err?.domain || (typeof window !== 'undefined' ? window.location.hostname : '');
        setUnauthorizedDomain(domain);
      } else {
        console.error(err);
        setLoginError(
          err?.message ||
            (isEn
              ? 'Login could not be completed. Please try again.'
              : 'লগইন সম্পন্ন করা যায়নি। অনুগ্রহ করে আবার চেষ্টা করুন।')
        );
      }
    }
  };

  const handleManualSync = async () => {
    setLoginError(null);
    try {
      await manualCloudSync();
      setSuccessToast(
        isEn
          ? 'All data synchronized and backed up to Firebase cloud!'
          : 'সমস্ত ডাটা ক্লাউডে সফলভাবে সিঙ্ক ও ব্যাকআপ করা হয়েছে!'
      );
      setTimeout(() => setSuccessToast(null), 4000);
    } catch (err: any) {
      console.error(err);
      setLoginError(
        isEn
          ? 'Sync failed. Please verify your internet connection.'
          : 'সিঙ্ক সম্পন্ন করতে সমস্যা হয়েছে। ইন্টারনেট সংযোগ চেক করুন।'
      );
    }
  };

  const handleLogout = async () => {
    await signOutUser();
    setShowLogoutConfirm(false);
    setSuccessToast(
      isEn
        ? 'Signed out. The app will now store data locally in offline mode.'
        : 'লগআউট সফল হয়েছে। অ্যাপটি বর্তমানে স্থানীয় অফলাইন মোডে চলবে।'
    );
    setTimeout(() => setSuccessToast(null), 4000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
      <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-2xl shadow-2xl border border-gray-100 dark:border-slate-800 p-5 space-y-4 max-h-[88vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400 flex items-center justify-center">
              <Cloud className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-800 dark:text-white leading-tight">
                {isEn ? 'Firebase Cloud Sync & Backup' : 'অনলাইন ক্লাউড ডাটাবেস ও অটো-সিঙ্ক'}
              </h3>
              <p className="text-[11px] text-slate-500">
                {isEn ? '100% Free Persistent Storage' : 'Firebase Firestore Cloud Sync (আজীবন ফ্রি)'}
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsFirebaseModalOpen(false)}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Success Toast */}
        {successToast && (
          <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-800 dark:text-emerald-300 flex items-center gap-2 font-medium">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <span>{successToast}</span>
          </div>
        )}

        {/* Domain Authorization Notice */}
        {unauthorizedDomain && (
          <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-700/70 space-y-3 animate-in fade-in">
            <div className="flex items-start gap-2.5">
              <AlertCircle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <h4 className="text-xs font-bold text-amber-900 dark:text-amber-200">
                  {isEn ? 'Firebase Domain Authorization Required' : 'Firebase ডোমেন অনুমোদন প্রয়োজন'}
                </h4>
                <p className="text-[11px] text-amber-800 dark:text-amber-300 leading-relaxed">
                  {isEn
                    ? 'To use Google Sign-In on this preview environment, this domain must be added to your Firebase authorized domains list.'
                    : 'গুগল সাইন-ইন চালু করতে এই ক্লাউড প্রিভিউ ডোমেনটি আপনার Firebase কনসোলে অনুমোদিত (Authorized domain) তালিকায় যোগ করতে হবে।'}
                </p>
              </div>
            </div>

            {/* Domain Copy Box */}
            <div className="flex items-center justify-between p-2.5 bg-white dark:bg-slate-900 rounded-xl border border-amber-200 dark:border-amber-800 text-xs shadow-xs">
              <code className="text-xs font-mono font-bold text-slate-800 dark:text-slate-200 break-all select-all">
                {unauthorizedDomain}
              </code>
              <button
                type="button"
                onClick={() => {
                  navigator.clipboard.writeText(unauthorizedDomain);
                  setCopiedDomain(true);
                  setTimeout(() => setCopiedDomain(false), 2500);
                }}
                className="ml-2 px-2.5 py-1 text-[11px] font-bold bg-amber-100 hover:bg-amber-200 dark:bg-amber-900 dark:hover:bg-amber-800 text-amber-900 dark:text-amber-200 rounded-lg shrink-0 flex items-center gap-1 transition-colors cursor-pointer"
              >
                {copiedDomain ? (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                    <span>{isEn ? 'Copied!' : 'কপি হয়েছে!'}</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>{isEn ? 'Copy' : 'কপি করুন'}</span>
                  </>
                )}
              </button>
            </div>

            {/* Step-by-step guidance */}
            <div className="text-[11px] text-amber-900/90 dark:text-amber-300 space-y-1 bg-amber-100/60 dark:bg-amber-900/30 p-2.5 rounded-xl">
              <p className="font-bold flex items-center gap-1">
                {isEn ? 'Quick 3 Steps to Authorize:' : 'সহজ ৩টি ধাপে যুক্ত করার নিয়ম:'}
              </p>
              <ol className="list-decimal list-inside space-y-0.5 text-[10.5px]">
                <li>{isEn ? 'Open Firebase Console > Authentication > Settings' : 'Firebase Console > Authentication > Settings-এ যান'}</li>
                <li>{isEn ? 'Scroll down to "Authorized domains" and click "Add domain"' : '"Authorized domains" সেকশনে "Add domain" বাটনে চাপুন'}</li>
                <li>{isEn ? 'Paste the copied domain and click Save' : 'কপি করা ডোমেনটি পেস্ট করে Save করুন'}</li>
              </ol>
            </div>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row items-center gap-2 pt-1">
              <a
                href={`https://console.firebase.google.com/project/coherent-cistern-n2sm5/authentication/settings`}
                target="_blank"
                rel="noreferrer"
                className="w-full sm:flex-1 py-2 px-3 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center justify-center gap-1.5"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>{isEn ? 'Open Firebase Settings' : 'Firebase সেটিংস খুলুন'}</span>
              </a>
              <button
                type="button"
                onClick={handleGoogleLogin}
                className="w-full sm:flex-1 py-2 px-3 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-800 dark:text-white border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>{isEn ? 'Retry Sign-In' : 'পুনরায় চেষ্টা করুন'}</span>
              </button>
            </div>

            {/* Offline reassurance */}
            <div className="pt-1 text-center">
              <button
                type="button"
                onClick={() => {
                  setUnauthorizedDomain(null);
                  setIsOfflineAcknowledged(true);
                }}
                className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 underline cursor-pointer"
              >
                {isEn
                  ? 'Continue in Offline Mode (100% features work without login)'
                  : 'অফলাইন মোডে চালিয়ে যান (লগইন ছাড়াও সব ফিচার সম্পূর্ণ কার্যকর)'}
              </button>
            </div>
          </div>
        )}

        {/* Offline Acknowledged Notice */}
        {isOfflineAcknowledged && !currentUser && !unauthorizedDomain && (
          <div className="p-3 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 text-xs text-blue-900 dark:text-blue-200 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
            <span>
              {isEn
                ? 'Offline Mode Active: All entries, balances & reports are safely saved in your browser storage.'
                : 'অফলাইন মোড সক্রিয়: সমস্ত হিসাব, খতিয়ান ও রিপোর্ট আপনার ডিভাইসে সংরক্ষিত থাকবে।'}
            </span>
          </div>
        )}

        {/* Error Toast */}
        {loginError && !unauthorizedDomain && (
          <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-xs text-rose-800 dark:text-rose-300 flex items-center gap-2 font-medium">
            <AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0" />
            <span>{loginError}</span>
          </div>
        )}

        {/* Cloud Status Banner */}
        {currentUser ? (
          <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-950/40 dark:to-teal-950/40 border border-emerald-200 dark:border-emerald-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {currentUser.photoURL ? (
                  <img
                    src={currentUser.photoURL}
                    alt={currentUser.displayName || 'User'}
                    className="w-11 h-11 rounded-full ring-2 ring-emerald-500 shadow-sm"
                  />
                ) : (
                  <div className="w-11 h-11 rounded-full bg-emerald-600 text-white font-bold text-base flex items-center justify-center ring-2 ring-emerald-500 shadow-sm">
                    {currentUser.displayName ? currentUser.displayName.charAt(0) : 'U'}
                  </div>
                )}
                <div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                    {currentUser.displayName || settings.userName}
                    <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  </h4>
                  <p className="text-xs text-slate-600 dark:text-slate-300">{currentUser.email}</p>
                </div>
              </div>

              <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-600 text-white flex items-center gap-1 shadow-xs">
                <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
                {isEn ? 'Sync Active' : 'অনলাইন সিঙ্ক সক্রিয়'}
              </span>
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-600 dark:text-slate-400 pt-1 border-t border-emerald-200/60 dark:border-emerald-800/60">
              <span>
                {isEn ? 'Last Synced' : 'সর্বশেষ সিঙ্ক'}:{' '}
                <strong className="text-slate-800 dark:text-slate-200">
                  {lastCloudSyncTime || (isEn ? 'Automatic (Real-time)' : 'স্বয়ংক্রিয় (রিয়েল-টাইম)')}
                </strong>
              </span>
              <span className="text-emerald-700 dark:text-emerald-400 font-medium">
                {isEn ? '100% Free & Secure' : 'ফ্রি ক্লাউড স্টোরেজ ১০০% সুরক্ষিত'}
              </span>
            </div>

            {/* Logout confirmation or action buttons */}
            {!showLogoutConfirm ? (
              <div className="flex items-center gap-2 pt-1">
                <button
                  onClick={handleManualSync}
                  disabled={isCloudSyncing}
                  className="flex-1 py-2 px-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center justify-center gap-1.5"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isCloudSyncing ? 'animate-spin' : ''}`} />
                  {isCloudSyncing
                    ? isEn
                      ? 'Syncing...'
                      : 'সিঙ্ক হচ্ছে...'
                    : isEn
                    ? 'Sync Cloud Now'
                    : 'এখনই সিঙ্ক করুন'}
                </button>
                <button
                  onClick={() => setShowLogoutConfirm(true)}
                  className="py-2 px-3 bg-slate-200 dark:bg-slate-800 hover:bg-rose-100 hover:text-rose-600 dark:hover:bg-rose-950 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold transition-colors flex items-center gap-1"
                  title={isEn ? 'Log out' : 'লগআউট'}
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>{isEn ? 'Log out' : 'লগআউট'}</span>
                </button>
              </div>
            ) : (
              <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-center space-y-2">
                <p className="text-xs font-bold text-rose-700 dark:text-rose-300">
                  {isEn
                    ? 'Are you sure you want to log out from cloud backup?'
                    : 'আপনি কি নিশ্চিত যে ক্লাউড অ্যাকাউন্ট থেকে লগআউট করতে চান?'}
                </p>
                <div className="flex justify-center gap-2">
                  <button
                    onClick={handleLogout}
                    className="px-4 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold"
                  >
                    {isEn ? 'Yes, Log out' : 'হ্যাঁ, লগআউট'}
                  </button>
                  <button
                    onClick={() => setShowLogoutConfirm(false)}
                    className="px-4 py-1.5 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-lg text-xs"
                  >
                    {isEn ? 'Cancel' : 'বাতিল'}
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="p-4 rounded-2xl bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950/40 dark:to-indigo-950/40 border border-blue-200 dark:border-blue-800 space-y-3">
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-md">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                  {isEn ? 'Enable Free Cloud Backup & Sync' : 'ফ্রি ক্লাউড ব্যাকআপ সক্রিয় করুন'}
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5 leading-relaxed">
                  {isEn
                    ? 'Even if you uninstall the app or switch devices, all your income, expense, and debts are safely restored automatically by signing in!'
                    : 'অ্যাপ আনইনস্টল করলেও আপনার কোনো তথ্য হারাবে না। যেকোনো ফোন বা কম্পিউটার থেকে লগইন করলেই সমস্ত হিসাব ফিরে পাবেন!'}
                </p>
              </div>
            </div>

            {/* Google Login Button */}
            <button
              onClick={handleGoogleLogin}
              disabled={isCloudSyncing}
              className="w-full py-2.5 px-4 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-white rounded-xl text-xs font-bold shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.8-2.4 3.66v3.04h3.88c2.27-2.09 3.66-5.17 3.66-9.14z"
                />
                <path
                  fill="#34A853"
                  d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.04c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.13C3.27 21.43 7.33 24 12 24z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.28 14.28c-.25-.72-.38-1.49-.38-2.28s.13-1.56.38-2.28V6.59H1.25C.45 8.18 0 9.98 0 12s.45 3.82 1.25 5.41l4.03-3.13z"
                />
                <path
                  fill="#EA4335"
                  d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.27 2.57 1.25 6.59l4.03 3.13c.95-2.83 3.6-4.97 6.72-4.97z"
                />
              </svg>
              <span>
                {isCloudSyncing
                  ? isEn
                    ? 'Connecting to Google...'
                    : 'সংযুক্ত হচ্ছে...'
                  : isEn
                  ? 'Sign in with Google (Free Cloud Backup)'
                  : 'Google দিয়ে সাইন ইন ও ফ্রি ব্যাকআপ চালু করুন'}
              </span>
            </button>
          </div>
        )}

        {/* Automatic Sync & Offline Guarantee Info Card */}
        <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700/80 space-y-2.5">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
              {isEn ? 'Automatic Sync & Offline Guarantee' : 'স্বয়ংক্রিয় সিঙ্ক ও অফলাইন নিশ্চয়তা'}
            </h4>
            <span
              className={`px-2 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1 ${
                isOnline
                  ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
                  : 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300'
              }`}
            >
              {isOnline ? (
                <>
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  {isEn ? 'Network: Online' : 'ইন্টারনেট: অনলাইন'}
                </>
              ) : (
                <>
                  <WifiOff className="w-3 h-3 text-amber-600 dark:text-amber-400" />
                  {isEn ? 'Network: Offline' : 'ইন্টারনেট: অফলাইন'}
                </>
              )}
            </span>
          </div>

          <div className="space-y-2 text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
            <div className="flex items-start gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
              <p>
                <strong className="text-slate-800 dark:text-slate-200">
                  {isEn ? 'Automatic Real-time Sync:' : 'স্বয়ংক্রিয় সিঙ্ক:'}
                </strong>{' '}
                {isEn
                  ? 'Once signed in with Google, every transaction, debt, budget, or mess record is synced in real-time to the cloud without needing to press any button.'
                  : 'Google দিয়ে একবার লগইন করার পর প্রতিবার আয়-ব্যয় বা বাকি খাতা এন্ট্রি করলেই কোনো বাটন না চেপেই সাথে সাথে ক্লাউডে ব্যাকআপ ও সিঙ্ক হয়ে যায়।'}
              </p>
            </div>

            <div className="flex items-start gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-blue-500 shrink-0 mt-0.5" />
              <p>
                <strong className="text-slate-800 dark:text-slate-200">
                  {isEn ? '100% Offline-First Protection:' : 'অফলাইনে শতভাগ কার্যকর:'}
                </strong>{' '}
                {isEn
                  ? 'No internet? No worries! All calculations, records, and reports work seamlessly offline. Everything is saved locally on your device and automatically syncs to the cloud as soon as you reconnect.'
                  : 'ইন্টারনেট বা নেটওয়ার্ক না থাকলেও কোনো সমস্যা নেই! সমস্ত হিসাব ও রিপোর্ট স্বাভাবিকভাবেই চলবে। সবকিছু আপনার ফোনের মেমরিতে সুরক্ষিত থাকবে এবং ইন্টারনেট পাওয়ামাত্রই স্বয়ংক্রিয়ভাবে ক্লাউডে সিঙ্ক (Auto Re-sync) হয়ে যাবে।'}
              </p>
            </div>
          </div>
        </div>

        {/* Data Sync Count Grid */}
        <div className="space-y-2">
          <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
            <Database className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            {isEn ? 'Cloud Synchronized Records' : 'ক্লাউডে সংরক্ষিত হিসাবের পরিসংখ্যান'}
          </h4>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-center">
            <div className="p-2.5 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-800">
              <span className="text-[10px] text-slate-500 block">
                {isEn ? 'Transactions' : 'মোট লেনদেন'}
              </span>
              <span className="text-sm font-bold text-slate-900 dark:text-white">
                {settings.useBanglaNumerals && !isEn ? toBanglaNumber(transactions.length) : transactions.length}
              </span>
            </div>

            <div className="p-2.5 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-800">
              <span className="text-[10px] text-slate-500 block">
                {isEn ? 'Debts / Persons' : 'দেনা-পাওনা ব্যক্তি'}
              </span>
              <span className="text-sm font-bold text-slate-900 dark:text-white">
                {settings.useBanglaNumerals && !isEn ? toBanglaNumber(persons.length) : persons.length}
              </span>
            </div>

            <div className="p-2.5 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-800">
              <span className="text-[10px] text-slate-500 block">
                {isEn ? 'Accounts & Wallets' : 'ওয়ালেট ও ব্যাংক'}
              </span>
              <span className="text-sm font-bold text-slate-900 dark:text-white">
                {settings.useBanglaNumerals && !isEn ? toBanglaNumber(accounts.length) : accounts.length}
              </span>
            </div>

            <div className="p-2.5 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-800">
              <span className="text-[10px] text-slate-500 block">
                {isEn ? 'Budgets & Goals' : 'বাজেট ও লক্ষ্য'}
              </span>
              <span className="text-sm font-bold text-slate-900 dark:text-white">
                {settings.useBanglaNumerals && !isEn
                  ? toBanglaNumber(budgets.length + savings.length)
                  : budgets.length + savings.length}
              </span>
            </div>

            <div className="p-2.5 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-800">
              <span className="text-[10px] text-slate-500 block">
                {isEn ? 'Notes & Memos' : 'নোট ও মেমো'}
              </span>
              <span className="text-sm font-bold text-slate-900 dark:text-white">
                {settings.useBanglaNumerals && !isEn ? toBanglaNumber(notes.length) : notes.length}
              </span>
            </div>

            <div className="p-2.5 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-800">
              <span className="text-[10px] text-slate-500 block">
                {isEn ? 'Cloud Storage' : 'ক্লাউড স্টোরেজ'}
              </span>
              <span className="text-sm font-bold text-emerald-600 dark:text-emerald-400">
                {isEn ? 'Free Forever' : 'আজীবন ফ্রি'}
              </span>
            </div>
          </div>
        </div>

        {/* Security & Multi-Device Assurance */}
        <div className="space-y-2 text-xs text-slate-600 dark:text-slate-400">
          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-start gap-2.5">
            <Lock className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
            <div>
              <strong className="text-slate-800 dark:text-slate-200 block text-xs">
                {isEn ? 'Isolated & Private User Security:' : 'সম্পূর্ণ ব্যক্তিগত ও নিরাপদ:'}
              </strong>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 leading-relaxed">
                {isEn
                  ? 'Your financial documents are securely encrypted and protected under your unique Google UID. No other user can access or view your entries.'
                  : 'আপনার হিসাব শুধু আপনার Google আইডি দিয়েই সুরক্ষিত। ফায়ারবেস সিকিউরিটি রুলসের মাধ্যমে অন্য কোনো ব্যবহারকারী আপনার ডাটা দেখতে বা পরিবর্তন করতে পারে না।'}
              </p>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-start gap-2.5">
            <Smartphone className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
            <div>
              <strong className="text-slate-800 dark:text-slate-200 block text-xs">
                {isEn ? 'Uninstall & Reinstall Recovery Guarantee:' : 'অ্যাপ আনইনস্টল রিকভারি গ্যারান্টি:'}
              </strong>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 leading-relaxed">
                {isEn
                  ? 'Even if you uninstall the app or get a brand-new device, simply install again and log in with the same Google Account to restore 100% of your records in seconds.'
                  : 'ভুলবশত অ্যাপ আনইনস্টল করলেও কিংবা ফোন পরিবর্তন করলেও কোনো চিন্তা নেই! পুনরায় ইনস্টল করে একই Google অ্যাকাউন্ট দিয়ে লগইন করলেই কয়েক সেকেন্ডে আগের সমস্ত হিসাব হুবহু পুনরুদ্ধার হবে।'}
              </p>
            </div>
          </div>
        </div>

        {/* Close Button */}
        <div>
          <button
            onClick={() => setIsFirebaseModalOpen(false)}
            className="w-full py-2.5 px-4 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-semibold transition-colors"
          >
            {isEn ? 'Close' : 'বন্ধ করুন'}
          </button>
        </div>
      </div>
    </div>
  );
};
