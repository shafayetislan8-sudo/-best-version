import React, { useState, useEffect } from 'react';
import {
  FileText,
  BookOpen,
  LayoutGrid,
  Wallet,
  Lock,
  Sliders,
  Users,
  Palette,
  Eye,
  CheckCircle2,
  Plus,
  User,
  X,
  Utensils,
  Zap,
  Calendar,
  Award,
  Cloud,
  Check,
  AlertCircle,
  Smartphone,
  Download,
  Copy,
  ExternalLink,
  Sparkles,
  Edit2,
  ArrowLeftRight,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Account, AccountType } from '../types';
import { toBanglaNumber, formatCurrency } from '../utils/formatters';

import { WalletTransferModal } from './WalletTransferModal';

export const ProfileMenuView: React.FC = () => {
  const {
    accounts,
    addAccount,
    updateAccount,
    settings,
    updateSettings,
    setActiveTab,
    setIsFirebaseModalOpen,
  } = useApp();

  const isEn = settings.language === 'en';
  const [isAddAccountModalOpen, setIsAddAccountModalOpen] = useState(false);
  const [editingAccount, setEditingAccount] = useState<Account | null>(null);
  const [accName, setAccName] = useState('');
  const [accType, setAccType] = useState<AccountType>('mobile_wallet');
  const [accInitialBalance, setAccInitialBalance] = useState('');
  const [accountError, setAccountError] = useState('');
  const [pinModalOpen, setPinModalOpen] = useState(false);
  const [pinCode, setPinCode] = useState(settings.pinCode || '');
  const [pinError, setPinError] = useState('');
  const [pinSuccess, setPinSuccess] = useState('');
  const [isWalletModalOpen, setIsWalletModalOpen] = useState(false);
  const [showApkModal, setShowApkModal] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    const handler = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      if (choice.outcome === 'accepted') {
        setDeferredPrompt(null);
      }
    }
  };

  const currentAppUrl = typeof window !== 'undefined' ? window.location.href : '';

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(currentAppUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2500);
  };

  const toolsGrid = [
    {
      id: 'apk_download',
      title: isEn ? 'App Icon & Mobile APK' : 'অ্যাপ আইকন ও মোবাইল APK',
      icon: Smartphone,
      color: '#059669',
      action: () => setShowApkModal(true),
    },
    {
      id: 'cloud_sync',
      title: isEn ? 'Cloud Sync & Backup' : 'অনলাইন ক্লাউড সিঙ্ক',
      icon: Cloud,
      color: '#0284c7',
      action: () => setIsFirebaseModalOpen(true),
    },
    {
      id: 'health_score',
      title: isEn ? 'Health Score' : 'আর্থিক স্বাস্থ্য স্কোর',
      icon: Award,
      color: '#10b981',
      action: () => setActiveTab('health_score'),
    },
    {
      id: 'mess',
      title: isEn ? 'Mess Splitter' : 'মেস ও মিল হিসাব',
      icon: Utensils,
      color: '#f97316',
      action: () => setActiveTab('mess'),
    },
    {
      id: 'sms_parse',
      title: isEn ? 'SMS Auto Tracker' : 'SMS ট্র্যাকার',
      icon: Zap,
      color: '#eab308',
      action: () => setActiveTab('sms_parse'),
    },
    {
      id: 'heatmap',
      title: isEn ? 'Calendar Heatmap' : 'ক্যালেন্ডার হিটম্যাপ',
      icon: Calendar,
      color: '#8b5cf6',
      action: () => setActiveTab('calendar_heatmap'),
    },
    {
      id: 'pdf',
      title: isEn ? 'Financial Reports' : 'রিপোর্ট ও স্টেটমেন্ট',
      icon: FileText,
      color: '#2563eb',
      action: () => setActiveTab('reports'),
    },
    {
      id: 'notes',
      title: isEn ? 'Notes & Memos' : 'নোট ও বাজারের ফর্দ',
      icon: BookOpen,
      color: '#f59e0b',
      action: () => setActiveTab('notes'),
    },
    {
      id: 'wallet',
      title: isEn ? 'Wallet Transfer' : 'ওয়ালেট ও ট্রান্সফার',
      icon: Wallet,
      color: '#06b6d4',
      action: () => setIsWalletModalOpen(true),
    },
    {
      id: 'pin',
      title: isEn ? 'PIN Security' : 'অ্যাপ পিন লক',
      icon: Lock,
      color: '#6366f1',
      action: () => {
        setPinError('');
        setPinSuccess('');
        setPinModalOpen(true);
      },
    },
    {
      id: 'theme',
      title: isEn ? 'Toggle Theme' : 'অ্যাপের থিম পরিবর্তন',
      icon: Palette,
      color: '#a855f7',
      action: () => {
        const next = settings.theme === 'dark' ? 'light' : 'dark';
        updateSettings({ theme: next });
      },
    },
  ];

  const openAddAccountModal = () => {
    setEditingAccount(null);
    setAccName('');
    setAccType('mobile_wallet');
    setAccInitialBalance('0');
    setAccountError('');
    setIsAddAccountModalOpen(true);
  };

  const openEditAccountModal = (acc: Account) => {
    setEditingAccount(acc);
    setAccName(acc.name);
    setAccType(acc.type);
    setAccInitialBalance(String(acc.initialBalance || 0));
    setAccountError('');
    setIsAddAccountModalOpen(true);
  };

  const handleSaveAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if (!accName.trim()) {
      setAccountError(isEn ? 'Please enter an account name' : 'অ্যাকাউন্টের নাম লিখুন');
      return;
    }

    const initBal = parseFloat(accInitialBalance) || 0;

    if (editingAccount) {
      updateAccount(editingAccount.id, {
        name: accName.trim(),
        type: accType,
        initialBalance: initBal,
      });
    } else {
      const typeColors: Record<AccountType, string> = {
        cash: '#10b981',
        mobile_wallet: '#ec4899',
        bank: '#2563eb',
        card: '#8b5cf6',
        other: '#64748b',
      };
      addAccount({
        name: accName.trim(),
        type: accType,
        initialBalance: initBal,
        color: typeColors[accType] || '#2563eb',
        icon: 'Wallet',
      });
    }

    setIsAddAccountModalOpen(false);
    setEditingAccount(null);
    setAccName('');
    setAccInitialBalance('');
    setAccountError('');
  };

  return (
    <div className="space-y-4 pb-20 pt-1">
      {/* 1. Profile / User Header Card */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-100 dark:border-slate-800 shadow-xs flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-blue-600 text-white font-bold text-lg flex items-center justify-center shadow-xs">
            {settings.userName ? settings.userName.charAt(0).toUpperCase() : 'S'}
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-800 dark:text-white">
              {settings.userName || (isEn ? 'Shafayet Islam' : 'শাফায়েত ইসলাম')}
            </h3>
            <p className="text-xs text-slate-400">
              {settings.userEmail || ''}
            </p>
          </div>
        </div>

        <button
          onClick={() => setActiveTab('settings')}
          className="p-2 text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
          title={isEn ? 'Settings' : 'সেটিংস'}
        >
          <Sliders className="w-5 h-5" />
        </button>
      </div>

      {/* 2. Tools Grid matching video 00:05 */}
      <div className="space-y-2">
        <h3 className="text-xs font-bold text-slate-700 dark:text-slate-300 px-1">
          {isEn ? 'Features & Smart Tools' : 'ফিচার ও স্মার্ট টুলস'}
        </h3>
        <div className="grid grid-cols-3 gap-2.5">
          {toolsGrid.map((tool) => {
            const Icon = tool.icon;
            return (
              <button
                key={tool.id}
                onClick={tool.action}
                className="p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-xs hover:border-slate-300 dark:hover:border-slate-700 flex flex-col items-center justify-center gap-2 transition-all active:scale-95 text-center group"
              >
                <div
                  className="w-10 h-10 rounded-2xl flex items-center justify-center text-white shadow-xs group-hover:scale-105 transition-transform"
                  style={{ backgroundColor: tool.color }}
                >
                  <Icon className="w-5 h-5" />
                </div>
                <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-200 line-clamp-1 leading-tight">
                  {tool.title}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 3. Accounts / Wallets Section (Requirement 3: Automatic balance tracking for bKash, Nagad, Cash, Bank) */}
      <div className="space-y-2 pt-1">
        <div className="flex items-center justify-between px-1">
          <div>
            <h3 className="text-xs font-bold text-slate-700 dark:text-slate-300">
              {isEn ? 'Accounts & Wallets' : 'অ্যাকাউন্ট ও ওয়ালেট ব্যালেন্স'}
            </h3>
            <p className="text-[10px] text-slate-400">
              {isEn
                ? 'bKash, Nagad, Cash & Bank balances update automatically from entries'
                : 'লেনদেন অনুযায়ী বিকাশ, নগদ, ক্যাশ ও ব্যাংকের ব্যালেন্স স্বয়ংক্রিয় হিসাব হয়'}
            </p>
          </div>
          <button
            onClick={openAddAccountModal}
            className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 shrink-0"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{isEn ? 'Add' : 'যোগ করুন'}</span>
          </button>
        </div>

        <div className="space-y-2">
          {accounts.map((acc) => (
            <div
              key={acc.id}
              className="p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-xs flex items-center justify-between hover:border-blue-200 dark:hover:border-slate-700 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div
                  className="w-9 h-9 rounded-xl flex items-center justify-center text-white text-xs font-bold shadow-xs shrink-0"
                  style={{ backgroundColor: acc.color || '#2563eb' }}
                >
                  {acc.name.charAt(0)}
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-800 dark:text-white flex items-center gap-2">
                    <span>{acc.name}</span>
                    <span className="text-[9px] px-1.5 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-500 font-semibold uppercase">
                      {acc.type === 'cash' ? (isEn ? 'Cash' : 'ক্যাশ') : acc.type === 'mobile_wallet' ? (isEn ? 'Wallet' : 'ওয়ালেট') : acc.type === 'bank' ? (isEn ? 'Bank' : 'ব্যাংক') : acc.type}
                    </span>
                  </h4>
                  <p className="text-[10px] text-slate-400 font-medium">
                    {isEn ? 'Opening' : 'প্রারম্ভিক'}: {formatCurrency(acc.initialBalance || 0, settings.useBanglaNumerals && !isEn)}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2.5">
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 block font-medium">
                    {isEn ? 'Current' : 'বর্তমান ব্যালেন্স'}
                  </span>
                  <span
                    className={`text-xs font-bold block ${
                      acc.currentBalance < 0
                        ? 'text-rose-600 dark:text-rose-400'
                        : 'text-slate-800 dark:text-slate-100'
                    }`}
                  >
                    {formatCurrency(acc.currentBalance, settings.useBanglaNumerals && !isEn)}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => openEditAccountModal(acc)}
                  className="p-1.5 text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg transition-colors"
                  title={isEn ? 'Edit Opening Balance' : 'প্রারম্ভিক ব্যালেন্স সম্পাদনা'}
                >
                  <Edit2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Add / Edit Account Modal */}
      {isAddAccountModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-5 shadow-2xl space-y-3.5 border border-slate-100 dark:border-slate-800">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
              <h3 className="text-sm font-bold text-slate-800 dark:text-white">
                {editingAccount
                  ? (isEn ? 'Edit Account / Wallet' : 'অ্যাকাউন্ট সম্পাদনা')
                  : (isEn ? 'New Account / Wallet' : 'নতুন অ্যাকাউন্ট বা ওয়ালেট')}
              </h3>
              <button
                type="button"
                onClick={() => {
                  setIsAddAccountModalOpen(false);
                  setEditingAccount(null);
                }}
                className="p-1 text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {accountError && (
              <p className="text-xs font-bold text-rose-600 dark:text-rose-400">{accountError}</p>
            )}

            <form onSubmit={handleSaveAccount} className="space-y-3">
              <div>
                <label className="text-[11px] font-bold text-slate-600 dark:text-slate-300 block mb-1">
                  {isEn ? 'Account Name' : 'অ্যাকাউন্টের নাম'} *
                </label>
                <input
                  type="text"
                  value={accName}
                  onChange={(e) => setAccName(e.target.value)}
                  placeholder={isEn ? 'e.g. bKash, Nagad, City Bank' : 'যেমন: বিকাশ (bKash), নগদ, সিটি ব্যাংক'}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500 font-semibold"
                  autoFocus
                  required
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-600 dark:text-slate-300 block mb-1">
                  {isEn ? 'Account Type' : 'অ্যাকাউন্টের ধরন'}
                </label>
                <select
                  value={accType}
                  onChange={(e) => setAccType(e.target.value as AccountType)}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500 font-semibold"
                >
                  <option value="mobile_wallet">{isEn ? 'Mobile Wallet (bKash / Nagad / Upay)' : 'মোবাইল ওয়ালেট (বিকাশ / নগদ / উপায়)'}</option>
                  <option value="cash">{isEn ? 'Cash (টাকা)' : 'নগদ ক্যাশ (টাকা)'}</option>
                  <option value="bank">{isEn ? 'Bank Account' : 'ব্যাংক অ্যাকাউন্ট'}</option>
                  <option value="card">{isEn ? 'Credit / Debit Card' : 'ক্রেডিট / ডেবিট কার্ড'}</option>
                  <option value="other">{isEn ? 'Other' : 'অন্যান্য'}</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-600 dark:text-slate-300 block mb-1">
                  {isEn ? 'Opening Balance (৳)' : 'প্রারম্ভিক ব্যালেন্স (Opening Balance) ৳'}
                </label>
                <input
                  type="number"
                  step="any"
                  value={accInitialBalance}
                  onChange={(e) => setAccInitialBalance(e.target.value)}
                  placeholder="0"
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-bold text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <p className="text-[10px] text-slate-400 mt-1">
                  {isEn
                    ? 'Total balance is calculated as Opening Balance + All Incomes - All Expenses.'
                    : 'বর্তমান ব্যালেন্স = প্রারম্ভিক ব্যালেন্স + সমস্ত আয় - সমস্ত ব্যয়।'}
                </p>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddAccountModalOpen(false);
                    setEditingAccount(null);
                  }}
                  className="px-3.5 py-2 text-xs font-semibold text-slate-500 hover:text-slate-700"
                >
                  {isEn ? 'Cancel' : 'বাতিল'}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
                >
                  {editingAccount ? (isEn ? 'Update' : 'আপডেট করুন') : (isEn ? 'Save' : 'সংরক্ষণ করুন')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* PIN Lock Security Modal */}
      {pinModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-xs bg-white dark:bg-slate-900 rounded-3xl p-5 shadow-2xl space-y-4 border border-slate-100 dark:border-slate-800 animate-in fade-in">
            <div className="flex items-center gap-2 text-slate-800 dark:text-white">
              <Lock className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <h3 className="text-sm font-bold">
                {isEn ? 'Set App PIN Lock' : '৪ ডিজিটের পিন লক সেট করুন'}
              </h3>
            </div>

            {pinError && (
              <div className="p-2 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 text-xs flex items-center gap-1.5 font-medium">
                <AlertCircle className="w-3.5 h-3.5" />
                <span>{pinError}</span>
              </div>
            )}

            {pinSuccess && (
              <div className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 text-xs flex items-center gap-1.5 font-bold">
                <Check className="w-4 h-4" />
                <span>{pinSuccess}</span>
              </div>
            )}

            <div className="flex items-center justify-between text-xs py-1">
              <span className="text-slate-600 dark:text-slate-400 font-medium">
                {isEn ? 'Enable PIN Lock' : 'পিন লক চালু রাখুন'}
              </span>
              <input
                type="checkbox"
                checked={settings.isPinEnabled}
                onChange={(e) => updateSettings({ isPinEnabled: e.target.checked })}
                className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
              />
            </div>

            <input
              type="password"
              maxLength={4}
              value={pinCode}
              onChange={(e) => {
                setPinError('');
                setPinCode(e.target.value.replace(/[^0-9]/g, ''));
              }}
              placeholder="••••"
              className="w-full text-center tracking-widest text-2xl font-bold p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />

            <div className="flex justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setPinModalOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
              >
                {isEn ? 'Close' : 'বাতিল'}
              </button>
              <button
                type="button"
                onClick={() => {
                  if (pinCode.length === 4) {
                    updateSettings({ isPinEnabled: true, pinCode });
                    setPinSuccess(isEn ? 'PIN saved successfully!' : 'পিন কোড সফলভাবে সংরক্ষিত হয়েছে!');
                    setTimeout(() => {
                      setPinModalOpen(false);
                    }, 1200);
                  } else {
                    setPinError(isEn ? 'Please enter a 4-digit PIN' : 'অনুগ্রহ করে ৪ ডিজিটের পিন কোড লিখুন');
                  }
                }}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
              >
                {isEn ? 'Save PIN' : 'সংরক্ষণ'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* APK & App Install Guide Modal */}
      {showApkModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-5 shadow-2xl space-y-4 border border-slate-100 dark:border-slate-800 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 flex items-center justify-center">
                  <Smartphone className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-800 dark:text-white">
                    {isEn ? 'Get Mobile APK & Install' : 'মোবাইল APK ডাউনলোড ও ইন্সটল'}
                  </h3>
                  <p className="text-[10px] text-slate-400">
                    {isEn ? 'Run offline like a native Android app' : 'অফলাইনে সাধারণ অ্যান্ড্রয়েড অ্যাপের মতো ব্যবহার করুন'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowApkModal(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
                title={isEn ? 'Close' : 'বন্ধ করুন'}
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* App Icon Preview & Download Card */}
            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <img
                  src="/src/assets/images/app_icon_1792345344884.jpg"
                  alt="App Icon"
                  className="w-14 h-14 rounded-2xl shadow-md border border-white/20 object-cover"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <h4 className="text-xs font-bold text-slate-800 dark:text-white">
                    {isEn ? 'Official 3D App Icon' : 'অফিশিয়াল 3D অ্যাপ আইকন'}
                  </h4>
                  <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">
                    {isEn ? 'Ready for APK & Play Store' : 'APK ও প্লে-স্টোরের জন্য প্রস্তুত'}
                  </p>
                  <p className="text-[9px] text-slate-400">
                    512×512 HD PNG
                  </p>
                </div>
              </div>
              <a
                href="/app-icon.png"
                download="ay_byay_app_icon.png"
                className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs flex items-center gap-1 transition-colors"
                title={isEn ? 'Download Icon' : 'আইকন ডাউনলোড'}
              >
                <Download className="w-3.5 h-3.5" />
                <span>{isEn ? 'Download' : 'ডাউনলোড'}</span>
              </a>
            </div>

            {/* Method 1: Direct WebAPK Install (No downloads needed) */}
            <div className="p-3.5 rounded-2xl bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-slate-800 dark:to-slate-800/60 border border-blue-100 dark:border-slate-700 space-y-2">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <h4 className="text-xs font-bold text-blue-900 dark:text-blue-200">
                  {isEn ? 'Method 1: Direct 1-Click Phone Install' : 'উপায় ১: কোনো ফাইল ছাড়া সরাসরি ফোনে ইন্সটল'}
                </h4>
              </div>
              <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                {isEn
                  ? 'Your browser can install this app directly onto your home screen with full offline support and its own app icon.'
                  : 'অ্যান্ড্রয়েড ক্রোমে কোনো APK ফাইল ডাউনলোড ছাড়াই স্বয়ংক্রিয়ভাবে ফোনে অ্যাপ ড্রয়ারে ইন্সটল করে নেওয়া যায়।'}
              </p>
              {deferredPrompt ? (
                <button
                  onClick={handleInstallClick}
                  className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{isEn ? 'Install App on Device Now' : 'এখনই ফোনে ইন্সটল করুন'}</span>
                </button>
              ) : (
                <div className="text-[10px] bg-white/80 dark:bg-slate-900/80 p-2.5 rounded-xl border border-blue-200/60 dark:border-slate-700 space-y-1">
                  <p className="font-bold text-slate-700 dark:text-slate-200">
                    {isEn ? 'How to install in Chrome:' : 'ফোনের ক্রোমে যেভাবে ইন্সটল করবেন:'}
                  </p>
                  <p className="text-slate-500 dark:text-slate-400">
                    ১. ফোনের Chrome ব্রাউজারের উপরে ৩-ডট (⋮) মেনুতে চাপ দিন।<br />
                    ২. <strong>"Install app"</strong> অথবা <strong>"Add to Home screen"</strong> সিলেক্ট করুন।<br />
                    ৩. সাথে সাথে ফোনের অ্যাপ তালিকায় "আয় ব্যয়" অ্যাপ হিসেবে যোগ হয়ে যাবে!
                  </p>
                </div>
              )}
            </div>

            {/* Method 2: PWABuilder (Convert to actual .apk file) */}
            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-2.5">
              <div className="flex items-center gap-2">
                <Download className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <h4 className="text-xs font-bold text-slate-800 dark:text-white">
                  {isEn ? 'Method 2: Generate APK via PWABuilder' : 'উপায় ২: PWABuilder দিয়ে .apk ফাইল তৈরি'}
                </h4>
              </div>

              <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                {isEn
                  ? 'Microsoft PWABuilder turns this live web app into a signed .apk file and Google Play Store package for free.'
                  : 'মাইক্রোসফটের অফিসিয়াল PWABuilder দিয়ে ১ মিনিটে এই অ্যাপের সাইনড .apk ফাইল তৈরি করে শেয়ার বা প্লে-স্টোরে দেওয়া যাবে।'}
              </p>

              {/* App URL Copy Box */}
              <div className="flex items-center gap-2 p-2 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700 text-xs">
                <input
                  type="text"
                  readOnly
                  value={currentAppUrl}
                  className="bg-transparent text-[11px] text-slate-600 dark:text-slate-300 flex-1 truncate focus:outline-none"
                />
                <button
                  onClick={handleCopyUrl}
                  className="px-2.5 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 rounded-lg text-[10px] font-bold flex items-center gap-1 flex-shrink-0"
                >
                  {copiedUrl ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedUrl ? (isEn ? 'Copied' : 'কপি হয়েছে') : isEn ? 'Copy' : 'কপি'}</span>
                </button>
              </div>

              {/* Steps */}
              <ol className="text-[10px] text-slate-500 dark:text-slate-400 space-y-1 list-decimal list-inside bg-white dark:bg-slate-900 p-2.5 rounded-xl border border-slate-100 dark:border-slate-800">
                <li>উপরের লিঙ্কটি <strong>কপি</strong> করুন।</li>
                <li>যেকোনো ব্রাউজারে <strong>pwabuilder.com</strong> ওয়েবসাইটে যান।</li>
                <li>লিঙ্কটি পেস্ট করে <strong>Start</strong> বাটনে চাপ দিন।</li>
                <li><strong>Package for Stores / Android</strong> সিলেক্ট করে সরাসরি <strong>.apk</strong> ডাউনলোড করুন!</li>
              </ol>

              <a
                href="https://www.pwabuilder.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs flex items-center justify-center gap-1.5 transition-colors"
              >
                <span>PWABuilder ওয়েবসাইটে যান</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Wallet & Transfer Modal */}
      <WalletTransferModal
        isOpen={isWalletModalOpen}
        onClose={() => setIsWalletModalOpen(false)}
      />
    </div>
  );
};
