import React from 'react';
import { X, Download, FileText, Calendar, DollarSign, Tag } from 'lucide-react';
import { Transaction } from '../types';
import { formatCurrency } from '../utils/formatters';
import { useApp } from '../context/AppContext';

interface ReceiptViewModalProps {
  transaction: Transaction | null;
  isOpen: boolean;
  onClose: () => void;
}

export const ReceiptViewModal: React.FC<ReceiptViewModalProps> = ({
  transaction,
  isOpen,
  onClose,
}) => {
  const { settings } = useApp();
  const isEn = settings.language === 'en';

  if (!isOpen || !transaction || !transaction.receiptImage) return null;

  const handleDownload = () => {
    if (!transaction.receiptImage) return;
    const a = document.createElement('a');
    a.href = transaction.receiptImage;
    a.download = `receipt_${transaction.date}_${transaction.id}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-sm w-full overflow-hidden shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-blue-100 dark:bg-blue-950/70 text-blue-600 dark:text-blue-400 flex items-center justify-center">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-slate-800 dark:text-white">
                {isEn ? 'Cash Memo / Receipt' : 'ক্যাশ মেমো ও রসিদ'}
              </h3>
              <p className="text-[10px] text-slate-400">
                {transaction.categoryName} • {transaction.date}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Image Content */}
        <div className="p-4 flex-1 overflow-y-auto flex flex-col items-center justify-center bg-slate-50 dark:bg-slate-950/50">
          <img
            src={transaction.receiptImage}
            alt="Receipt"
            className="max-h-[50vh] w-auto object-contain rounded-2xl shadow-md border border-slate-200 dark:border-slate-800"
          />

          {/* Transaction Summary Card */}
          <div className="w-full mt-3 p-3 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/80 space-y-1.5 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-[11px] text-slate-500 flex items-center gap-1">
                <Tag className="w-3 h-3" /> {isEn ? 'Amount' : 'পরিমাণ'}:
              </span>
              <strong className={`font-bold ${transaction.type === 'expense' ? 'text-rose-600' : 'text-emerald-600'}`}>
                {transaction.type === 'expense' ? '-' : '+'}{formatCurrency(transaction.amount, settings.useBanglaNumerals, settings.currencySymbol)}
              </strong>
            </div>

            {transaction.note && (
              <div className="text-[11px] text-slate-600 dark:text-slate-300 pt-1 border-t border-slate-100 dark:border-slate-700">
                <span className="text-slate-400 font-medium">{isEn ? 'Note: ' : 'নোট: '}</span>
                {transaction.note}
              </div>
            )}
          </div>
        </div>

        {/* Footer actions */}
        <div className="p-3 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2">
          <button
            onClick={handleDownload}
            className="flex-1 py-2.5 px-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-xs"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{isEn ? 'Save Image' : 'ছবি সেভ করুন'}</span>
          </button>
          <button
            onClick={onClose}
            className="py-2.5 px-4 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold transition-colors"
          >
            {isEn ? 'Close' : 'বন্ধ করুন'}
          </button>
        </div>
      </div>
    </div>
  );
};
