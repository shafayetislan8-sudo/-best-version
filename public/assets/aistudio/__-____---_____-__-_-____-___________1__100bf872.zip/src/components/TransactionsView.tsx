import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  Download,
  Calendar,
  ArrowUpRight,
  ArrowDownLeft,
  RefreshCw,
  X,
  FileSpreadsheet,
  Image as ImageIcon,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import {
  formatCurrency,
  formatBengaliDate,
  toBanglaNumber,
} from '../utils/formatters';
import { renderCategoryIcon } from '../utils/iconMap';
import { Transaction, TransactionType } from '../types';
import { ReceiptViewModal } from './ReceiptViewModal';

export const TransactionsView: React.FC = () => {
  const {
    transactions,
    categories,
    accounts,
    settings,
    setEditingTransaction,
    setIsAddTxOpen,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [filterAccount, setFilterAccount] = useState<string>('all');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [filterPeriod, setFilterPeriod] = useState<string>('all'); // all, this_month, last_month
  const [selectedReceiptTx, setSelectedReceiptTx] = useState<Transaction | null>(null);

  // Compute filtered transactions
  const filteredTransactions = useMemo(() => {
    const now = new Date();
    const curYear = now.getFullYear();
    const curMonth = now.getMonth() + 1;

    return transactions.filter((tx) => {
      // Search query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesNote = tx.note?.toLowerCase().includes(query);
        const matchesCategory = tx.categoryName.toLowerCase().includes(query);
        const matchesAccount = tx.accountName.toLowerCase().includes(query);
        const matchesPerson = tx.person?.toLowerCase().includes(query);
        const matchesAmount = String(tx.amount).includes(query);
        if (!matchesNote && !matchesCategory && !matchesAccount && !matchesPerson && !matchesAmount) {
          return false;
        }
      }

      // Type filter
      if (filterType !== 'all' && tx.type !== filterType) {
        return false;
      }

      // Account filter
      if (filterAccount !== 'all' && tx.accountId !== filterAccount && tx.toAccountId !== filterAccount) {
        return false;
      }

      // Category filter
      if (filterCategory !== 'all' && tx.categoryId !== filterCategory) {
        return false;
      }

      // Period filter
      if (filterPeriod !== 'all') {
        const [year, month] = tx.date.split('-').map(Number);
        if (filterPeriod === 'this_month') {
          if (year !== curYear || month !== curMonth) return false;
        } else if (filterPeriod === 'last_month') {
          const lastM = curMonth === 1 ? 12 : curMonth - 1;
          const lastY = curMonth === 1 ? curYear - 1 : curYear;
          if (year !== lastY || month !== lastM) return false;
        }
      }

      return true;
    });
  }, [transactions, searchQuery, filterType, filterAccount, filterCategory, filterPeriod]);

  // Totals for filtered transactions
  const totalFilteredIncome = useMemo(() => {
    return filteredTransactions
      .filter((t) => t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0);
  }, [filteredTransactions]);

  const totalFilteredExpense = useMemo(() => {
    return filteredTransactions
      .filter((t) => t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0);
  }, [filteredTransactions]);

  // Export to CSV
  const handleExportCSV = () => {
    const headers = ['তারিখ', 'সময়', 'ধরন', 'ক্যাটাগরি', 'পরিমাণ', 'অ্যাকাউন্ট', 'নোট', 'ব্যক্তি'];
    const rows = filteredTransactions.map((tx) => [
      tx.date,
      tx.time,
      tx.type === 'income' ? 'আয়' : tx.type === 'expense' ? 'ব্যয়' : 'স্থানান্তর',
      `"${tx.categoryName}"`,
      tx.amount,
      `"${tx.accountName}${tx.toAccountName ? ' -> ' + tx.toAccountName : ''}"`,
      `"${(tx.note || '').replace(/"/g, '""')}"`,
      `"${(tx.person || '').replace(/"/g, '""')}"`,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,\uFEFF' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `ay_byay_transactions_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const clearFilters = () => {
    setSearchQuery('');
    setFilterType('all');
    setFilterAccount('all');
    setFilterCategory('all');
    setFilterPeriod('all');
  };

  const hasActiveFilters =
    searchQuery || filterType !== 'all' || filterAccount !== 'all' || filterCategory !== 'all' || filterPeriod !== 'all';

  return (
    <div className="space-y-4 pb-24">
      {/* Top Search & Filter Bar */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-3 border border-slate-100 dark:border-slate-800 shadow-xs space-y-3">
        <div className="relative flex items-center">
          <Search className="w-4 h-4 text-slate-400 absolute left-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="বিবরণ, ক্যাটাগরি বা পরিমাণ দিয়ে খুঁজুন..."
            className="w-full pl-9 pr-9 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 text-slate-400 hover:text-slate-600"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Dropdown Filters */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
          {/* Type Filter */}
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-700 dark:text-slate-300"
          >
            <option value="all">সব ধরন (All Types)</option>
            <option value="expense">ব্যয় (Expense)</option>
            <option value="income">আয় (Income)</option>
            <option value="transfer">স্থানান্তর (Transfer)</option>
          </select>

          {/* Account Filter */}
          <select
            value={filterAccount}
            onChange={(e) => setFilterAccount(e.target.value)}
            className="px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-700 dark:text-slate-300"
          >
            <option value="all">সব অ্যাকাউন্ট</option>
            {accounts.map((acc) => (
              <option key={acc.id} value={acc.id}>
                {acc.name}
              </option>
            ))}
          </select>

          {/* Category Filter */}
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-700 dark:text-slate-300"
          >
            <option value="all">সব ক্যাটাগরি</option>
            {categories.map((cat) => (
              <option key={cat.id} value={cat.id}>
                {cat.name} ({cat.type === 'income' ? 'আয়' : 'ব্যয়'})
              </option>
            ))}
          </select>

          {/* Period Filter */}
          <select
            value={filterPeriod}
            onChange={(e) => setFilterPeriod(e.target.value)}
            className="px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-700 dark:text-slate-300"
          >
            <option value="all">সব সময়</option>
            <option value="this_month">চলতি মাস</option>
            <option value="last_month">গত মাস</option>
          </select>
        </div>

        {/* Filter Summary & Actions */}
        <div className="flex items-center justify-between pt-1 border-t border-slate-100 dark:border-slate-800 text-xs">
          <span className="text-slate-500 dark:text-slate-400">
            খুঁজে পাওয়া গেছে:{' '}
            <strong className="text-slate-800 dark:text-white">
              {settings.useBanglaNumerals
                ? toBanglaNumber(filteredTransactions.length)
                : filteredTransactions.length}
            </strong>{' '}
            টি লেনদেন
          </span>

          <div className="flex items-center gap-2">
            {hasActiveFilters && (
              <button
                onClick={clearFilters}
                className="text-[11px] text-rose-600 dark:text-rose-400 hover:underline"
              >
                ফিল্টার মুছুন
              </button>
            )}
            <button
              onClick={handleExportCSV}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 font-semibold text-[11px] hover:bg-blue-100 transition-colors"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              এক্সেল / CSV
            </button>
          </div>
        </div>
      </div>

      {/* Filtered Totals Banner */}
      <div className="grid grid-cols-2 gap-2">
        <div className="p-3 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/40 border border-emerald-100 dark:border-emerald-900/60">
          <p className="text-[11px] text-emerald-700 dark:text-emerald-300 font-medium">
            ফিল্টারকৃত মোট আয়
          </p>
          <p className="text-base font-bold text-emerald-700 dark:text-emerald-300">
            {formatCurrency(totalFilteredIncome, settings.useBanglaNumerals)}
          </p>
        </div>
        <div className="p-3 rounded-2xl bg-rose-50/70 dark:bg-rose-950/40 border border-rose-100 dark:border-rose-900/60">
          <p className="text-[11px] text-rose-700 dark:text-rose-300 font-medium">
            ফিল্টারকৃত মোট ব্যয়
          </p>
          <p className="text-base font-bold text-rose-700 dark:text-rose-300">
            {formatCurrency(totalFilteredExpense, settings.useBanglaNumerals)}
          </p>
        </div>
      </div>

      {/* Transaction List */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-xs divide-y divide-slate-50 dark:divide-slate-800 overflow-hidden">
        {filteredTransactions.length === 0 ? (
          <div className="p-8 text-center text-slate-400 dark:text-slate-500">
            <p className="text-xs">কোনো লেনদেন পাওয়া যায়নি</p>
          </div>
        ) : (
          filteredTransactions.map((tx) => {
            const isExpense = tx.type === 'expense';
            const isIncome = tx.type === 'income';
            const isTransfer = tx.type === 'transfer';

            return (
              <div
                key={tx.id}
                onClick={() => {
                  setEditingTransaction(tx);
                  setIsAddTxOpen(true);
                }}
                className="px-4 py-3 flex items-center justify-between hover:bg-slate-50/80 dark:hover:bg-slate-800/40 cursor-pointer transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center text-white shadow-xs flex-shrink-0"
                    style={{
                      backgroundColor:
                        tx.categoryColor ||
                        (isExpense ? '#ef4444' : isIncome ? '#10b981' : '#6366f1'),
                    }}
                  >
                    {renderCategoryIcon(tx.categoryIcon, 'w-5 h-5', '#ffffff')}
                  </div>

                  <div>
                    <div className="flex items-center gap-1.5">
                      <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100">
                        {tx.categoryName}
                      </h4>
                      {isTransfer && (
                        <span className="text-[10px] px-1.5 py-0.2 bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400 rounded-md">
                          স্থানান্তর
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-1">
                      {tx.note || (isTransfer ? `${tx.accountName} ➔ ${tx.toAccountName}` : tx.accountName)}
                      {tx.person ? ` • ${tx.person}` : ''}
                    </p>
                    <div className="flex items-center gap-1.5 text-[10px] text-slate-400 dark:text-slate-500 mt-0.5">
                      <span>{formatBengaliDate(tx.date, settings.useBanglaNumerals)}</span>
                      <span>•</span>
                      <span>{tx.time}</span>
                      <span>•</span>
                      <span className="text-blue-600 dark:text-blue-400 font-medium">
                        {tx.accountName}
                      </span>
                      {tx.receiptImage && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedReceiptTx(tx);
                          }}
                          className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-md bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 text-[9px] font-bold border border-blue-200/60 hover:bg-blue-100 transition-colors"
                          title="ক্যাশ মেমো দেখুন"
                        >
                          <ImageIcon className="w-2.5 h-2.5" />
                          <span>মেমো</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                <div className="text-right flex-shrink-0 pl-2">
                  <span
                    className={`text-sm font-bold block ${
                      isIncome
                        ? 'text-emerald-600 dark:text-emerald-400'
                        : isExpense
                        ? 'text-rose-600 dark:text-rose-400'
                        : 'text-blue-600 dark:text-blue-400'
                    }`}
                  >
                    {isIncome ? '+' : isExpense ? '-' : '↔'}{' '}
                    {formatCurrency(tx.amount, settings.useBanglaNumerals)}
                  </span>
                  <span className="text-[10px] text-slate-400 hover:text-blue-500">
                    সম্পাদনা করুন
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Cash Memo & Receipt Image Modal */}
      <ReceiptViewModal
        transaction={selectedReceiptTx}
        isOpen={Boolean(selectedReceiptTx)}
        onClose={() => setSelectedReceiptTx(null)}
      />
    </div>
  );
};
