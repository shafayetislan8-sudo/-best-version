import React, { useState } from 'react';
import {
  ArrowLeft,
  Search,
  Plus,
  MoreVertical,
  CheckCircle2,
  Edit2,
  Trash2,
  AlertCircle,
  Tag,
  Check,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Category } from '../types';
import { renderCategoryIcon } from '../utils/iconMap';

const COLOR_PALETTE = [
  '#ef4444', '#f97316', '#f59e0b', '#10b981', '#06b6d4',
  '#3b82f6', '#6366f1', '#8b5cf6', '#ec4899', '#64748b',
];

const AVAILABLE_ICONS = [
  'Utensils', 'ShoppingBasket', 'Home', 'Car', 'Zap', 'Wifi',
  'HeartPulse', 'ShoppingBag', 'GraduationCap', 'Film', 'Gift',
  'HandCoins', 'Briefcase', 'Building2', 'Laptop', 'TrendingUp', 'Tag'
];

export const CategoriesScreen: React.FC = () => {
  const { categories, addCategory, updateCategory, deleteCategory, setActiveTab, settings } = useApp();
  const isEn = settings.language === 'en';

  const [activeTabType, setActiveTabType] = useState<'expense' | 'income' | 'all'>('expense');
  const [search, setSearch] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCat, setEditingCat] = useState<Category | null>(null);
  const [activeItemMenuId, setActiveItemMenuId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Form states
  const [categoryType, setCategoryType] = useState<'income' | 'expense'>('expense');
  const [name, setName] = useState('');
  const [selectedColor, setSelectedColor] = useState('#ef4444');
  const [selectedIcon, setSelectedIcon] = useState('Tag');

  const expenseCount = categories.filter((c) => c.type === 'expense').length;
  const incomeCount = categories.filter((c) => c.type === 'income').length;

  const filtered = categories.filter((c) => {
    if (activeTabType !== 'all' && c.type !== activeTabType) return false;
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return c.name.toLowerCase().includes(q) || (c.nameEn && c.nameEn.toLowerCase().includes(q));
  });

  const openAddModal = () => {
    setEditingCat(null);
    setName('');
    setCategoryType(activeTabType === 'income' ? 'income' : 'expense');
    setSelectedColor(activeTabType === 'income' ? '#10b981' : '#ef4444');
    setSelectedIcon('Tag');
    setErrorMessage(null);
    setIsModalOpen(true);
  };

  const openEditModal = (cat: Category) => {
    setEditingCat(cat);
    setName(isEn ? (cat.nameEn || cat.name) : cat.name);
    setCategoryType(cat.type);
    setSelectedColor(cat.color || '#2563eb');
    setSelectedIcon(cat.icon || 'Tag');
    setActiveItemMenuId(null);
    setErrorMessage(null);
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = name.trim();
    if (!cleanName) {
      setErrorMessage(isEn ? 'Please enter a category name' : 'ক্যাটাগরির নাম লিখুন');
      return;
    }

    // Duplicate check: ensure no other category of same type has this name
    const isDuplicate = categories.some(
      (c) =>
        c.type === categoryType &&
        c.id !== editingCat?.id &&
        c.name.trim().toLowerCase() === cleanName.toLowerCase()
    );

    if (isDuplicate) {
      setErrorMessage(
        isEn
          ? 'A category with this name already exists!'
          : 'এই নামে ইতিমধ্যে একটি ক্যাটাগরি রয়েছে!'
      );
      return;
    }

    if (editingCat) {
      updateCategory(editingCat.id, {
        name: cleanName,
        nameEn: cleanName,
        type: categoryType,
        color: selectedColor,
        icon: selectedIcon,
      });
      setToastMessage(isEn ? 'Category updated successfully' : 'ক্যাটাগরি আপডেট করা হয়েছে');
    } else {
      addCategory({
        name: cleanName,
        nameEn: cleanName,
        type: categoryType,
        icon: selectedIcon,
        color: selectedColor,
      });
      setToastMessage(isEn ? 'Category added successfully' : 'নতুন ক্যাটাগরি যোগ করা হয়েছে');
    }

    setIsModalOpen(false);
    setName('');
    setErrorMessage(null);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleDelete = (id: string) => {
    const res = deleteCategory(id);
    setActiveItemMenuId(null);
    if (!res.success) {
      setToastMessage(res.message || (isEn ? 'Could not delete category' : 'ক্যাটাগরি মুছে ফেলা যায়নি'));
    } else {
      setToastMessage(isEn ? 'Category moved to trash' : 'ক্যাটাগরি রিসাইকেল বিনে নেওয়া হয়েছে');
    }
    setTimeout(() => setToastMessage(null), 3000);
  };

  return (
    <div className="space-y-4 pb-24 pt-1">
      {/* Header */}
      <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setActiveTab('dashboard')}
            className="p-1 rounded-full text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title={isEn ? 'Back' : 'পেছনে যান'}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              {isEn ? 'Category Manager' : 'ক্যাটাগরি ব্যবস্থাপনা'}
            </h2>
            <p className="text-[10px] text-slate-500 dark:text-slate-400">
              {isEn ? 'Manage your income & expense categories' : 'আয় ও ব্যয়ের ক্যাটাগরি যোগ ও পরিবর্তন করুন'}
            </p>
          </div>
        </div>

        <button
          onClick={openAddModal}
          className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold flex items-center gap-1 shadow-xs transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>{isEn ? 'Add' : 'নতুন ক্যাটাগরি'}</span>
        </button>
      </div>

      {/* Segmented Filter Tabs: Expense | Income | All */}
      <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-100 dark:bg-slate-800/80 rounded-2xl text-xs font-bold text-center">
        <button
          type="button"
          onClick={() => setActiveTabType('expense')}
          className={`py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
            activeTabType === 'expense'
              ? 'bg-rose-500 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <span>{isEn ? 'Expenses' : 'ব্যয় ক্যাটাগরি'}</span>
          <span className="text-[10px] opacity-80">({expenseCount})</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveTabType('income')}
          className={`py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
            activeTabType === 'income'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <span>{isEn ? 'Income' : 'আয় ক্যাটাগরি'}</span>
          <span className="text-[10px] opacity-80">({incomeCount})</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveTabType('all')}
          className={`py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
            activeTabType === 'all'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <span>{isEn ? 'All' : 'সব'}</span>
          <span className="text-[10px] opacity-80">({categories.length})</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={isEn ? 'Search categories...' : 'ক্যাটাগরি খুঁজুন...'}
          className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs focus:outline-none shadow-xs text-slate-800 dark:text-slate-100 placeholder:text-slate-400"
        />
      </div>

      {/* Categories List */}
      {filtered.length === 0 ? (
        <div className="py-16 flex flex-col items-center justify-center text-center">
          <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-400 mb-2">
            <Tag className="w-6 h-6" />
          </div>
          <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">
            {isEn ? 'No categories found' : 'কোন ক্যাটাগরি পাওয়া যায়নি'}
          </p>
          <button
            onClick={openAddModal}
            className="mt-3 text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline"
          >
            {isEn ? '+ Add new category' : '+ নতুন ক্যাটাগরি তৈরি করুন'}
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {filtered.map((cat) => (
            <div
              key={cat.id}
              className="p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-xs flex items-center justify-between relative hover:border-slate-300 dark:hover:border-slate-700 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div
                  className="w-9 h-9 rounded-xl flex items-center justify-center text-white shadow-xs"
                  style={{ backgroundColor: cat.color || '#2563eb' }}
                >
                  {renderCategoryIcon(cat.icon, '#ffffff')}
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-800 dark:text-white">
                    {isEn ? (cat.nameEn || cat.name) : cat.name}
                  </h4>
                  <span
                    className={`inline-block text-[9px] px-1.5 py-0.2 rounded-md font-bold uppercase mt-0.5 ${
                      cat.type === 'income'
                        ? 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400'
                        : 'bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400'
                    }`}
                  >
                    {cat.type === 'income' ? (isEn ? 'Income' : 'আয়') : isEn ? 'Expense' : 'ব্যয়'}
                  </span>
                </div>
              </div>

              {/* Action Menu */}
              <div className="relative">
                <button
                  onClick={() =>
                    setActiveItemMenuId(activeItemMenuId === cat.id ? null : cat.id)
                  }
                  className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
                  aria-label="Options"
                >
                  <MoreVertical className="w-4 h-4" />
                </button>

                {activeItemMenuId === cat.id && (
                  <div className="absolute right-0 top-8 z-30 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl shadow-xl py-1 w-28 text-xs font-medium animate-in fade-in">
                    <button
                      onClick={() => openEditModal(cat)}
                      className="w-full px-3 py-2 text-left hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2 text-slate-700 dark:text-slate-200"
                    >
                      <Edit2 className="w-3.5 h-3.5 text-slate-400" />
                      <span>{isEn ? 'Edit' : 'এডিট'}</span>
                    </button>
                    <button
                      onClick={() => handleDelete(cat.id)}
                      className="w-full px-3 py-2 text-left hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2 text-rose-500"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>{isEn ? 'Delete' : 'মুছুন'}</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Floating Action Button */}
      <button
        onClick={openAddModal}
        className="fixed bottom-6 right-6 z-40 w-13 h-13 rounded-full bg-blue-600 hover:bg-blue-700 active:scale-95 text-white shadow-xl shadow-blue-500/30 flex items-center justify-center transition-all focus:outline-none"
        title={isEn ? 'Add Category' : 'নতুন ক্যাটাগরি যোগ করুন'}
      >
        <Plus className="w-6 h-6 stroke-[2.5]" />
      </button>

      {/* Add / Edit Category Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-5 shadow-2xl space-y-4 border border-slate-100 dark:border-slate-800 max-h-[90vh] overflow-y-auto">
            <h3 className="text-sm font-bold text-slate-800 dark:text-white text-center">
              {editingCat
                ? isEn
                  ? 'Edit Category'
                  : 'ক্যাটাগরি সম্পাদনা'
                : isEn
                ? 'Create New Category'
                : 'নতুন ক্যাটাগরি তৈরি করুন'}
            </h3>

            {errorMessage && (
              <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 text-xs flex items-center gap-1.5 font-medium">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Type Switcher: Income | Expense */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
                {isEn ? 'Category Type' : 'ক্যাটাগরির ধরন'} *
              </label>
              <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs font-bold text-center">
                <button
                  type="button"
                  onClick={() => {
                    setCategoryType('expense');
                    setSelectedColor('#ef4444');
                  }}
                  className={`py-2 rounded-lg transition-all ${
                    categoryType === 'expense'
                      ? 'bg-rose-500 text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  {isEn ? 'Expense (ব্যয়)' : 'ব্যয় (Expense)'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setCategoryType('income');
                    setSelectedColor('#10b981');
                  }}
                  className={`py-2 rounded-lg transition-all ${
                    categoryType === 'income'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  {isEn ? 'Income (আয়)' : 'আয় (Income)'}
                </button>
              </div>
            </div>

            {/* Category Name Input */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
                {isEn ? 'Category Name' : 'ক্যাটাগরির নাম'} *
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  setErrorMessage(null);
                }}
                placeholder={isEn ? 'e.g. Freelancing, Gym, Tuition' : 'যেমন: টিউশন ফি, জিম খরচ, নাস্তা'}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-xs"
                autoFocus
                required
              />
            </div>

            {/* Color Palette */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1.5">
                {isEn ? 'Select Badge Color' : 'কালার নির্বাচন করুন'}
              </label>
              <div className="flex flex-wrap gap-2">
                {COLOR_PALETTE.map((color) => (
                  <button
                    key={color}
                    type="button"
                    onClick={() => setSelectedColor(color)}
                    className="w-7 h-7 rounded-full flex items-center justify-center transition-transform active:scale-90"
                    style={{ backgroundColor: color }}
                  >
                    {selectedColor === color && (
                      <Check className="w-4 h-4 text-white stroke-[3]" />
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Icon Picker */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1.5">
                {isEn ? 'Select Icon' : 'আইকন নির্বাচন করুন'}
              </label>
              <div className="grid grid-cols-6 gap-2 max-h-32 overflow-y-auto p-1 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-800">
                {AVAILABLE_ICONS.map((iconName) => (
                  <button
                    key={iconName}
                    type="button"
                    onClick={() => setSelectedIcon(iconName)}
                    className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
                      selectedIcon === iconName
                        ? 'bg-blue-600 text-white ring-2 ring-blue-400 shadow-xs'
                        : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100'
                    }`}
                  >
                    {renderCategoryIcon(iconName, selectedIcon === iconName ? '#ffffff' : '#64748b')}
                  </button>
                ))}
              </div>
            </div>

            {/* Buttons: Cancel | Add / Update */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  setIsModalOpen(false);
                  setErrorMessage(null);
                }}
                className="px-4 py-2 text-xs text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 font-semibold"
              >
                {isEn ? 'Cancel' : 'বাতিল'}
              </button>
              <button
                type="button"
                onClick={handleSave}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
              >
                {editingCat ? (isEn ? 'Update' : 'আপডেট') : isEn ? 'Save' : 'সংরক্ষণ করুন'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Pill Toast Banner */}
      {toastMessage && (
        <div className="fixed bottom-10 left-1/2 -translate-x-1/2 bg-white dark:bg-slate-900 border border-emerald-300 dark:border-emerald-700 text-slate-800 dark:text-slate-100 text-xs px-4 py-2.5 rounded-full shadow-xl flex items-center gap-2 animate-in fade-in z-50">
          <CheckCircle2 className="w-4 h-4 text-emerald-500 fill-emerald-500" />
          <span className="font-semibold">{toastMessage}</span>
        </div>
      )}
    </div>
  );
};
