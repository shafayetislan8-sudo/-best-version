import React, { useState, useEffect } from 'react';
import {
  ArrowLeft,
  Users,
  Plus,
  Trash2,
  Check,
  Share2,
  Utensils,
  Calculator,
  Edit2,
  RotateCcw,
  Calendar,
  CheckCircle2,
  X,
  AlertCircle,
  Save,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import {
  formatCurrency,
  toBanglaNumber,
  getTodayString,
  getCurrentTimeString,
} from '../utils/formatters';
import { MessMember, MessRecord } from '../types';

export const MessSplitterScreen: React.FC = () => {
  const { setActiveTab, addTransaction, settings, messRecords, saveMessRecord } = useApp();
  const isEn = settings.language === 'en';

  const now = new Date();
  const [selectedMonth, setSelectedMonth] = useState<number>(now.getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState<number>(now.getFullYear());

  const recordId = `mess_${selectedYear}_${selectedMonth}`;

  const [title, setTitle] = useState('');
  const [totalBazaarCost, setTotalBazaarCost] = useState<number>(0);
  const [calculationMode, setCalculationMode] = useState<'auto' | 'custom'>('auto');
  const [customMealRate, setCustomMealRate] = useState<number>(0);
  const [members, setMembers] = useState<MessMember[]>([]);

  const [copied, setCopied] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [showSyncConfirm, setShowSyncConfirm] = useState(false);

  // Rate Modal states (Requirement 4)
  const [isRateModalOpen, setIsRateModalOpen] = useState(false);
  const [tempMode, setTempMode] = useState<'auto' | 'custom'>('auto');
  const [tempRateInput, setTempRateInput] = useState<string>('');
  const [rateError, setRateError] = useState<string>('');

  // Add Member Modal states
  const [newMemberName, setNewMemberName] = useState('');
  const [newMemberMeals, setNewMemberMeals] = useState('');
  const [newMemberDeposit, setNewMemberDeposit] = useState('');
  const [isAddMemberOpen, setIsAddMemberOpen] = useState(false);

  // Month Names
  const banglaMonths = [
    'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
    'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
  ];
  const englishMonths = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  // Load record whenever selectedMonth or selectedYear changes
  useEffect(() => {
    const existing = messRecords.find((r) => r.month === selectedMonth && r.year === selectedYear);
    if (existing) {
      setTitle(existing.title);
      setTotalBazaarCost(existing.totalBazaarCost || 0);
      setCalculationMode(existing.calculationMode || 'auto');
      setCustomMealRate(existing.customMealRate || 0);
      setMembers(existing.members || []);
    } else {
      const monthLabel = isEn ? englishMonths[selectedMonth - 1] : banglaMonths[selectedMonth - 1];
      const yearLabel = settings.useBanglaNumerals && !isEn ? toBanglaNumber(selectedYear) : selectedYear;
      setTitle(`${monthLabel} ${yearLabel} ${isEn ? 'Mess Account' : 'মেসের হিসাব'}`);
      setTotalBazaarCost(0);
      setCalculationMode('auto');
      setCustomMealRate(0);
      setMembers([]);
    }
  }, [selectedMonth, selectedYear]);

  // Calculations
  const totalMeals = members.reduce((sum, m) => sum + (m.meals || 0), 0);
  const totalDeposit = members.reduce((sum, m) => sum + (m.deposit || 0), 0);
  const autoMealRate = totalMeals > 0 ? totalBazaarCost / totalMeals : 0;
  const effectiveMealRate =
    calculationMode === 'custom' && customMealRate > 0 ? customMealRate : autoMealRate;

  // Persist current month calculation state safely
  const handleSaveCurrentRecord = () => {
    const record: MessRecord = {
      id: recordId,
      month: selectedMonth,
      year: selectedYear,
      title: title.trim() || `${banglaMonths[selectedMonth - 1]} মেসের হিসাব`,
      totalBazaarCost,
      calculationMode,
      customMealRate: calculationMode === 'custom' ? customMealRate : undefined,
      effectiveMealRate,
      members,
      updatedAt: new Date().toISOString(),
    };
    saveMessRecord(record);
    setToastMessage(isEn ? 'Mess account saved successfully!' : 'মেসের হিসাব সফলভাবে সংরক্ষিত হয়েছে!');
    setTimeout(() => setToastMessage(null), 2500);
  };

  const handleOpenRateModal = () => {
    setTempMode(calculationMode);
    setTempRateInput(customMealRate > 0 ? String(customMealRate) : autoMealRate > 0 ? autoMealRate.toFixed(2) : '');
    setRateError('');
    setIsRateModalOpen(true);
  };

  const handleSaveMealRate = (e: React.FormEvent) => {
    e.preventDefault();
    setRateError('');

    if (tempMode === 'custom') {
      const parsedRate = parseFloat(tempRateInput);
      if (isNaN(parsedRate) || parsedRate <= 0) {
        setRateError(isEn ? 'Please enter a valid positive meal rate' : 'অনুগ্রহ করে সঠিক ধনাত্মক মিল রেট লিখুন');
        return;
      }
      setCalculationMode('custom');
      setCustomMealRate(parsedRate);
    } else {
      setCalculationMode('auto');
      setCustomMealRate(0);
    }

    setIsRateModalOpen(false);
    setToastMessage(
      isEn
        ? 'Meal rate updated successfully!'
        : 'মিল রেট সফলভাবে পরিবর্তন করা হয়েছে!'
    );
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleAddMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemberName.trim()) return;

    const newM: MessMember = {
      id: `m_${Date.now()}`,
      name: newMemberName.trim(),
      meals: parseFloat(newMemberMeals) || 0,
      deposit: parseFloat(newMemberDeposit) || 0,
    };

    const updated = [...members, newM];
    setMembers(updated);
    setNewMemberName('');
    setNewMemberMeals('');
    setNewMemberDeposit('');
    setIsAddMemberOpen(false);
  };

  const handleDeleteMember = (id: string) => {
    setMembers((prev) => prev.filter((m) => m.id !== id));
  };

  // Generate WhatsApp formatted summary
  const handleCopySummary = () => {
    let msg = `🍲 *${title}*\n`;
    msg += `------------------------------\n`;
    msg += `${isEn ? 'Total Bazaar Cost' : 'মোট বাজার খরচ'}: ${formatCurrency(
      totalBazaarCost,
      settings.useBanglaNumerals && !isEn
    )}\n`;
    msg += `${isEn ? 'Total Meals' : 'মোট মিল'}: ${
      settings.useBanglaNumerals && !isEn ? toBanglaNumber(totalMeals) : totalMeals
    } ${isEn ? 'Meals' : 'টি'}\n`;
    msg += `${isEn ? 'Effective Meal Rate' : 'মিল রেট'}: ${effectiveMealRate.toFixed(2)} ৳ ${
      calculationMode === 'custom' ? `(${isEn ? 'Custom Rate' : 'নির্ধারিত কাস্টম রেট'})` : `(${isEn ? 'Auto' : 'স্বয়ংক্রিয়'})`
    }\n`;
    msg += `------------------------------\n`;
    msg += `*${isEn ? 'Member Summary:' : 'সদস্যদের হিসাব বিবরণী:'}*\n`;

    members.forEach((m) => {
      const memberCost = m.meals * effectiveMealRate;
      const balance = m.deposit - memberCost;
      const status =
        balance >= 0
          ? `${isEn ? 'Refund' : 'ফেরত পাবে'}: +${Math.round(balance)} ৳ 🟢`
          : `${isEn ? 'Due' : 'দিতে হবে'}: ${Math.round(Math.abs(balance))} ৳ 🔴`;
      msg += `• ${m.name}: ${isEn ? 'Meals' : 'মিল'} ${m.meals}, ${
        isEn ? 'Deposit' : 'জমা'
      } ${m.deposit} ৳ | ${status}\n`;
    });

    msg += `------------------------------\n`;
    msg += isEn
      ? `Prepared by: Income Expense App`
      : `হিসাব প্রস্তুতকারক: আয় ব্যয় ট্র্যাকার অ্যাপ`;

    navigator.clipboard.writeText(msg);
    setCopied(true);
    setToastMessage(isEn ? 'Summary copied to clipboard!' : 'সামারি ক্লিপবোর্ডে কপি হয়েছে!');
    setTimeout(() => {
      setCopied(false);
      setToastMessage(null), 3000;
    });
  };

  const handleSyncToExpense = () => {
    addTransaction({
      type: 'expense',
      amount: totalBazaarCost,
      categoryId: 'cat_food',
      categoryName: isEn ? 'Food & Dining' : 'খাবার ও পানীয়',
      accountId: 'acc_cash',
      accountName: isEn ? 'Cash' : 'নগদ',
      date: getTodayString(),
      time: getCurrentTimeString(),
      note: `${title} (${isEn ? 'Meal rate' : 'মিল রেট'}: ${effectiveMealRate.toFixed(2)} ৳)`,
    });
    setShowSyncConfirm(false);
    setToastMessage(
      isEn
        ? 'Mess cost saved to main expense ledger!'
        : 'মেসের খরচ প্রধান ব্যয় হিসেবে সংরক্ষিত হয়েছে!'
    );
    setTimeout(() => setToastMessage(null), 3000);
  };

  return (
    <div className="space-y-4 pb-24 pt-1">
      {/* Top Header */}
      <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setActiveTab('profile_menu')}
            className="p-1.5 rounded-full text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title={isEn ? 'Back' : 'পেছনে যান'}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <Utensils className="w-5 h-5 text-orange-500" />
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              {isEn ? 'Mess & Meal Splitter' : 'মেস ও শেয়ার্ড মিল স্প্লিটার'}
            </h2>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleSaveCurrentRecord}
            className="border border-emerald-200 dark:border-emerald-800 text-emerald-600 dark:text-emerald-400 bg-emerald-50/40 hover:bg-emerald-50 rounded-xl px-2.5 py-1.5 text-xs font-semibold flex items-center gap-1 transition-colors"
            title={isEn ? 'Save Record' : 'হিসাব সংরক্ষণ করুন'}
          >
            <Save className="w-3.5 h-3.5" />
            <span>{isEn ? 'Save' : 'সংরক্ষণ'}</span>
          </button>

          <button
            onClick={handleCopySummary}
            className="border border-blue-200 dark:border-blue-800 text-blue-600 dark:text-blue-400 bg-blue-50/30 hover:bg-blue-50 dark:hover:bg-blue-950/40 rounded-xl px-2.5 py-1.5 text-xs font-semibold flex items-center gap-1 transition-colors"
            title={isEn ? 'Share Summary' : 'WhatsApp এ শেয়ার করুন'}
          >
            {copied ? (
              <Check className="w-3.5 h-3.5 text-emerald-500" />
            ) : (
              <Share2 className="w-3.5 h-3.5" />
            )}
            <span>{copied ? (isEn ? 'Copied' : 'কপি হয়েছে') : isEn ? 'Share' : 'শেয়ার'}</span>
          </button>
        </div>
      </div>

      {/* Month & Year Selector for Multi-month calculation isolation */}
      <div className="bg-slate-50 dark:bg-slate-800/60 p-2 rounded-2xl flex items-center justify-between border border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700 dark:text-slate-300">
          <Calendar className="w-4 h-4 text-blue-500" />
          <span>{isEn ? 'Account Month:' : 'হিসাবের মাস:'}</span>
        </div>
        <div className="flex items-center gap-2">
          <select
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(Number(e.target.value))}
            className="px-2.5 py-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-bold text-slate-800 dark:text-white focus:outline-none"
          >
            {englishMonths.map((m, idx) => (
              <option key={m} value={idx + 1}>
                {isEn ? m : banglaMonths[idx]}
              </option>
            ))}
          </select>
          <select
            value={selectedYear}
            onChange={(e) => setSelectedYear(Number(e.target.value))}
            className="px-2.5 py-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-bold text-slate-800 dark:text-white focus:outline-none"
          >
            {[2025, 2026, 2027].map((yr) => (
              <option key={yr} value={yr}>
                {settings.useBanglaNumerals && !isEn ? toBanglaNumber(yr) : yr}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main KPI Card: Total Bazaar | Total Meals | Meal Rate */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 border border-slate-100 dark:border-slate-800 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="text-xs font-bold text-slate-800 dark:text-white bg-transparent border-b border-dashed border-slate-300 dark:border-slate-700 focus:outline-none flex-1 mr-2"
          />
          <button
            onClick={() => setShowSyncConfirm(true)}
            className="text-[11px] font-bold text-blue-600 dark:text-blue-400 hover:underline flex-shrink-0"
          >
            {isEn ? '+ Sync to Expense' : '+ ব্যয়ে যুক্ত করুন'}
          </button>
        </div>

        <div className="grid grid-cols-3 gap-2 pt-1 text-center">
          {/* Total Bazaar */}
          <div className="p-2.5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-100 dark:border-amber-900/60">
            <span className="text-[10px] text-amber-700 dark:text-amber-300 font-semibold block">
              {isEn ? 'Total Bazaar' : 'মোট বাজার'}
            </span>
            <input
              type="number"
              value={totalBazaarCost || ''}
              onChange={(e) => setTotalBazaarCost(parseFloat(e.target.value) || 0)}
              placeholder="0"
              className="w-full text-center text-sm font-bold bg-transparent text-amber-900 dark:text-amber-100 focus:outline-none"
            />
          </div>

          {/* Total Meals */}
          <div className="p-2.5 rounded-2xl bg-blue-50 dark:bg-blue-950/40 border border-blue-100 dark:border-blue-900/60">
            <span className="text-[10px] text-blue-700 dark:text-blue-300 font-semibold block">
              {isEn ? 'Total Meals' : 'মোট মিল'}
            </span>
            <span className="text-sm font-bold text-blue-900 dark:text-blue-100 block">
              {settings.useBanglaNumerals && !isEn ? toBanglaNumber(totalMeals) : totalMeals}
            </span>
          </div>

          {/* Meal Rate with Edit Rate button (Requirement 4) */}
          <div
            onClick={handleOpenRateModal}
            className="p-2.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/80 cursor-pointer hover:bg-emerald-100/60 transition-all group relative"
            title={isEn ? 'Click to change meal rate' : 'মিল রেট পরিবর্তন করতে ক্লিক করুন'}
          >
            <div className="flex items-center justify-center gap-1">
              <span className="text-[10px] text-emerald-700 dark:text-emerald-300 font-semibold block">
                {isEn ? 'Meal Rate' : 'মিল রেট'}
              </span>
              <Edit2 className="w-2.5 h-2.5 text-emerald-600 dark:text-emerald-400 group-hover:scale-125 transition-transform" />
            </div>
            <span className="text-sm font-bold text-emerald-900 dark:text-emerald-100 block">
              {effectiveMealRate.toFixed(2)} ৳
            </span>
            <span className="text-[9px] font-bold text-emerald-600 dark:text-emerald-400 block">
              {calculationMode === 'custom' ? (isEn ? '• Custom' : '• কাস্টম রেট') : (isEn ? '• Auto' : '• স্বয়ংক্রিয়')}
            </span>
          </div>
        </div>

        {/* Change Meal Rate Bar */}
        <div className="flex items-center justify-between pt-1 border-t border-slate-100 dark:border-slate-800 text-[11px]">
          <span className="text-slate-500 dark:text-slate-400">
            {calculationMode === 'custom'
              ? (isEn ? `Custom rate is active: ${effectiveMealRate.toFixed(2)} ৳` : `কাস্টম মিল রেট কার্যকর: ${effectiveMealRate.toFixed(2)} ৳`)
              : (isEn ? `Auto rate: total bazaar ÷ total meals` : `স্বয়ংক্রিয় রেট: মোট বাজার ÷ মোট মিল`)}
          </span>
          <button
            type="button"
            onClick={handleOpenRateModal}
            className="font-bold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1"
          >
            <Edit2 className="w-3 h-3" />
            <span>{isEn ? 'Change Rate' : 'মিল রেট পরিবর্তন'}</span>
          </button>
        </div>
      </div>

      {/* Members List */}
      <div className="space-y-2.5 px-1">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-slate-700 dark:text-slate-300">
            {isEn
              ? `Member Accounts (${members.length})`
              : `মেম্বারদের হিসাব (${members.length} জন)`}
          </h3>
          <button
            onClick={() => setIsAddMemberOpen(true)}
            className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:text-blue-700 flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{isEn ? 'Add Member' : 'নতুন মেম্বার'}</span>
          </button>
        </div>

        {members.length === 0 ? (
          <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 text-xs text-slate-400 space-y-2">
            <Users className="w-8 h-8 mx-auto text-slate-300 dark:text-slate-600" />
            <p>{isEn ? 'No members added yet for this month.' : 'এই মাসে এখনো কোনো মেম্বার যোগ করা হয়নি।'}</p>
            <button
              onClick={() => setIsAddMemberOpen(true)}
              className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline"
            >
              {isEn ? '+ Add First Member' : '+ প্রথম মেম্বার যোগ করুন'}
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            {members.map((m) => {
              const memberCost = m.meals * effectiveMealRate;
              const balance = m.deposit - memberCost;
              const isRefund = balance >= 0;

              return (
                <div
                  key={m.id}
                  className="p-3.5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-xs flex items-center justify-between hover:border-slate-300 dark:hover:border-slate-700 transition-colors"
                >
                  <div className="space-y-0.5">
                    <h4 className="text-xs font-bold text-slate-800 dark:text-white">
                      {m.name}
                    </h4>
                    <p className="text-[10px] text-slate-400">
                      {isEn ? 'Meals' : 'মিল'}:{' '}
                      {settings.useBanglaNumerals && !isEn ? toBanglaNumber(m.meals) : m.meals} |{' '}
                      {isEn ? 'Deposit' : 'জমা'}:{' '}
                      {formatCurrency(m.deposit, settings.useBanglaNumerals && !isEn)}
                    </p>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 block">
                        {isEn ? 'Cost' : 'খরচ'}: {Math.round(memberCost)} ৳
                      </span>
                      <span
                        className={`text-xs font-bold ${
                          isRefund
                            ? 'text-emerald-600 dark:text-emerald-400'
                            : 'text-rose-600 dark:text-rose-400'
                        }`}
                      >
                        {isRefund ? (isEn ? 'Refund: +' : 'পাবে: +') : isEn ? 'Due: -' : 'দিবে: -'}{' '}
                        {formatCurrency(
                          Math.abs(Math.round(balance)),
                          settings.useBanglaNumerals && !isEn
                        )}
                      </span>
                    </div>

                    <button
                      onClick={() => handleDeleteMember(m.id)}
                      className="p-1 text-slate-400 hover:text-rose-500 rounded-lg transition-colors"
                      title={isEn ? 'Remove member' : 'মুছে ফেলুন'}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Change Meal Rate Modal (Requirement 4) */}
      {isRateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-5 shadow-2xl space-y-4 border border-slate-100 dark:border-slate-800">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2.5">
              <div className="flex items-center gap-2">
                <Calculator className="w-4 h-4 text-orange-500" />
                <h3 className="text-sm font-bold text-slate-800 dark:text-white">
                  {isEn ? 'Change Meal Rate' : 'মিল রেট পরিবর্তন করুন'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsRateModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {rateError && (
              <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 text-xs font-semibold flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{rateError}</span>
              </div>
            )}

            <form onSubmit={handleSaveMealRate} className="space-y-3.5">
              {/* Mode Selection */}
              <div className="space-y-2">
                <label className="text-[11px] font-bold text-slate-500 dark:text-slate-400 block">
                  {isEn ? 'Calculation Mode' : 'রেট গণনার পদ্ধতি'}
                </label>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setTempMode('auto');
                      setRateError('');
                    }}
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      tempMode === 'auto'
                        ? 'border-blue-500 bg-blue-50 dark:bg-blue-950/50 text-blue-700 dark:text-blue-300 font-bold'
                        : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    <span className="text-xs block">{isEn ? 'Auto Rate' : 'স্বয়ংক্রিয় রেট'}</span>
                    <span className="text-[10px] opacity-75 font-normal block">
                      {autoMealRate.toFixed(2)} ৳ / মিল
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setTempMode('custom');
                      setRateError('');
                    }}
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      tempMode === 'custom'
                        ? 'border-orange-500 bg-orange-50 dark:bg-orange-950/50 text-orange-700 dark:text-orange-300 font-bold'
                        : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    <span className="text-xs block">{isEn ? 'Custom Rate' : 'কাস্টম রেট'}</span>
                    <span className="text-[10px] opacity-75 font-normal block">
                      {isEn ? 'Enter manually' : 'নিজের পছন্দমতো'}
                    </span>
                  </button>
                </div>
              </div>

              {/* Custom Rate Input */}
              {tempMode === 'custom' && (
                <div className="space-y-1 animate-in fade-in">
                  <label className="text-[11px] font-bold text-slate-600 dark:text-slate-300 block">
                    {isEn ? 'Enter Custom Meal Rate (৳)' : 'নতুন মিল রেট লিখুন (টাকা / মিল) *'}
                  </label>
                  <div className="relative flex items-center">
                    <span className="absolute left-3 text-sm font-bold text-slate-400">৳</span>
                    <input
                      type="number"
                      step="any"
                      value={tempRateInput}
                      onChange={(e) => {
                        setTempRateInput(e.target.value);
                        setRateError('');
                      }}
                      placeholder="e.g. 55.00"
                      className="w-full pl-8 pr-3 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-bold text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-orange-500"
                      autoFocus
                      required
                    />
                  </div>
                  <p className="text-[10px] text-slate-400 pt-0.5">
                    {isEn
                      ? 'All member bills and due/refund will calculate based on this rate.'
                      : 'নতুন রেট অনুযায়ী সকল মেম্বারের খরচ ও বকেয়া/ফেরত হিসাব হবে।'}
                  </p>
                </div>
              )}

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsRateModalOpen(false)}
                  className="px-3.5 py-2 text-xs font-semibold text-slate-500 hover:text-slate-700"
                >
                  {isEn ? 'Cancel' : 'বাতিল'}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
                >
                  {isEn ? 'Save Rate' : 'রেট সংরক্ষণ করুন'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Member Modal */}
      {isAddMemberOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-5 shadow-2xl space-y-3 border border-slate-100 dark:border-slate-800 animate-in fade-in">
            <h3 className="text-xs font-bold text-slate-800 dark:text-white">
              {isEn ? 'Add Member' : 'মেম্বার যোগ করুন'}
            </h3>
            <input
              type="text"
              value={newMemberName}
              onChange={(e) => setNewMemberName(e.target.value)}
              placeholder={isEn ? 'Member name' : 'মেম্বারের নাম'}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
              autoFocus
            />
            <div className="grid grid-cols-2 gap-2">
              <input
                type="number"
                step="any"
                value={newMemberMeals}
                onChange={(e) => setNewMemberMeals(e.target.value)}
                placeholder={isEn ? 'Total meals' : 'মোট মিল'}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <input
                type="number"
                step="any"
                value={newMemberDeposit}
                onChange={(e) => setNewMemberDeposit(e.target.value)}
                placeholder={isEn ? 'Deposit amount' : 'জমা টাকা'}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsAddMemberOpen(false)}
                className="px-3 py-1.5 text-xs text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
              >
                {isEn ? 'Cancel' : 'বাতিল'}
              </button>
              <button
                type="button"
                onClick={handleAddMember}
                className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-colors shadow-xs"
              >
                {isEn ? 'Add' : 'যোগ করুন'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Sync To Expense Confirmation Modal */}
      {showSyncConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-xs bg-white dark:bg-slate-900 rounded-3xl p-5 shadow-2xl space-y-4 border border-slate-100 dark:border-slate-800 animate-in fade-in">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-blue-50 dark:bg-blue-950/60 text-blue-600 flex items-center justify-center flex-shrink-0">
                <Utensils className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-800 dark:text-white">
                  {isEn ? 'Sync to Expenses?' : 'ব্যয়ে যুক্ত করতে চান?'}
                </h3>
                <p className="text-[11px] text-slate-400">
                  {isEn
                    ? `Add ${formatCurrency(totalBazaarCost, false)} to main expense list as Food & Dining.`
                    : `মেসের বাজার খরচ (${formatCurrency(totalBazaarCost, settings.useBanglaNumerals)}) প্রধান খরচে যুক্ত হবে।`}
                </p>
              </div>
            </div>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowSyncConfirm(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200"
              >
                {isEn ? 'Cancel' : 'বাতিল'}
              </button>
              <button
                onClick={handleSyncToExpense}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
              >
                {isEn ? 'Confirm & Add' : 'হ্যাঁ, যুক্ত করুন'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Pill Toast Banner */}
      {toastMessage && (
        <div className="fixed bottom-10 left-1/2 -translate-x-1/2 bg-white dark:bg-slate-900 border border-emerald-300 dark:border-emerald-700 text-slate-800 dark:text-slate-100 text-xs px-4 py-2.5 rounded-full shadow-xl flex items-center gap-2 animate-in fade-in z-50">
          <CheckCircle2 className="w-4 h-4 text-emerald-500 fill-emerald-500 shrink-0" />
          <span className="font-semibold">{toastMessage}</span>
        </div>
      )}
    </div>
  );
};
