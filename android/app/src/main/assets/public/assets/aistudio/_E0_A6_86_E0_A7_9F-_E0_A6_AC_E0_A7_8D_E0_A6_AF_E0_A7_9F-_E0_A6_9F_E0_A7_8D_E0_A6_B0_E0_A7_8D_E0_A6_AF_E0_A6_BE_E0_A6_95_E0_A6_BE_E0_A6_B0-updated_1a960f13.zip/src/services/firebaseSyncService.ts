import {
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  User,
} from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  deleteDoc,
  writeBatch,
  onSnapshot,
} from 'firebase/firestore';
import { auth, db, googleProvider, handleFirestoreError, OperationType } from '../firebase';
import {
  Transaction,
  Account,
  PersonRecord,
  BudgetItem,
  SavingsGoal,
  TaskItem,
  RecurringItem,
  AppSettings,
  Category,
} from '../types';

export interface CloudUserData {
  settings?: Partial<AppSettings>;
  transactions?: Transaction[];
  categories?: Category[];
  accounts?: Account[];
  persons?: PersonRecord[];
  budgets?: BudgetItem[];
  savings?: SavingsGoal[];
  tasks?: TaskItem[];
  recurring?: RecurringItem[];
  notes?: any[];
  trash?: any[];
  lastSyncedAt?: string;
}

export const firebaseAuthService = {
  onAuthChange(callback: (user: User | null) => void) {
    return onAuthStateChanged(auth, callback);
  },

  async loginWithGoogle(): Promise<User> {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      return result.user;
    } catch (error) {
      console.error('Google Sign-In Error:', error);
      throw error;
    }
  },

  async logout(): Promise<void> {
    try {
      await signOut(auth);
    } catch (error) {
      console.error('Logout Error:', error);
      throw error;
    }
  },

  getCurrentUser(): User | null {
    return auth.currentUser;
  },
};

export const firestoreSyncService = {
  /** Subscribe to live changes from this user's Firestore documents and collections. */
  subscribeUserData(
    userId: string,
    onData: (patch: Partial<CloudUserData>) => void,
    onError?: (error: Error) => void,
  ): () => void {
    const unsubscribers: Array<() => void> = [];
    const reportError = (error: unknown, path: string) => {
      console.error(`Firestore live sync failed at ${path}:`, error);
      onError?.(error instanceof Error ? error : new Error(String(error)));
    };

    unsubscribers.push(onSnapshot(
      doc(db, 'users', userId),
      (snapshot) => {
        const data = snapshot.exists() ? snapshot.data() : {};
        onData({
          ...(data.settings ? { settings: data.settings as Partial<AppSettings> } : {}),
          ...(data.updatedAt ? { lastSyncedAt: String(data.updatedAt) } : {}),
        });
      },
      (error) => reportError(error, `users/${userId}`),
    ));

    const collectionMap: Record<string, keyof CloudUserData> = {
      transactions: 'transactions', categories: 'categories', accounts: 'accounts',
      persons: 'persons', budgets: 'budgets', savings: 'savings', tasks: 'tasks',
      notes: 'notes', recurring: 'recurring', trash: 'trash',
    };
    for (const [subcollection, resultKey] of Object.entries(collectionMap)) {
      unsubscribers.push(onSnapshot(
        collection(db, 'users', userId, subcollection),
        (snapshot) => {
          const items = snapshot.docs.map((item) => ({ ...item.data(), id: item.id }));
          onData({ [resultKey]: items } as Partial<CloudUserData>);
        },
        (error) => reportError(error, `users/${userId}/${subcollection}`),
      ));
    }

    return () => unsubscribers.forEach((unsubscribe) => unsubscribe());
  },
  /**
   * Save individual document to user's collection
   */
  async saveDoc(userId: string, subcollection: string, docId: string, data: any): Promise<void> {
    const path = `users/${userId}/${subcollection}/${docId}`;
    try {
      const docRef = doc(db, 'users', userId, subcollection, docId);
      await setDoc(docRef, { ...data, userId }, { merge: true });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },

  /**
   * Delete individual document from user's collection
   */
  async deleteDoc(userId: string, subcollection: string, docId: string): Promise<void> {
    const path = `users/${userId}/${subcollection}/${docId}`;
    try {
      const docRef = doc(db, 'users', userId, subcollection, docId);
      await deleteDoc(docRef);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  },

  /**
   * Save user profile and global settings
   */
  async saveUserSettings(userId: string, settings: AppSettings): Promise<void> {
    const path = `users/${userId}`;
    try {
      const userRef = doc(db, 'users', userId);
      await setDoc(
        userRef,
        {
          uid: userId,
          settings,
          updatedAt: new Date().toISOString(),
        },
        { merge: true }
      );
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },

  /**
   * Fetch all user data from cloud Firestore
   */
  async fetchAllUserData(userId: string): Promise<CloudUserData> {
    const result: CloudUserData = {};

    // 1. Get user document (settings)
    const userPath = `users/${userId}`;
    try {
      const userDocSnap = await getDoc(doc(db, 'users', userId));
      if (userDocSnap.exists()) {
        const data = userDocSnap.data();
        if (data.settings) result.settings = data.settings;
        if (data.updatedAt) result.lastSyncedAt = data.updatedAt;
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, userPath);
    }

    // Subcollections to fetch
    const subcollections = [
      'transactions',
      'categories',
      'accounts',
      'persons',
      'budgets',
      'savings',
      'tasks',
      'notes',
      'recurring',
      'trash',
    ] as const;

    for (const sub of subcollections) {
      const colPath = `users/${userId}/${sub}`;
      try {
        const snap = await getDocs(collection(db, 'users', userId, sub));
        const items = snap.docs.map((d) => d.data());
        if (sub === 'transactions') result.transactions = items as Transaction[];
        if (sub === 'categories') result.categories = items as Category[];
        if (sub === 'accounts') result.accounts = items as Account[];
        if (sub === 'persons') result.persons = items as PersonRecord[];
        if (sub === 'budgets') result.budgets = items as BudgetItem[];
        if (sub === 'savings') result.savings = items as SavingsGoal[];
        if (sub === 'tasks') result.tasks = items as TaskItem[];
        if (sub === 'notes') result.notes = items;
        if (sub === 'recurring') result.recurring = items as RecurringItem[];
        if (sub === 'trash') result.trash = items;
      } catch (error) {
        handleFirestoreError(error, OperationType.LIST, colPath);
      }
    }

    return result;
  },

  /**
   * Full backup / push of all local data to cloud Firestore
   */
  async uploadAllData(
    userId: string,
    data: {
      settings: AppSettings;
      transactions: Transaction[];
      categories?: Category[];
      accounts: Account[];
      persons: PersonRecord[];
      budgets: BudgetItem[];
      savings: SavingsGoal[];
      tasks: TaskItem[];
      recurring: RecurringItem[];
      notes?: any[];
      trash?: any[];
    }
  ): Promise<void> {
    // 1. Save user settings doc
    await this.saveUserSettings(userId, data.settings);

    // 2. Batch write helper to avoid exceeding 500 operations per batch
    let batch = writeBatch(db);
    let opCount = 0;

    // A Firestore WriteBatch must not be reused after commit. Create a fresh
    // batch after each commit so large backups do not replay old writes.
    const commitBatchIfFull = async () => {
      if (opCount >= 400) {
        await batch.commit();
        batch = writeBatch(db);
        opCount = 0;
      }
    };

    // Upload transactions
    for (const tx of data.transactions) {
      const ref = doc(db, 'users', userId, 'transactions', tx.id);
      batch.set(ref, { ...tx, userId }, { merge: true });
      opCount++;
      await commitBatchIfFull();
    }

    // Upload custom/default categories so another device restores the same setup.
    for (const category of data.categories || []) {
      const ref = doc(db, 'users', userId, 'categories', category.id);
      batch.set(ref, { ...category, userId }, { merge: true });
      opCount++;
      await commitBatchIfFull();
    }

    // Upload accounts
    for (const acc of data.accounts) {
      const ref = doc(db, 'users', userId, 'accounts', acc.id);
      batch.set(ref, { ...acc, userId }, { merge: true });
      opCount++;
      await commitBatchIfFull();
    }

    // Upload persons
    for (const person of data.persons) {
      const ref = doc(db, 'users', userId, 'persons', person.id);
      batch.set(ref, { ...person, userId }, { merge: true });
      opCount++;
      await commitBatchIfFull();
    }

    // Upload budgets
    for (const b of data.budgets) {
      const ref = doc(db, 'users', userId, 'budgets', b.id);
      batch.set(ref, { ...b, userId }, { merge: true });
      opCount++;
      await commitBatchIfFull();
    }

    // Upload savings
    for (const s of data.savings) {
      const ref = doc(db, 'users', userId, 'savings', s.id);
      batch.set(ref, { ...s, userId }, { merge: true });
      opCount++;
      await commitBatchIfFull();
    }

    // Upload tasks
    for (const t of data.tasks) {
      const ref = doc(db, 'users', userId, 'tasks', t.id);
      batch.set(ref, { ...t, userId }, { merge: true });
      opCount++;
      await commitBatchIfFull();
    }

    // Upload recurring
    for (const r of data.recurring) {
      const ref = doc(db, 'users', userId, 'recurring', r.id);
      batch.set(ref, { ...r, userId }, { merge: true });
      opCount++;
      await commitBatchIfFull();
    }

    // Upload notes
    if (data.notes && Array.isArray(data.notes)) {
      for (const n of data.notes) {
        if (n && n.id) {
          const ref = doc(db, 'users', userId, 'notes', n.id);
          batch.set(ref, { ...n, userId }, { merge: true });
          opCount++;
          await commitBatchIfFull();
        }
      }
    }

    // Upload the recycle bin so deleted items remain recoverable across devices.
    for (const item of data.trash || []) {
      if (!item?.id) continue;
      const ref = doc(db, 'users', userId, 'trash', item.id);
      batch.set(ref, { ...item, userId }, { merge: true });
      opCount++;
      await commitBatchIfFull();
    }

    if (opCount > 0) {
      try {
        await batch.commit();
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, `users/${userId}`);
      }
    }
  },
};
