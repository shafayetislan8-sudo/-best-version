import React, { useState } from 'react';
import {
  ArrowLeft,
  Search,
  Plus,
  MoreVertical,
  CheckCircle2,
  Edit2,
  Trash2,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Category } from '../types';

export const CategoriesScreen: React.FC = () => {
  const { categories, addCategory, updateCategory, deleteCategory, setActiveTab, settings } = useApp();
  const isEn = settings.language === 'en';

  const [search, setSearch] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCat, setEditingCat] = useState<Category | null>(null);
  const [activeItemMenuId, setActiveItemMenuId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Form states: আয় | ব্যয় | উভয়
  const [categoryType, setCategoryType] = useState<'income' | 'expense' | 'both'>('both');
  const [name, setName] = useState('');

  const filtered = categories.filter((c) => {
    const q = search.toLowerCase();
    return c.name.toLowerCase().includes(q) || (c.nameEn && c.nameEn.toLowerCase().includes(q));
  });

  const openAddModal = () => {
    setEditingCat(null);
    setName('');
    setCategoryType('both');
    setIsModalOpen(true);
  };

  const openEditModal = (cat: Category) => {
    setEditingCat(cat);
    setName(isEn ? (cat.nameEn || cat.name) : cat.name);
    setCategoryType((cat.type as any) || 'both');
    setActiveItemMenuId(null);
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    if (editingCat) {
      updateCategory(editingCat.id, {
        name: name.trim(),
        nameEn: name.trim(),
        type: categoryType === 'both' ? 'expense' : categoryType,
      });
      setToastMessage(isEn ? 'Category updated successfully' : 'ক্যাটাগরি আপডেট করা হয়েছে');
    } else {
      addCategory({
        name: name.trim(),
        nameEn: name.trim(),
        type: categoryType === 'both' ? 'expense' : categoryType,
        icon: 'Tag',
        color: '#2563eb',
      });
      setToastMessage(isEn ? 'Category added successfully' : 'ক্যাটাগরি যোগ করা হয়েছে');
    }

    setIsModalOpen(false);
    setName('');
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleDelete = (id: string) => {
    deleteCategory(id);
    setActiveItemMenuId(null);
    setToastMessage(isEn ? 'Category moved to trash' : 'ক্যাটাগরি মুছে ফেলা হয়েছে');
    setTimeout(() => setToastMessage(null), 3000);
  };

  return (
    <div className="space-y-4 pb-20 pt-1">
      {/* Header */}
      <div className="flex items-center gap-3 py-2 border-b border-slate-100 dark:border-slate-800">
        <button
          onClick={() => setActiveTab('dashboard')}
          className="p-1 rounded-full text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          title={isEn ? 'Back' : 'পেছনে যান'}
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h2 className="text-base font-bold text-slate-900 dark:text-white">
          {isEn ? 'Categories' : 'ক্যাটাগরি'}
        </h2>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={isEn ? 'Search categories...' : 'ক্যাটাগরি খুঁজুন...'}
          className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs focus:outline-none shadow-xs text-slate-800 dark:text-slate-100 placeholder:text-slate-400"
        />
      </div>

      {/* Empty State / Categories List */}
      {filtered.length === 0 ? (
        <div className="py-24 flex flex-col items-center justify-center text-center">
          <div className="text-slate-300 dark:text-slate-600 mb-3">
            <svg
              className="w-16 h-16"
              viewBox="0 0 48 48"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <polygon points="24 6 36 22 12 22" />
              <circle cx="16" cy="34" r="8" />
              <rect x="26" y="26" width="16" height="16" rx="2" />
            </svg>
          </div>
          <p className="text-xs font-medium text-slate-400 dark:text-slate-500">
            {isEn ? 'No categories found' : 'কোন ক্যাটাগরি নেই'}
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map((cat) => (
            <div
              key={cat.id}
              className="p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-xs flex items-center justify-between relative hover:border-slate-300 dark:hover:border-slate-700 transition-colors"
            >
              {/* Drag Handle `=` + Name */}
              <div className="flex items-center gap-3">
                <span className="text-slate-400 font-bold text-base leading-none select-none">
                  =
                </span>
                <span className="text-xs font-semibold text-slate-800 dark:text-white">
                  {isEn ? (cat.nameEn || cat.name) : cat.name}
                </span>
                {cat.type && (
                  <span
                    className={`text-[9px] px-1.5 py-0.5 rounded-md font-bold uppercase ${
                      cat.type === 'income'
                        ? 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400'
                        : 'bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400'
                    }`}
                  >
                    {cat.type === 'income' ? (isEn ? 'Income' : 'আয়') : isEn ? 'Expense' : 'ব্যয়'}
                  </span>
                )}
              </div>

              {/* Three dots ⋮ */}
              <button
                onClick={() =>
                  setActiveItemMenuId(activeItemMenuId === cat.id ? null : cat.id)
                }
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                aria-label="Options"
              >
                <MoreVertical className="w-4 h-4" />
              </button>

              {/* Dropdown Menu on Category Item: Edit & Delete */}
              {activeItemMenuId === cat.id && (
                <div className="absolute right-3 top-10 z-30 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl shadow-xl py-1 w-32 text-xs font-medium animate-in fade-in">
                  <button
                    onClick={() => openEditModal(cat)}
                    className="w-full px-3 py-2 text-left hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2 text-slate-700 dark:text-slate-200"
                  >
                    <Edit2 className="w-3.5 h-3.5 text-slate-400" />
                    <span>{isEn ? 'Edit' : 'এডিট'}</span>
                  </button>
                  <button
                    onClick={() => handleDelete(cat.id)}
                    className="w-full px-3 py-2 text-left hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2 text-rose-500"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>{isEn ? 'Delete' : 'ডিলিট'}</span>
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Floating Action Button */}
      <button
        onClick={openAddModal}
        className="fixed bottom-6 right-6 z-40 w-14 h-14 rounded-full bg-[#1877f2] hover:bg-blue-600 active:scale-95 text-white shadow-xl shadow-blue-500/30 flex items-center justify-center transition-all focus:outline-none"
        title={isEn ? 'Add Category' : 'নতুন ক্যাটাগরি যোগ করুন'}
      >
        <Plus className="w-7 h-7 stroke-[2.5]" />
      </button>

      {/* Add / Edit Category Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-xs bg-white dark:bg-slate-900 rounded-3xl p-5 shadow-2xl space-y-4 border border-slate-100 dark:border-slate-800">
            <h3 className="text-sm font-bold text-slate-800 dark:text-white text-center">
              {editingCat
                ? isEn
                  ? 'Edit Category'
                  : 'ক্যাটাগরি এডিট'
                : isEn
                ? 'New Category'
                : 'নতুন ক্যাটাগরি'}
            </h3>

            {/* Segmented Switcher: Income | Expense | Both */}
            <div className="grid grid-cols-3 gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs font-bold text-center">
              <button
                type="button"
                onClick={() => setCategoryType('income')}
                className={`py-1.5 rounded-lg transition-all ${
                  categoryType === 'income'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                {isEn ? 'Income' : 'আয়'}
              </button>
              <button
                type="button"
                onClick={() => setCategoryType('expense')}
                className={`py-1.5 rounded-lg transition-all ${
                  categoryType === 'expense'
                    ? 'bg-rose-500 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                {isEn ? 'Expense' : 'ব্যয়'}
              </button>
              <button
                type="button"
                onClick={() => setCategoryType('both')}
                className={`py-1.5 rounded-lg transition-all ${
                  categoryType === 'both'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                {isEn ? 'Both' : 'উভয়'}
              </button>
            </div>

            {/* Input field */}
            <div>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={isEn ? 'Enter category name' : 'ক্যাটাগরির নাম লিখুন'}
                className="w-full px-3.5 py-2.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-xs"
                autoFocus
                required
              />
            </div>

            {/* Buttons: Cancel | Add / Update */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-3 py-1.5 text-xs text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 font-semibold"
              >
                {isEn ? 'Cancel' : 'বাতিল'}
              </button>
              <button
                type="button"
                onClick={handleSave}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
              >
                {editingCat ? (isEn ? 'Update' : 'আপডেট') : isEn ? 'Add' : 'অ্যাড'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Pill Toast Banner */}
      {toastMessage && (
        <div className="fixed bottom-10 left-1/2 -translate-x-1/2 bg-white dark:bg-slate-900 border border-emerald-300 dark:border-emerald-700 text-slate-800 dark:text-slate-100 text-xs px-4 py-2.5 rounded-full shadow-xl flex items-center gap-2 animate-in fade-in z-50">
          <CheckCircle2 className="w-4 h-4 text-emerald-500 fill-emerald-500" />
          <span className="font-semibold">{toastMessage}</span>
        </div>
      )}
    </div>
  );
};
