import React, { useState } from 'react';
import { X, ArrowRight, Wallet, Check, AlertCircle } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatCurrency, toBanglaNumber, getTodayString, getCurrentTimeString } from '../utils/formatters';

interface WalletTransferModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WalletTransferModal: React.FC<WalletTransferModalProps> = ({ isOpen, onClose }) => {
  const { accounts, transferBetweenAccounts, settings } = useApp();
  const isEn = settings.language === 'en';

  const [fromAccountId, setFromAccountId] = useState(accounts[0]?.id || '');
  const [toAccountId, setToAccountId] = useState(accounts[1]?.id || accounts[0]?.id || '');
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  if (!isOpen) return null;

  const handleTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount);

    if (isNaN(numAmount) || numAmount <= 0) {
      setError(isEn ? 'Please enter a valid amount' : 'সঠিক পরিমাণ লিখুন');
      return;
    }

    if (fromAccountId === toAccountId) {
      setError(isEn ? 'Cannot transfer to the same account' : 'একই অ্যাকাউন্টে ট্রান্সফার সম্ভব নয়');
      return;
    }

    transferBetweenAccounts(
      fromAccountId,
      toAccountId,
      numAmount,
      getTodayString(),
      getCurrentTimeString(),
      note.trim() || (isEn ? 'Account Balance Transfer' : 'অ্যাকাউন্ট ব্যালেন্স ট্রান্সফার')
    );

    setSuccess(true);
    setTimeout(() => {
      setSuccess(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
      <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-5 shadow-2xl space-y-4 border border-slate-100 dark:border-slate-800">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-blue-50 dark:bg-blue-950/60 flex items-center justify-center text-blue-600 dark:text-blue-400">
              <Wallet className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-800 dark:text-white">
                {isEn ? 'Wallet & Balance Transfer' : 'ওয়ালেট ও ট্রান্সফার'}
              </h3>
              <p className="text-[10px] text-slate-400">
                {isEn ? 'Transfer funds between your accounts' : 'এক অ্যাকাউন্ট থেকে অন্য অ্যাকাউন্টে টাকা স্থানান্তর'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
            title={isEn ? 'Close' : 'বন্ধ করুন'}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Existing Accounts & Balances */}
        <div className="space-y-1.5">
          <label className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
            {isEn ? 'Your Accounts & Wallets' : 'আপনার অ্যাকাউন্টসমূহ'}
          </label>
          <div className="grid grid-cols-2 gap-2">
            {accounts.map((acc) => (
              <div
                key={acc.id}
                className="p-2.5 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 space-y-0.5"
              >
                <span className="text-[10px] text-slate-500 dark:text-slate-400 font-medium block truncate">
                  {acc.name}
                </span>
                <span className="text-xs font-bold text-slate-800 dark:text-white block">
                  {formatCurrency(acc.currentBalance, settings.useBanglaNumerals && !isEn)}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Transfer Form */}
        <form onSubmit={handleTransfer} className="space-y-3 pt-1">
          {error && (
            <div className="p-2 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-600 dark:text-rose-400 text-xs flex items-center gap-1.5 font-medium">
              <AlertCircle className="w-3.5 h-3.5" />
              <span>{error}</span>
            </div>
          )}

          {success && (
            <div className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 text-emerald-600 dark:text-emerald-400 text-xs flex items-center gap-1.5 font-bold">
              <Check className="w-4 h-4" />
              <span>{isEn ? 'Transfer successful!' : 'স্থানান্তর সফল হয়েছে!'}</span>
            </div>
          )}

          {/* From -> To Account Selectors */}
          <div className="flex items-center gap-2">
            {/* From */}
            <div className="flex-1 space-y-1">
              <label className="text-[10px] text-slate-400 font-medium">{isEn ? 'From Account' : 'যেখান থেকে (From)'}</label>
              <select
                value={fromAccountId}
                onChange={(e) => {
                  setFromAccountId(e.target.value);
                  setError('');
                }}
                className="w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-800 dark:text-slate-100 focus:outline-none"
              >
                {accounts.map((acc) => (
                  <option key={acc.id} value={acc.id}>
                    {acc.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="pt-4 text-slate-400">
              <ArrowRight className="w-4 h-4" />
            </div>

            {/* To */}
            <div className="flex-1 space-y-1">
              <label className="text-[10px] text-slate-400 font-medium">{isEn ? 'To Account' : 'যেখানে পাঠাবেন (To)'}</label>
              <select
                value={toAccountId}
                onChange={(e) => {
                  setToAccountId(e.target.value);
                  setError('');
                }}
                className="w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-800 dark:text-slate-100 focus:outline-none"
              >
                {accounts.map((acc) => (
                  <option key={acc.id} value={acc.id}>
                    {acc.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Amount */}
          <div className="space-y-1">
            <label className="text-[10px] text-slate-400 font-medium">{isEn ? 'Amount' : 'টাকার পরিমাণ'}</label>
            <div className="relative flex items-center">
              <input
                type="number"
                value={amount}
                onChange={(e) => {
                  setAmount(e.target.value);
                  setError('');
                }}
                placeholder="0.00"
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
              <span className="absolute right-3 text-xs font-bold text-slate-400">
                {settings.currencySymbol}
              </span>
            </div>
          </div>

          {/* Note */}
          <div className="space-y-1">
            <label className="text-[10px] text-slate-400 font-medium">{isEn ? 'Note (Optional)' : 'নোট / বিবরণ (ঐচ্ছিক)'}</label>
            <input
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder={isEn ? 'e.g. Bank to bKash Cash In' : 'যেমন: ব্যাংক থেকে বিকাশ ক্যাশ-ইন'}
              className="w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none"
            />
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center justify-center gap-1.5"
          >
            <span>{isEn ? 'Complete Transfer' : 'স্থানান্তর সম্পন্ন করুন'}</span>
          </button>
        </form>
      </div>
    </div>
  );
};
