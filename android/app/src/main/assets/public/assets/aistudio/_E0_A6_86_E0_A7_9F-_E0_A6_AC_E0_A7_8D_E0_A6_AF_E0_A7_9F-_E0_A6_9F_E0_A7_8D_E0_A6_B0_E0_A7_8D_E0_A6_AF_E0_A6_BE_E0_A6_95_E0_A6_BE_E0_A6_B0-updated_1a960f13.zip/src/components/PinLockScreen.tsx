import React, { useState } from 'react';
import { Lock, Delete, KeyRound, AlertTriangle } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { toBanglaNumber } from '../utils/formatters';

export const PinLockScreen: React.FC = () => {
  const { settings, setIsAppUnlocked, updateSettings } = useApp();
  const isEn = settings.language === 'en';

  const [enteredPin, setEnteredPin] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [showForgotModal, setShowForgotModal] = useState(false);

  const targetPin = settings.pinCode || '1234';

  const handleDigit = (digit: string) => {
    if (enteredPin.length >= 4) return;
    const nextPin = enteredPin + digit;
    setEnteredPin(nextPin);
    setErrorMsg('');

    if (nextPin.length === 4) {
      if (nextPin === targetPin) {
        setIsAppUnlocked(true);
      } else {
        setErrorMsg(isEn ? 'Incorrect PIN code! Please try again.' : 'ভুল পিন কোড! আবার চেষ্টা করুন।');
        setTimeout(() => {
          setEnteredPin('');
        }, 600);
      }
    }
  };

  const handleDelete = () => {
    setEnteredPin((prev) => prev.slice(0, -1));
    setErrorMsg('');
  };

  const handleResetPin = () => {
    updateSettings({ isPinEnabled: false, pinCode: '' });
    setShowForgotModal(false);
    setIsAppUnlocked(true);
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#fafbff] dark:bg-slate-900 flex flex-col items-center justify-between p-6 select-none transition-colors">
      {/* Header */}
      <div className="w-full flex justify-end">
        <button
          onClick={() => setShowForgotModal(true)}
          className="text-xs font-semibold text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors py-2 px-3"
        >
          {isEn ? 'Forgot PIN?' : 'পিন ভুলে গেছেন?'}
        </button>
      </div>

      {/* Main Lock Display */}
      <div className="flex flex-col items-center text-center space-y-4 max-w-xs">
        <div className="w-16 h-16 rounded-2xl bg-blue-50 dark:bg-blue-950/60 border border-blue-100 dark:border-blue-900 flex items-center justify-center text-blue-600 dark:text-blue-400 shadow-sm">
          <Lock className="w-8 h-8 stroke-[2.2]" />
        </div>

        <div>
          <h2 className="text-lg font-bold text-slate-800 dark:text-slate-100">
            {isEn ? 'App Locked & Secured' : 'আয় ব্যয় সুরক্ষিত'}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {isEn
              ? 'Enter 4-digit PIN to access your finances'
              : 'আপনার আর্থিক তথ্য সুরক্ষিত রাখতে ৪ ডিজিটের পিন দিন'}
          </p>
        </div>

        {/* 4-Dot PIN Indicator */}
        <div className="flex items-center gap-3 pt-4">
          {[0, 1, 2, 3].map((idx) => {
            const isFilled = enteredPin.length > idx;
            return (
              <div
                key={idx}
                className={`w-4 h-4 rounded-full transition-all duration-200 ${
                  isFilled
                    ? 'bg-blue-600 dark:bg-blue-500 scale-110 shadow-sm'
                    : 'border-2 border-slate-300 dark:border-slate-700 bg-transparent'
                }`}
              />
            );
          })}
        </div>

        {errorMsg && (
          <p className="text-xs font-bold text-rose-500 animate-shake">
            {errorMsg}
          </p>
        )}
      </div>

      {/* Numeric Keypad */}
      <div className="w-full max-w-xs grid grid-cols-3 gap-3 pb-8">
        {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
          <button
            key={digit}
            onClick={() => handleDigit(digit)}
            className="h-14 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-xs hover:bg-slate-50 dark:hover:bg-slate-700/60 active:scale-95 text-lg font-bold text-slate-800 dark:text-slate-100 flex items-center justify-center transition-all"
          >
            {settings.useBanglaNumerals && !isEn ? toBanglaNumber(digit) : digit}
          </button>
        ))}

        {/* Empty placeholder */}
        <div className="flex items-center justify-center text-slate-300 dark:text-slate-600">
          <KeyRound className="w-5 h-5 opacity-40" />
        </div>

        {/* 0 */}
        <button
          onClick={() => handleDigit('0')}
          className="h-14 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-xs hover:bg-slate-50 dark:hover:bg-slate-700/60 active:scale-95 text-lg font-bold text-slate-800 dark:text-slate-100 flex items-center justify-center transition-all"
        >
          {settings.useBanglaNumerals && !isEn ? '০' : '0'}
        </button>

        {/* Backspace */}
        <button
          onClick={handleDelete}
          className="h-14 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-xs hover:bg-rose-50 dark:hover:bg-rose-950/40 active:scale-95 text-slate-500 dark:text-slate-400 hover:text-rose-500 dark:hover:text-rose-400 flex items-center justify-center transition-all"
          aria-label="Delete"
        >
          <Delete className="w-6 h-6" />
        </button>
      </div>

      {/* Forgot PIN Confirmation Modal (replacing window.confirm) */}
      {showForgotModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-xs bg-white dark:bg-slate-900 rounded-3xl p-5 shadow-2xl space-y-4 border border-slate-100 dark:border-slate-800 animate-in fade-in">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-amber-50 dark:bg-amber-950/60 text-amber-500 flex items-center justify-center flex-shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-800 dark:text-white">
                  {isEn ? 'Reset App Lock PIN?' : 'পিন রিসেট করবেন?'}
                </h3>
                <p className="text-[11px] text-slate-400">
                  {isEn
                    ? 'This will disable the PIN lock and let you unlock the app.'
                    : 'এটি পিন লক নিষ্ক্রিয় করে দেবে এবং আপনি অ্যাপে প্রবেশ করতে পারবেন।'}
                </p>
              </div>
            </div>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowForgotModal(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200"
              >
                {isEn ? 'Cancel' : 'বাতিল'}
              </button>
              <button
                onClick={handleResetPin}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
              >
                {isEn ? 'Reset & Unlock' : 'রিসেট ও আনলক'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
