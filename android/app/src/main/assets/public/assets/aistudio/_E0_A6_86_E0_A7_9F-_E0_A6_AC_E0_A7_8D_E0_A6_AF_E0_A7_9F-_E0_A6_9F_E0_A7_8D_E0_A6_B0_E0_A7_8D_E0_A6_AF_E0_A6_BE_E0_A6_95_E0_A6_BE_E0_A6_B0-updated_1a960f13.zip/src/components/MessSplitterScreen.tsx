import React, { useState } from 'react';
import {
  ArrowLeft,
  Users,
  Plus,
  Trash2,
  Copy,
  Check,
  Share2,
  Utensils,
  Calculator,
  ArrowRight,
  CheckCircle2,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import {
  formatCurrency,
  toBanglaNumber,
  getTodayString,
  getCurrentTimeString,
} from '../utils/formatters';

interface MessMember {
  id: string;
  name: string;
  meals: number;
  deposit: number;
}

export const MessSplitterScreen: React.FC = () => {
  const { setActiveTab, addTransaction, settings } = useApp();
  const isEn = settings.language === 'en';

  const [title, setTitle] = useState(
    isEn ? `${new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' })} Mess Account` : `${new Date().toLocaleDateString('bn-BD', { month: 'long', year: 'numeric' })} মেসের হিসাব`
  );
  const [totalBazaarCost, setTotalBazaarCost] = useState<number>(0);
  const [copied, setCopied] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [showSyncConfirm, setShowSyncConfirm] = useState(false);

  // Start with a clean ledger instead of fictional members and deposits.
  const [members, setMembers] = useState<MessMember[]>([]);

  const [newMemberName, setNewMemberName] = useState('');
  const [newMemberMeals, setNewMemberMeals] = useState('');
  const [newMemberDeposit, setNewMemberDeposit] = useState('');
  const [isAddMemberOpen, setIsAddMemberOpen] = useState(false);

  // Calculations
  const totalMeals = members.reduce((sum, m) => sum + (m.meals || 0), 0);
  const totalDeposit = members.reduce((sum, m) => sum + (m.deposit || 0), 0);
  const mealRate = totalMeals > 0 ? totalBazaarCost / totalMeals : 0;

  const handleAddMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemberName.trim()) return;

    const newM: MessMember = {
      id: `m_${Date.now()}`,
      name: newMemberName.trim(),
      meals: parseFloat(newMemberMeals) || 0,
      deposit: parseFloat(newMemberDeposit) || 0,
    };

    setMembers([...members, newM]);
    setNewMemberName('');
    setNewMemberMeals('');
    setNewMemberDeposit('');
    setIsAddMemberOpen(false);
  };

  const handleDeleteMember = (id: string) => {
    setMembers(members.filter((m) => m.id !== id));
  };

  // Generate WhatsApp formatted message
  const handleCopySummary = () => {
    let msg = `🍲 *${title}*\n`;
    msg += `------------------------------\n`;
    msg += `${isEn ? 'Total Bazaar Cost' : 'মোট বাজার খরচ'}: ${formatCurrency(
      totalBazaarCost,
      settings.useBanglaNumerals && !isEn
    )}\n`;
    msg += `${isEn ? 'Total Meals' : 'মোট মিল'}: ${
      settings.useBanglaNumerals && !isEn ? toBanglaNumber(totalMeals) : totalMeals
    } ${isEn ? 'Meals' : 'টি'}\n`;
    msg += `${isEn ? 'Meal Rate' : 'মিল রেট'}: ${mealRate.toFixed(2)} ৳\n`;
    msg += `------------------------------\n`;
    msg += `*${isEn ? 'Member Summary:' : 'সদস্যদের হিসাব বিবরণী:'}*\n`;

    members.forEach((m) => {
      const memberCost = m.meals * mealRate;
      const balance = m.deposit - memberCost;
      const status =
        balance >= 0
          ? `${isEn ? 'Refund' : 'ফেরত পাবে'}: +${Math.round(balance)} ৳ 🟢`
          : `${isEn ? 'Due' : 'দিতে হবে'}: ${Math.round(Math.abs(balance))} ৳ 🔴`;
      msg += `• ${m.name}: ${isEn ? 'Meals' : 'মিল'} ${m.meals}, ${
        isEn ? 'Deposit' : 'জমা'
      } ${m.deposit} ৳ | ${status}\n`;
    });

    msg += `------------------------------\n`;
    msg += isEn
      ? `Prepared by: Income Expense App`
      : `হিসাব প্রস্তুতকারক: আয় ব্যয় অ্যাপ`;

    navigator.clipboard.writeText(msg);
    setCopied(true);
    setToastMessage(isEn ? 'Summary copied to clipboard!' : 'সামারি ক্লিপবোর্ডে কপি হয়েছে!');
    setTimeout(() => {
      setCopied(false);
      setToastMessage(null);
    }, 3000);
  };

  const handleSyncToExpense = () => {
    addTransaction({
      type: 'expense',
      amount: totalBazaarCost,
      categoryId: 'cat_food',
      categoryName: isEn ? 'Food & Dining' : 'খাবার ও পানীয়',
      accountId: 'acc_cash',
      accountName: isEn ? 'Cash' : 'নগদ',
      date: getTodayString(),
      time: getCurrentTimeString(),
      note: `${title} (${isEn ? 'Meal rate' : 'মিল রেট'}: ${mealRate.toFixed(1)} ৳)`,
    });
    setShowSyncConfirm(false);
    setToastMessage(
      isEn
        ? 'Mess cost saved to main expense ledger!'
        : 'মেসের খরচ প্রধান ব্যয় হিসেবে সংরক্ষিত হয়েছে!'
    );
    setTimeout(() => setToastMessage(null), 3000);
  };

  return (
    <div className="space-y-4 pb-24 pt-1">
      {/* Top Header */}
      <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setActiveTab('profile_menu')}
            className="p-1.5 rounded-full text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title={isEn ? 'Back' : 'পেছনে যান'}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <Utensils className="w-5 h-5 text-orange-500" />
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              {isEn ? 'Mess & Meal Splitter' : 'মেস ও শেয়ার্ড মিল স্প্লিটার'}
            </h2>
          </div>
        </div>

        <button
          onClick={handleCopySummary}
          className="border border-blue-200 dark:border-blue-800 text-blue-600 dark:text-blue-400 bg-blue-50/30 hover:bg-blue-50 dark:hover:bg-blue-950/40 rounded-xl px-3 py-1.5 text-xs font-semibold flex items-center gap-1.5 transition-colors"
          title={isEn ? 'Share Summary' : 'WhatsApp এ শেয়ার করুন'}
        >
          {copied ? (
            <Check className="w-3.5 h-3.5 text-emerald-500" />
          ) : (
            <Share2 className="w-3.5 h-3.5" />
          )}
          <span>{copied ? (isEn ? 'Copied' : 'কপি হয়েছে') : isEn ? 'Share' : 'শেয়ার'}</span>
        </button>
      </div>

      {/* Main KPI Card: Total Bazaar | Total Meals | Meal Rate */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 border border-slate-100 dark:border-slate-800 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="text-xs font-bold text-slate-800 dark:text-white bg-transparent border-b border-dashed border-slate-300 dark:border-slate-700 focus:outline-none flex-1 mr-2"
          />
          <button
            onClick={() => setShowSyncConfirm(true)}
            className="text-[11px] font-bold text-blue-600 dark:text-blue-400 hover:underline flex-shrink-0"
          >
            {isEn ? '+ Sync to Expense' : '+ ব্যয়ে যুক্ত করুন'}
          </button>
        </div>

        <div className="grid grid-cols-3 gap-2 pt-1 text-center">
          <div className="p-2.5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-100 dark:border-amber-900/60">
            <span className="text-[10px] text-amber-700 dark:text-amber-300 font-semibold block">
              {isEn ? 'Total Bazaar' : 'মোট বাজার'}
            </span>
            <input
              type="number"
              value={totalBazaarCost}
              onChange={(e) => setTotalBazaarCost(parseFloat(e.target.value) || 0)}
              className="w-full text-center text-sm font-bold bg-transparent text-amber-900 dark:text-amber-100 focus:outline-none"
            />
          </div>

          <div className="p-2.5 rounded-2xl bg-blue-50 dark:bg-blue-950/40 border border-blue-100 dark:border-blue-900/60">
            <span className="text-[10px] text-blue-700 dark:text-blue-300 font-semibold block">
              {isEn ? 'Total Meals' : 'মোট মিল'}
            </span>
            <span className="text-sm font-bold text-blue-900 dark:text-blue-100 block">
              {settings.useBanglaNumerals && !isEn ? toBanglaNumber(totalMeals) : totalMeals}
            </span>
          </div>

          <div className="p-2.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-100 dark:border-emerald-900/60">
            <span className="text-[10px] text-emerald-700 dark:text-emerald-300 font-semibold block">
              {isEn ? 'Meal Rate' : 'মিল রেট'}
            </span>
            <span className="text-sm font-bold text-emerald-900 dark:text-emerald-100 block">
              {mealRate.toFixed(1)} ৳
            </span>
          </div>
        </div>
      </div>

      {/* Members List */}
      <div className="space-y-2.5 px-1">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-slate-700 dark:text-slate-300">
            {isEn
              ? `Member Accounts (${members.length})`
              : `মেম্বারদের হিসাব (${members.length} জন)`}
          </h3>
          <button
            onClick={() => setIsAddMemberOpen(true)}
            className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:text-blue-700 flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{isEn ? 'Add Member' : 'নতুন মেম্বার'}</span>
          </button>
        </div>

        <div className="space-y-2">
          {members.map((m) => {
            const memberCost = m.meals * mealRate;
            const balance = m.deposit - memberCost;
            const isRefund = balance >= 0;

            return (
              <div
                key={m.id}
                className="p-3.5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-xs flex items-center justify-between hover:border-slate-300 dark:hover:border-slate-700 transition-colors"
              >
                <div className="space-y-0.5">
                  <h4 className="text-xs font-bold text-slate-800 dark:text-white">
                    {m.name}
                  </h4>
                  <p className="text-[10px] text-slate-400">
                    {isEn ? 'Meals' : 'মিল'}:{' '}
                    {settings.useBanglaNumerals && !isEn ? toBanglaNumber(m.meals) : m.meals} |{' '}
                    {isEn ? 'Deposit' : 'জমা'}:{' '}
                    {formatCurrency(m.deposit, settings.useBanglaNumerals && !isEn)}
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 block">
                      {isEn ? 'Cost' : 'খরচ'}: {Math.round(memberCost)} ৳
                    </span>
                    <span
                      className={`text-xs font-bold ${
                        isRefund ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
                      }`}
                    >
                      {isRefund ? (isEn ? 'Refund: +' : 'পাবে: +') : isEn ? 'Due: -' : 'দিবে: -'}{' '}
                      {formatCurrency(
                        Math.abs(Math.round(balance)),
                        settings.useBanglaNumerals && !isEn
                      )}
                    </span>
                  </div>

                  <button
                    onClick={() => handleDeleteMember(m.id)}
                    className="p-1 text-slate-400 hover:text-rose-500 rounded-lg transition-colors"
                    title={isEn ? 'Remove member' : 'মুছে ফেলুন'}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Add Member Modal */}
      {isAddMemberOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-5 shadow-2xl space-y-3 border border-slate-100 dark:border-slate-800 animate-in fade-in">
            <h3 className="text-xs font-bold text-slate-800 dark:text-white">
              {isEn ? 'Add Member' : 'মেম্বার যোগ করুন'}
            </h3>
            <input
              type="text"
              value={newMemberName}
              onChange={(e) => setNewMemberName(e.target.value)}
              placeholder={isEn ? 'Member name' : 'মেম্বারের নাম'}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
              autoFocus
            />
            <div className="grid grid-cols-2 gap-2">
              <input
                type="number"
                value={newMemberMeals}
                onChange={(e) => setNewMemberMeals(e.target.value)}
                placeholder={isEn ? 'Total meals' : 'মোট মিল'}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <input
                type="number"
                value={newMemberDeposit}
                onChange={(e) => setNewMemberDeposit(e.target.value)}
                placeholder={isEn ? 'Deposit amount' : 'জমা টাকা'}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsAddMemberOpen(false)}
                className="px-3 py-1.5 text-xs text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
              >
                {isEn ? 'Cancel' : 'বাতিল'}
              </button>
              <button
                type="button"
                onClick={handleAddMember}
                className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-colors shadow-xs"
              >
                {isEn ? 'Add' : 'যোগ করুন'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Sync To Expense Confirmation Modal (no window.confirm) */}
      {showSyncConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-xs bg-white dark:bg-slate-900 rounded-3xl p-5 shadow-2xl space-y-4 border border-slate-100 dark:border-slate-800 animate-in fade-in">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-blue-50 dark:bg-blue-950/60 text-blue-600 flex items-center justify-center flex-shrink-0">
                <Utensils className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-800 dark:text-white">
                  {isEn ? 'Sync to Expenses?' : 'ব্যয়ে যুক্ত করতে চান?'}
                </h3>
                <p className="text-[11px] text-slate-400">
                  {isEn
                    ? `Add ${formatCurrency(totalBazaarCost, false)} to main expense list as Food & Dining.`
                    : `মেসের বাজার খরচ (${formatCurrency(totalBazaarCost, settings.useBanglaNumerals)}) প্রধান খরচে যুক্ত হবে।`}
                </p>
              </div>
            </div>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowSyncConfirm(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200"
              >
                {isEn ? 'Cancel' : 'বাতিল'}
              </button>
              <button
                onClick={handleSyncToExpense}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
              >
                {isEn ? 'Confirm & Add' : 'হ্যাঁ, যুক্ত করুন'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Pill Toast Banner */}
      {toastMessage && (
        <div className="fixed bottom-10 left-1/2 -translate-x-1/2 bg-white dark:bg-slate-900 border border-emerald-300 dark:border-emerald-700 text-slate-800 dark:text-slate-100 text-xs px-4 py-2.5 rounded-full shadow-xl flex items-center gap-2 animate-in fade-in z-50">
          <CheckCircle2 className="w-4 h-4 text-emerald-500 fill-emerald-500" />
          <span className="font-semibold">{toastMessage}</span>
        </div>
      )}
    </div>
  );
};
