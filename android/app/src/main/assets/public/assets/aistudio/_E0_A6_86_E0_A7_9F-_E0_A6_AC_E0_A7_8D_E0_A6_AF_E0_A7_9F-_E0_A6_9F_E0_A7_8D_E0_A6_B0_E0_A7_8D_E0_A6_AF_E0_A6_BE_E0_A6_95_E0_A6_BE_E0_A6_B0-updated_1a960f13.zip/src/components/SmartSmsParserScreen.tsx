import React, { useState } from 'react';
import { ArrowLeft, MessageSquare, Zap, Check, ArrowRight, Sparkles } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { getTodayString, getCurrentTimeString, formatCurrency } from '../utils/formatters';

export const SmartSmsParserScreen: React.FC = () => {
  const { setActiveTab, addTransaction, categories, accounts, settings } = useApp();
  const isEn = settings.language === 'en';

  const [smsText, setSmsText] = useState('');
  const [parsedData, setParsedData] = useState<{
    amount: number;
    type: 'income' | 'expense';
    accountName: string;
    note: string;
    categoryName: string;
  } | null>(null);

  const [success, setSuccess] = useState(false);

  // Sample SMS templates common in Bangladesh & global banking
  const samples = [
    {
      label: isEn ? 'bKash Cash Out (Expense)' : 'বিকাশ ক্যাশ আউট (ব্যয়)',
      text: 'Cash Out Tk 1,500.00 to 01712345678 successful. Fee Tk 27.75. Balance Tk 3,450.00. TrxID 9K8J2LM3 at 15/10/2026 11:30',
    },
    {
      label: isEn ? 'bKash Received (Income)' : 'বিকাশ টাকা গ্রহণ (আয়)',
      text: 'You have received Tk 2,500.00 from 01898765432. Fee Tk 0.00. Balance Tk 5,950.00. TrxID 7N2V9P1X at 15/10/2026 10:15',
    },
    {
      label: isEn ? 'Bank POS Payment (Expense)' : 'ব্যাংক কার্ড পেমেন্ট (ব্যয়)',
      text: 'Your A/C ...4582 is debited by BDT 1,850.00 for POS payment at Agora Superstore on 15-OCT-2026.',
    },
    {
      label: isEn ? 'Nagad Cash In (Income)' : 'নগদ ক্যাশ ইন (আয়)',
      text: 'Cash In of Tk 4,000.00 from Agent 01911223344 is successful. New balance Tk 8,200.00. TxnId: 88AFG1',
    },
  ];

  const handleParse = (textToParse: string) => {
    setSmsText(textToParse);
    if (!textToParse.trim()) {
      setParsedData(null);
      return;
    }

    const t = textToParse.toLowerCase();

    // 1. Determine Type
    let txType: 'income' | 'expense' = 'expense';
    if (t.includes('received') || t.includes('credited') || t.includes('cash in') || t.includes('জমা')) {
      txType = 'income';
    } else if (t.includes('cash out') || t.includes('debited') || t.includes('payment') || t.includes('fee')) {
      txType = 'expense';
    }

    // 2. Extract Amount (Tk or BDT followed by number)
    let amount = 0;
    const amtMatch = textToParse.match(/(?:tk|bdt|টাকা)\s*([0-9,]+(?:\.[0-9]+)?)/i);
    if (amtMatch && amtMatch[1]) {
      amount = parseFloat(amtMatch[1].replace(/,/g, ''));
    } else {
      const genericMatch = textToParse.match(/([0-9,]+(?:\.[0-9]+)?)/);
      if (genericMatch) amount = parseFloat(genericMatch[1].replace(/,/g, ''));
    }

    // 3. Determine Account
    let accName = isEn ? 'bKash' : 'বিকাশ';
    if (t.includes('bkash')) accName = isEn ? 'bKash' : 'বিকাশ';
    else if (t.includes('nagad')) accName = isEn ? 'Nagad' : 'নগদ';
    else if (t.includes('rocket')) accName = isEn ? 'Rocket' : 'রকেট';
    else if (t.includes('bank') || t.includes('a/c') || t.includes('bdt')) accName = isEn ? 'Bank Account' : 'ব্যাংক অ্যাকাউন্ট';

    // 4. Determine Category & Note
    let catName = txType === 'income' ? (isEn ? 'Salary & Income' : 'মাসিক বেতন') : (isEn ? 'Other Expense' : 'অন্যান্য ব্যয়');
    if (t.includes('agora') || t.includes('shop') || t.includes('superstore')) {
      catName = isEn ? 'Groceries & Market' : 'বাজার খরচ';
    } else if (t.includes('fee')) {
      catName = isEn ? 'Bills & Utilities' : 'ইউটিলিটি ও বিল';
    }

    const trxMatch = textToParse.match(/(?:trxid|txnid)\s*([a-z0-9]+)/i);
    const trxId = trxMatch ? `TrxID: ${trxMatch[1]}` : '';

    setParsedData({
      amount: amount || 0,
      type: txType,
      accountName: accName,
      categoryName: catName,
      note: trxId ? (isEn ? `SMS Entry (${trxId})` : `SMS এন্ট্রি (${trxId})`) : (isEn ? 'SMS Transaction Entry' : 'SMS ট্রানজেকশন এন্ট্রি'),
    });
  };

  const handleSaveTransaction = () => {
    if (!parsedData || parsedData.amount <= 0) return;

    const matchedCat = categories.find((c) => c.name === parsedData.categoryName) || categories[0];
    const matchedAcc = accounts.find((a) => a.name.includes(parsedData.accountName)) || accounts[0];

    addTransaction({
      type: parsedData.type,
      amount: parsedData.amount,
      categoryId: matchedCat ? matchedCat.id : 'cat_general',
      categoryName: parsedData.categoryName,
      accountId: matchedAcc ? matchedAcc.id : 'acc_bkash',
      accountName: parsedData.accountName,
      date: getTodayString(),
      time: getCurrentTimeString(),
      note: parsedData.note,
    });

    setSuccess(true);
    setTimeout(() => {
      setSuccess(false);
      setActiveTab('dashboard');
    }, 1200);
  };

  return (
    <div className="space-y-4 pb-24 pt-1">
      {/* Top Header */}
      <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setActiveTab('profile_menu')}
            className="p-1.5 rounded-full text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title={isEn ? 'Back' : 'পেছনে যান'}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-amber-500" />
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              {isEn ? 'Smart Bank & SMS Parser' : 'বিকাশ/নগদ SMS ট্র্যাকার'}
            </h2>
          </div>
        </div>
      </div>

      {/* Description */}
      <div className="p-3 bg-blue-50/50 dark:bg-blue-950/30 rounded-2xl border border-blue-100 dark:border-blue-900/60 flex items-start gap-2.5">
        <Sparkles className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
        <p className="text-xs text-blue-800 dark:text-blue-200 leading-relaxed">
          {isEn
            ? 'Paste any SMS from bKash, Nagad, Rocket, or your bank below. The app will automatically detect the transaction amount, type, and account.'
            : 'বিকাশ, নগদ বা ব্যাংকের যেকোনো এসএমএস কপি করে নিচে পেস্ট করুন। অ্যাপ স্বয়ংক্রিয়ভাবে টাকার পরিমাণ ও হিসাব শনাক্ত করে নেবে।'}
        </p>
      </div>

      {/* Text Area */}
      <div className="space-y-2">
        <textarea
          rows={4}
          value={smsText}
          onChange={(e) => handleParse(e.target.value)}
          placeholder={isEn ? 'Paste transaction SMS text here...' : 'এখানে এসএমএস পেস্ট করুন...'}
          className="w-full p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-xs resize-none placeholder:text-slate-400"
        />

        {/* Sample Pills */}
        <div className="space-y-1.5">
          <span className="text-[10px] font-bold text-slate-400">
            {isEn ? 'Quick test with sample bank/MFS SMS:' : 'পরীক্ষা করতে নমুনা এসএমএস বেছে নিন:'}
          </span>
          <div className="flex flex-wrap gap-1.5">
            {samples.map((s) => (
              <button
                key={s.label}
                onClick={() => handleParse(s.text)}
                className="text-[10px] font-medium px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-blue-50 dark:hover:bg-blue-900/40 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Parsed Result Card */}
      {parsedData && parsedData.amount > 0 && (
        <div className="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3 animate-in fade-in">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
              {isEn ? 'Detected Transaction:' : 'শনাক্ত হওয়া লেনদেন:'}
            </span>
            <span
              className={`text-xs font-extrabold px-2.5 py-0.5 rounded-full ${
                parsedData.type === 'income'
                  ? 'bg-emerald-50 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400'
                  : 'bg-rose-50 text-rose-600 dark:bg-rose-950/60 dark:text-rose-400'
              }`}
            >
              {parsedData.type === 'income'
                ? isEn ? 'Income (+ Inflow)' : 'আয় (টাকা এসেছে)'
                : isEn ? 'Expense (- Outflow)' : 'ব্যয় (টাকা খরচ)'}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div>
              <span className="text-[10px] text-slate-400 block">{isEn ? 'Amount' : 'পরিমাণ'}</span>
              <span className="text-lg font-black text-slate-900 dark:text-white">
                {formatCurrency(parsedData.amount, settings.useBanglaNumerals && !isEn)}
              </span>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block">{isEn ? 'Account / Channel' : 'মাধ্যম / অ্যাকাউন্ট'}</span>
              <span className="font-bold text-slate-800 dark:text-slate-200">
                {parsedData.accountName}
              </span>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block">{isEn ? 'Category' : 'ক্যাটাগরি'}</span>
              <span className="font-semibold text-slate-800 dark:text-slate-200">
                {parsedData.categoryName}
              </span>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block">{isEn ? 'Note / Ref' : 'নোট'}</span>
              <span className="font-medium text-slate-600 dark:text-slate-400 truncate block">
                {parsedData.note}
              </span>
            </div>
          </div>

          <button
            onClick={handleSaveTransaction}
            disabled={success}
            className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center justify-center gap-1.5"
          >
            {success ? (
              <>
                <Check className="w-4 h-4 text-emerald-300" />
                <span>{isEn ? 'Saved to Transactions!' : 'সংরক্ষণ সম্পন্ন হয়েছে!'}</span>
              </>
            ) : (
              <>
                <span>{isEn ? 'Save as Transaction' : 'আয়-ব্যয় হিসেবে সেভ করুন'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </>
            )}
          </button>
        </div>
      )}
    </div>
  );
};
