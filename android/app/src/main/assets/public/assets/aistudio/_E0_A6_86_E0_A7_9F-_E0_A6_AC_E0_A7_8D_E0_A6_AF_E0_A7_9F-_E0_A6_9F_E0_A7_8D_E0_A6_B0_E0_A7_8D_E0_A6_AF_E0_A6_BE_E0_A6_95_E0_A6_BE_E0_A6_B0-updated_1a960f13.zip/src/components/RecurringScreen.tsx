import React, { useState } from 'react';
import {
  ArrowLeft,
  Clock,
  Plus,
  Play,
  Trash2,
  CheckCircle2,
  Repeat,
  Calendar,
  AlertCircle,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatCurrency, toBanglaNumber, getTodayString } from '../utils/formatters';

export const RecurringScreen: React.FC = () => {
  const {
    setActiveTab,
    recurringItems,
    addRecurringItem,
    toggleRecurringItem,
    deleteRecurringItem,
    applyRecurringToTransactions,
    categories,
    settings,
  } = useApp();

  const isEn = settings.language === 'en';
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Form states
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [type, setType] = useState<'income' | 'expense'>('expense');
  const [frequency, setFrequency] = useState<'daily' | 'monthly' | 'yearly'>('monthly');
  const [dayOfMonth, setDayOfMonth] = useState('1');
  const [selectedCatName, setSelectedCatName] = useState('');

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(amount);
    if (!title.trim() || isNaN(val) || val <= 0) return;

    addRecurringItem({
      title: title.trim(),
      amount: val,
      type,
      frequency,
      dayOfMonth: parseInt(dayOfMonth, 10) || 1,
      categoryName: selectedCatName || (isEn ? 'General' : 'সাধারণ'),
      isActive: true,
    });

    setIsModalOpen(false);
    setTitle('');
    setAmount('');
    setToastMessage(isEn ? 'Recurring rule created!' : 'রিকারিং নিয়ম যুক্ত হয়েছে!');
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleTriggerNow = (id: string, itemTitle: string) => {
    applyRecurringToTransactions(id);
    setToastMessage(
      isEn
        ? `Applied "${itemTitle}" as today's transaction!`
        : `"${itemTitle}" আজকের লেনদেনে যুক্ত হয়েছে!`
    );
    setTimeout(() => setToastMessage(null), 3000);
  };

  return (
    <div className="space-y-4 pb-24 pt-1">
      {/* Top Header */}
      <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setActiveTab('dashboard')}
            className="p-1 rounded-full text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title={isEn ? 'Back' : 'পেছনে যান'}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <Repeat className="w-5 h-5 text-indigo-500" />
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              {isEn ? 'Recurring Transactions' : 'রিকারিং লেনদেন'}
            </h2>
          </div>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="border border-blue-200 dark:border-blue-800 text-blue-600 dark:text-blue-400 bg-blue-50/20 hover:bg-blue-50/80 dark:hover:bg-blue-950/40 rounded-xl px-3 py-1.5 text-xs font-semibold flex items-center gap-1 transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>{isEn ? 'New Rule' : 'নতুন রিকারিং'}</span>
        </button>
      </div>

      <p className="text-xs text-slate-500 dark:text-slate-400 px-1">
        {isEn
          ? 'Manage recurring bills (salary, rent, wifi bill). Tap Play to instantly record today.'
          : 'পুনরাবৃত্ত বিল ও আয় (যেমন: বেতন, বাসা ভাড়া, ওয়াইফাই বিল)। প্লে বাটনে চাপলে আজকেই লেনদেন যোগ হয়ে যাবে।'}
      </p>

      {/* List or Empty State */}
      {recurringItems.length === 0 ? (
        <div className="py-24 flex flex-col items-center justify-center text-center">
          <div className="text-slate-300 dark:text-slate-600 mb-3">
            <Clock className="w-16 h-16 stroke-[1.5]" />
          </div>
          <p className="text-xs font-medium text-slate-600 dark:text-slate-300">
            {isEn ? 'No recurring rules set' : 'কোনো রিকারিং লেনদেন নেই'}
          </p>
          <p className="text-[11px] text-slate-400 mt-1">
            {isEn ? 'Tap + New Rule to schedule your bills' : 'উপরে + বাটন দিয়ে নতুন নিয়ম তৈরি করুন'}
          </p>
        </div>
      ) : (
        <div className="space-y-2.5 px-1">
          {recurringItems.map((item) => {
            const isExpense = item.type === 'expense';
            return (
              <div
                key={item.id}
                className="bg-white dark:bg-slate-900 rounded-2xl p-3.5 border border-slate-100 dark:border-slate-800 shadow-xs flex items-center justify-between hover:border-slate-300 dark:hover:border-slate-700 transition-colors"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[9px] px-1.5 py-0.5 rounded font-bold uppercase ${
                        isExpense
                          ? 'bg-rose-50 dark:bg-rose-950/60 text-rose-600'
                          : 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600'
                      }`}
                    >
                      {item.frequency === 'daily'
                        ? isEn ? 'Daily' : 'দৈনিক'
                        : item.frequency === 'yearly'
                        ? isEn ? 'Yearly' : 'বাৎসরিক'
                        : isEn ? `Monthly (${item.dayOfMonth}th)` : `মাসিক (${toBanglaNumber(item.dayOfMonth)} তারিখ)`}
                    </span>
                    <span className="text-xs font-bold text-slate-800 dark:text-white">
                      {item.title}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-400">
                    {item.categoryName} • {isEn ? 'Next' : 'পরবর্তী'}: {item.nextDate || '১ম তারিখ'}
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <span
                    className={`text-sm font-extrabold ${
                      isExpense ? 'text-rose-500' : 'text-emerald-500'
                    }`}
                  >
                    {isExpense ? '-' : '+'}
                    {formatCurrency(item.amount, settings.useBanglaNumerals && !isEn)}
                  </span>

                  <div className="flex items-center gap-1.5">
                    {/* 1-Tap Trigger Button */}
                    <button
                      onClick={() => handleTriggerNow(item.id, item.title)}
                      className="p-1.5 rounded-xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 hover:bg-blue-100 dark:hover:bg-blue-900/60 transition-colors"
                      title={isEn ? 'Record transaction today' : 'আজকেই লেনদেনে যুক্ত করুন'}
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                    </button>

                    {/* Delete */}
                    <button
                      onClick={() => deleteRecurringItem(item.id)}
                      className="p-1.5 rounded-xl text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                      title={isEn ? 'Delete rule' : 'মুছে ফেলুন'}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add Recurring Rule Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-5 shadow-2xl space-y-3.5 border border-slate-100 dark:border-slate-800 animate-in fade-in">
            <h3 className="text-sm font-bold text-slate-800 dark:text-white">
              {isEn ? 'Add Recurring Rule' : 'নতুন রিকারিং লেনদেন'}
            </h3>

            {/* Type Switcher */}
            <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs font-bold text-center">
              <button
                type="button"
                onClick={() => setType('expense')}
                className={`py-1.5 rounded-lg transition-all ${
                  type === 'expense'
                    ? 'bg-rose-500 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                {isEn ? 'Expense' : 'ব্যয়'}
              </button>
              <button
                type="button"
                onClick={() => setType('income')}
                className={`py-1.5 rounded-lg transition-all ${
                  type === 'income'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                {isEn ? 'Income' : 'আয়'}
              </button>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-500 dark:text-slate-400 block mb-1">
                {isEn ? 'Title (e.g. WiFi Bill, Flat Rent)' : 'শিরোনাম (যেমন: ওয়াইফাই বিল, বাসা ভাড়া)'}
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder={isEn ? 'Title' : 'শিরোনাম লিখুন'}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                autoFocus
                required
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-500 dark:text-slate-400 block mb-1">
                {isEn ? 'Amount (৳)' : 'টাকার পরিমাণ (৳)'}
              </label>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder={isEn ? 'Amount' : 'পরিমাণ লিখুন'}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[11px] font-bold text-slate-500 dark:text-slate-400 block mb-1">
                  {isEn ? 'Frequency' : 'পুনরাবৃত্তি'}
                </label>
                <select
                  value={frequency}
                  onChange={(e) => setFrequency(e.target.value as any)}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="daily">{isEn ? 'Daily' : 'দৈনিক'}</option>
                  <option value="monthly">{isEn ? 'Monthly' : 'মাসিক'}</option>
                  <option value="yearly">{isEn ? 'Yearly' : 'বাৎসরিক'}</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-500 dark:text-slate-400 block mb-1">
                  {isEn ? 'Day of Month' : 'মাসের কত তারিখ?'}
                </label>
                <input
                  type="number"
                  min="1"
                  max="31"
                  value={dayOfMonth}
                  onChange={(e) => setDayOfMonth(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-500 dark:text-slate-400 block mb-1">
                {isEn ? 'Category' : 'ক্যাটাগরি'}
              </label>
              <select
                value={selectedCatName}
                onChange={(e) => setSelectedCatName(e.target.value)}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">{isEn ? 'Select a category...' : 'ক্যাটাগরি নির্বাচন করুন...'}</option>
                {categories.map((c) => (
                  <option key={c.id} value={isEn ? (c.nameEn || c.name) : c.name}>
                    {isEn ? (c.nameEn || c.name) : c.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
              >
                {isEn ? 'Cancel' : 'বাতিল'}
              </button>
              <button
                type="button"
                onClick={handleAddSubmit}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
              >
                {isEn ? 'Save Rule' : 'সেইভ করুন'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast message */}
      {toastMessage && (
        <div className="fixed bottom-10 left-1/2 -translate-x-1/2 bg-white dark:bg-slate-900 border border-emerald-300 dark:border-emerald-700 text-slate-800 dark:text-slate-100 text-xs px-4 py-2.5 rounded-full shadow-xl flex items-center gap-2 animate-in fade-in z-50">
          <CheckCircle2 className="w-4 h-4 text-emerald-500 fill-emerald-500" />
          <span className="font-semibold">{toastMessage}</span>
        </div>
      )}
    </div>
  );
};
