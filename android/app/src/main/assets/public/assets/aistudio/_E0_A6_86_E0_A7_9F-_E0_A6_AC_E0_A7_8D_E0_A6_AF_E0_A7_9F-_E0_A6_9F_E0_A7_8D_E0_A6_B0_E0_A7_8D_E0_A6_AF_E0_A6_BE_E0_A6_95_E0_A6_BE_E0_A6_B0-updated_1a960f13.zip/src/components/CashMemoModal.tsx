import React from 'react';
import { X, Printer, CheckCircle2, FileText, ArrowDownLeft, ArrowUpRight } from 'lucide-react';
import { Transaction } from '../types';
import { formatCurrency, formatBengaliDate, toBanglaNumber } from '../utils/formatters';
import { useApp } from '../context/AppContext';

interface CashMemoModalProps {
  transaction: Transaction | null;
  onClose: () => void;
  currencySymbol?: string;
  useBanglaNumerals?: boolean;
}

export const CashMemoModal: React.FC<CashMemoModalProps> = ({
  transaction,
  onClose,
  currencySymbol = '৳',
  useBanglaNumerals = true,
}) => {
  const { settings } = useApp();
  const isEn = settings.language === 'en';

  if (!transaction) return null;

  const isIncome = transaction.type === 'income';

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
      <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-5 shadow-2xl space-y-4 border border-slate-200 dark:border-slate-800">
        {/* Top Dialog Action Bar */}
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <h3 className="text-xs font-bold text-slate-800 dark:text-white">
              {isEn ? 'Digital Cash Memo / Receipt' : 'ডিজিটাল ক্যাশ মেমো / রসিদ'}
            </h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="p-1.5 rounded-lg text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              title={isEn ? 'Print' : 'প্রিন্ট করুন'}
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
              title={isEn ? 'Close' : 'বন্ধ করুন'}
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Traditional Bengali/English Cash Memo Design */}
        <div className="bg-[#fcfbf7] dark:bg-slate-950/80 p-4 rounded-2xl border-2 border-dashed border-slate-300 dark:border-slate-700 space-y-3 font-sans">
          {/* Header */}
          <div className="text-center border-b border-slate-200 dark:border-slate-800 pb-2">
            <span className="text-[10px] tracking-wider font-bold text-slate-400 uppercase">
              {isEn ? 'Income Expense Official Voucher' : 'আয় ব্যয় অফিসিয়াল ভাউচার'}
            </span>
            <h2 className="text-sm font-extrabold text-slate-900 dark:text-white mt-0.5">
              {isEn ? 'CASH MEMO / RECEIPT' : 'ক্যাশ মেমো (রসিদ)'}
            </h2>
            <p className="text-[10px] text-slate-500 dark:text-slate-400">
              {isEn ? 'Voucher No:' : 'ভাউচার নং:'} #{transaction.id.slice(-6).toUpperCase()}
            </p>
          </div>

          {/* Details Table */}
          <div className="space-y-1.5 text-xs">
            <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
              <span className="text-slate-500 dark:text-slate-400">{isEn ? 'Date & Time:' : 'তারিখ ও সময়:'}</span>
              <span className="font-semibold text-slate-800 dark:text-slate-200">
                {isEn ? transaction.date : formatBengaliDate(transaction.date)} ({transaction.time})
              </span>
            </div>

            <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
              <span className="text-slate-500 dark:text-slate-400">{isEn ? 'Type:' : 'লেনদেনের ধরন:'}</span>
              <span
                className={`font-bold flex items-center gap-1 ${
                  isIncome ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
                }`}
              >
                {isIncome ? <ArrowDownLeft className="w-3.5 h-3.5" /> : <ArrowUpRight className="w-3.5 h-3.5" />}
                {isIncome
                  ? isEn ? 'Income / Deposit' : 'আমানত / আয়'
                  : isEn ? 'Expense / Payment' : 'পরিশোধ / ব্যয়'}
              </span>
            </div>

            <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
              <span className="text-slate-500 dark:text-slate-400">{isEn ? 'Category:' : 'খাত / ক্যাটাগরি:'}</span>
              <span className="font-semibold text-slate-800 dark:text-slate-200">
                {transaction.categoryName}
              </span>
            </div>

            <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
              <span className="text-slate-500 dark:text-slate-400">{isEn ? 'Account:' : 'অ্যাকাউন্ট:'}</span>
              <span className="font-semibold text-slate-800 dark:text-slate-200">
                {transaction.accountName || (isEn ? 'Cash' : 'নগদ')}
              </span>
            </div>

            {transaction.note && (
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500 dark:text-slate-400">{isEn ? 'Note:' : 'বিবরণ / নোট:'}</span>
                <span className="font-medium text-slate-700 dark:text-slate-300 max-w-[60%] text-right truncate">
                  {transaction.note}
                </span>
              </div>
            )}
          </div>

          {/* Total Amount Box */}
          <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between">
            <span className="text-xs font-bold text-slate-600 dark:text-slate-400">
              {isEn ? 'Total Amount:' : 'সর্বমোট পরিশোধ:'}
            </span>
            <span
              className={`text-lg font-black ${
                isIncome ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
              }`}
            >
              {formatCurrency(transaction.amount, settings.useBanglaNumerals && !isEn)}
            </span>
          </div>

          <p className="text-[10px] text-slate-400 italic text-center">
            {isEn
              ? `In figures: ${currencySymbol} ${transaction.amount} only`
              : `কথায়: ${useBanglaNumerals && !isEn ? toBanglaNumber(transaction.amount) : transaction.amount} ${currencySymbol} মাত্র`}
          </p>

          {/* Signatures */}
          <div className="pt-4 flex justify-between items-end text-[10px] text-slate-400 border-t border-slate-200 dark:border-slate-800">
            <div className="text-center">
              <div className="w-16 border-b border-slate-300 dark:border-slate-700 mb-1" />
              <span>{isEn ? 'Collector' : 'আদায়কারী'}</span>
            </div>
            <div className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-bold">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>{isEn ? 'Verified Voucher' : 'অনুমোদিত ভাউচার'}</span>
            </div>
            <div className="text-center">
              <div className="w-16 border-b border-slate-300 dark:border-slate-700 mb-1" />
              <span>{isEn ? 'Signature' : 'স্বাক্ষর'}</span>
            </div>
          </div>
        </div>

        {/* Action Button */}
        <button
          onClick={handlePrint}
          className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center justify-center gap-2"
        >
          <Printer className="w-4 h-4" />
          <span>{isEn ? 'Print / Export Memo' : 'মেমো প্রিন্ট / ডাউনলোড করুন'}</span>
        </button>
      </div>
    </div>
  );
};
