import React, { useState, useEffect } from 'react';
import {
  ArrowLeft,
  Calendar as CalendarIcon,
  Clock as ClockIcon,
  Zap,
  Power,
  FileText,
  Search,
  ChevronDown,
  X,
  Check,
  ChevronLeft,
  ChevronRight,
  Edit2,
  Keyboard,
  Calculator,
  Camera,
  Image as ImageIcon,
  Trash2,
  Plus,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { getTodayString, getCurrentTimeString, formatBengaliDate, toBanglaNumber } from '../utils/formatters';

export const AddTransactionScreen: React.FC = () => {
  const {
    addTransaction,
    updateTransaction,
    editingTransaction,
    setEditingTransaction,
    accounts,
    categories,
    setActiveTab,
    settings,
  } = useApp();

  // Basic Form States
  const isEn = settings.language === 'en';
  const [type, setType] = useState<'income' | 'expense'>(
    editingTransaction?.type === 'income' ? 'income' : 'expense'
  );
  const [amount, setAmount] = useState<string>(
    editingTransaction ? String(editingTransaction.amount) : ''
  );
  const [description, setDescription] = useState<string>(
    editingTransaction?.note || ''
  );
  const [selectedTag, setSelectedTag] = useState<string>(
    editingTransaction?.categoryName || (type === 'income' ? (isEn ? 'Salary' : 'বেতন') : (isEn ? 'Food' : 'খাবার'))
  );
  const [isEditingTag, setIsEditingTag] = useState(false);

  // Date states
  const initialDate = editingTransaction?.date ? new Date(`${editingTransaction.date}T12:00:00`) : new Date();
  const [selectedYear, setSelectedYear] = useState<number>(initialDate.getFullYear());
  const [selectedMonth, setSelectedMonth] = useState<number>(initialDate.getMonth() + 1); // 1-indexed
  const [selectedDay, setSelectedDay] = useState<number>(initialDate.getDate());
  const [showDatePicker, setShowDatePicker] = useState<boolean>(false);

  // Time states
  const initialNow = new Date();
  const initialHour = initialNow.getHours();
  const [timeHour, setTimeHour] = useState<number>(initialHour % 12 || 12);
  const [timeMinute, setTimeMinute] = useState<number>(initialNow.getMinutes());
  const [timePeriod, setTimePeriod] = useState<'AM' | 'PM'>(initialHour >= 12 ? 'PM' : 'AM');
  const [showTimePicker, setShowTimePicker] = useState<boolean>(false);
  const [timePickerTarget, setTimePickerTarget] = useState<'hour' | 'minute'>('hour');
  const [isTimeInputMode, setIsTimeInputMode] = useState<boolean>(false);

  // Category bottom sheet
  const [showCatSheet, setShowCatSheet] = useState<boolean>(false);
  const [catSearch, setCatSearch] = useState<string>('');

  // Receipt voucher image state
  const [receiptImage, setReceiptImage] = useState<string | null>(
    editingTransaction?.receiptImage || null
  );
  const [showReceiptPreview, setShowReceiptPreview] = useState<boolean>(false);

  // In-App Calculator keypad state
  const [showCalculator, setShowCalculator] = useState<boolean>(false);
  const [calcExpression, setCalcExpression] = useState<string>('');

  // Initialize from editingTransaction
  useEffect(() => {
    if (!editingTransaction) {
      const now = new Date();
      const hour = now.getHours();
      setType('expense');
      setAmount('');
      setDescription('');
      setSelectedTag(isEn ? 'Food' : 'খাবার');
      setSelectedYear(now.getFullYear());
      setSelectedMonth(now.getMonth() + 1);
      setSelectedDay(now.getDate());
      setTimeHour(hour % 12 || 12);
      setTimeMinute(now.getMinutes());
      setTimePeriod(hour >= 12 ? 'PM' : 'AM');
      setReceiptImage(null);
      return;
    }
    if (editingTransaction) {
      setType(editingTransaction.type === 'income' ? 'income' : 'expense');
      setAmount(String(editingTransaction.amount));
      setDescription(editingTransaction.note || editingTransaction.categoryName || 'ব্যয়');
      setSelectedTag(editingTransaction.categoryName || (isEn ? 'Other Expense' : 'অন্যান্য খরচ'));
      setReceiptImage(editingTransaction.receiptImage || null);

      try {
        const [y, m, d] = editingTransaction.date.split('-').map(Number);
        if (y && m && d) {
          setSelectedYear(y);
          setSelectedMonth(m);
          setSelectedDay(d);
        }
      } catch {}

      if (editingTransaction.time) {
        const timeMatch = editingTransaction.time.match(/(\d+):(\d+)\s*(AM|PM)?/i);
        if (timeMatch) {
          setTimeHour(Math.min(12, Math.max(1, parseInt(timeMatch[1], 10) || 12)));
          setTimeMinute(Math.min(59, Math.max(0, parseInt(timeMatch[2], 10) || 0)));
          if (timeMatch[3]) {
            setTimePeriod(timeMatch[3].toUpperCase() as 'AM' | 'PM');
          }
        }
      }
    }
  }, [editingTransaction]);

  // Formatted date string for button display: ১৫ অক্টো, ২০২৬
  const monthNames = isEn ? ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'] : ['জানু', 'ফেব্রু', 'মার্চ', 'এপ্রি', 'মে', 'জুন', 'জুলা', 'আগ', 'সেপ্টে', 'অক্টো', 'নভে', 'ডিসে'];
  const formatDateNumber = (value: number) => isEn || !settings.useBanglaNumerals ? String(value) : toBanglaNumber(value);
  const dateDisplay = `${formatDateNumber(selectedDay)} ${monthNames[selectedMonth - 1]}, ${formatDateNumber(selectedYear)}`;
  const displayedDate = new Date(selectedYear, selectedMonth - 1, selectedDay);
  // Formatted time string for button display: ১১:৩৬ AM
  const timeDisplay = `${toBanglaNumber(String(timeHour).padStart(2, '0'))}:${toBanglaNumber(
    String(timeMinute).padStart(2, '0')
  )} ${timePeriod}`;

  // Image upload handler
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    // Reset the input so the same receipt can be selected again if needed.
    e.target.value = '';
    if (!file) return;
    if (!file.type.startsWith('image/')) return;
    if (file.size > 12 * 1024 * 1024) {
      window.alert(isEn ? 'Please choose an image smaller than 12 MB.' : '১২ MB-এর কম আকারের ছবি নির্বাচন করুন।');
      return;
    }

    // Compress receipts before storing them in local/Firestore data. Firestore
    // documents have a 1 MiB limit; storing raw phone photos often exceeds it.
    const reader = new FileReader();
    reader.onerror = () => window.alert(isEn ? 'Could not read this image.' : 'ছবিটি পড়া যায়নি।');
    reader.onload = () => {
      const image = new Image();
      image.onerror = () => window.alert(isEn ? 'This image could not be opened.' : 'ছবিটি খোলা যায়নি।');
      image.onload = () => {
        const maxDimension = 1400;
        const scale = Math.min(1, maxDimension / Math.max(image.naturalWidth, image.naturalHeight));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
        canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
        const context = canvas.getContext('2d');
        if (!context) {
          window.alert(isEn ? 'Image compression is unavailable.' : 'ছবি ছোট করার সুবিধা পাওয়া যাচ্ছে না।');
          return;
        }
        context.drawImage(image, 0, 0, canvas.width, canvas.height);
        let compressed = canvas.toDataURL('image/jpeg', 0.68);
        if (compressed.length > 900_000) {
          const smallerCanvas = document.createElement('canvas');
          const smallerScale = Math.min(1, 1000 / Math.max(image.naturalWidth, image.naturalHeight));
          smallerCanvas.width = Math.max(1, Math.round(image.naturalWidth * smallerScale));
          smallerCanvas.height = Math.max(1, Math.round(image.naturalHeight * smallerScale));
          const smallerContext = smallerCanvas.getContext('2d');
          if (smallerContext) {
            smallerContext.drawImage(image, 0, 0, smallerCanvas.width, smallerCanvas.height);
            compressed = smallerCanvas.toDataURL('image/jpeg', 0.52);
          }
        }
        if (compressed.length > 900_000) {
          window.alert(isEn ? 'This image is still too large. Please choose a smaller image.' : 'ছবিটি এখনও অনেক বড়। আরও ছোট ছবি নির্বাচন করুন।');
          return;
        }
        setReceiptImage(compressed);
      };
      image.src = String(reader.result || '');
    };
    reader.readAsDataURL(file);
  };

  // Calculator logic
  const handleCalcPress = (val: string) => {
    if (val === 'AC') {
      setCalcExpression('');
      setAmount('');
    } else if (val === '⌫') {
      const next = calcExpression.slice(0, -1);
      setCalcExpression(next);
      try {
        if (next && !isNaN(Number(next))) {
          setAmount(next);
        }
      } catch {}
    } else if (val === '=') {
      try {
        // Safe evaluation of basic arithmetic
        const sanitized = calcExpression.replace(/×/g, '*').replace(/÷/g, '/');
        // Validate characters
        if (/^[0-9+\-*/.() ]+$/.test(sanitized)) {
          const tokens = sanitized.match(/(?:\d+(?:\.\d*)?|\.\d+)|[()+\-*/]/g) || [];
          if (tokens.join('') !== sanitized.replace(/\s/g, '') || tokens.length === 0) return;
          let index = 0;
          const parsePrimary = (): number => {
            const token = tokens[index++];
            if (token === '+') return parsePrimary();
            if (token === '-') return -parsePrimary();
            if (token === '(') {
              const value = parseExpression();
              if (tokens[index++] !== ')') throw new Error('Missing closing parenthesis');
              return value;
            }
            if (token === undefined || !/^\d+(?:\.\d*)?$|^\.\d+$/.test(token)) throw new Error('Invalid number');
            return Number(token);
          };
          const parseTerm = (): number => {
            let value = parsePrimary();
            while (tokens[index] === '*' || tokens[index] === '/') {
              const operator = tokens[index++];
              const right = parsePrimary();
              if (operator === '/' && right === 0) throw new Error('Division by zero');
              value = operator === '*' ? value * right : value / right;
            }
            return value;
          };
          const parseExpression = (): number => {
            let value = parseTerm();
            while (tokens[index] === '+' || tokens[index] === '-') {
              const operator = tokens[index++];
              const right = parseTerm();
              value = operator === '+' ? value + right : value - right;
            }
            return value;
          };
          const result = parseExpression();
          if (index !== tokens.length || !Number.isFinite(result)) throw new Error('Invalid expression');
          const formatted = String(Math.round(result * 100) / 100);
          setAmount(formatted);
          setCalcExpression(formatted);
        }
      } catch {}
    } else {
      const next = calcExpression + val;
      setCalcExpression(next);
      if (!isNaN(Number(next))) {
        setAmount(next);
      }
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const normalizedAmount = amount.trim().replace(/,/g, '');
    if (!/^(?:\d+\.?\d*|\.\d+)$/.test(normalizedAmount)) return;
    const numAmount = Number(normalizedAmount);
    if (!Number.isFinite(numAmount) || numAmount <= 0) return;

    const rawDate = `${selectedYear}-${String(selectedMonth).padStart(2, '0')}-${String(
      selectedDay
    ).padStart(2, '0')}`;
    const rawTime = `${timeHour}:${String(timeMinute).padStart(2, '0')} ${timePeriod}`;

    const acc = accounts[0] || { id: 'acc_cash', name: 'নগদ ক্যাশ (টাকা)' };

    if (editingTransaction) {
      updateTransaction(editingTransaction.id, {
        type,
        amount: numAmount,
        categoryName: selectedTag,
        note: description.trim() || undefined,
        date: rawDate,
        time: rawTime,
        categoryColor: type === 'expense' ? '#ef4444' : '#10b981',
        receiptImage: receiptImage || undefined,
      });
      setEditingTransaction(null);
    } else {
      addTransaction({
        type,
        amount: numAmount,
        categoryId: 'cat_custom',
        categoryName: selectedTag,
        categoryIcon: 'Tag',
        categoryColor: type === 'expense' ? '#ef4444' : '#10b981',
        accountId: acc.id,
        accountName: acc.name,
        date: rawDate,
        time: rawTime,
        note: description.trim() || undefined,
        receiptImage: receiptImage || undefined,
      });
    }

    setActiveTab('dashboard');
  };

  const handleClear = () => {
    setAmount('');
    setDescription('');
    setReceiptImage(null);
    setCalcExpression('');
  };

  const handleGoBack = () => {
    setEditingTransaction(null);
    setActiveTab('dashboard');
  };

  // Helper calculation for Date Picker calendar
  const daysInMonth = new Date(selectedYear, selectedMonth, 0).getDate();
  const firstDayOfWeek = new Date(selectedYear, selectedMonth - 1, 1).getDay(); // 0 is Sunday
  const calendarCells = [];
  for (let i = 0; i < firstDayOfWeek; i++) {
    calendarCells.push(null);
  }
  for (let d = 1; d <= daysInMonth; d++) {
    calendarCells.push(d);
  }

  // Helper for analog clock dial positions
  const getClockCoordinates = (index: number, total: number, radius: number = 85) => {
    const angle = (index * (360 / total) - 90) * (Math.PI / 180);
    const x = Math.round(radius * Math.cos(angle));
    const y = Math.round(radius * Math.sin(angle));
    return { x, y };
  };

  return (
    <div className="space-y-4 pb-20 pt-1">
      {/* Top Header: ← Update / New */}
      <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={handleGoBack}
            className="p-1 rounded-full text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="text-base font-bold text-slate-900 dark:text-white">
            {isEn
              ? editingTransaction
                ? 'Update Transaction'
                : 'New Transaction'
              : editingTransaction
              ? 'আপডেট'
              : 'নতুন'}
          </h2>
        </div>

        {!editingTransaction && (
          <div className="flex items-center gap-3 text-slate-400">
            <button
              type="button"
              onClick={handleClear}
              className="hover:text-rose-500 p-1"
              title={isEn ? 'Reset form' : 'রিসেট করুন'}
            >
              <Power className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      <form onSubmit={handleSave} className="space-y-4 px-1">
        {/* Row 1: Date & Time Buttons */}
        <div className="grid grid-cols-2 gap-3">
          {/* Date Button */}
          <button
            type="button"
            onClick={() => setShowDatePicker(true)}
            className="py-3 px-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center justify-center gap-2 shadow-xs hover:border-blue-400 transition-colors"
          >
            <CalendarIcon className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <span>{dateDisplay}</span>
          </button>

          {/* Time Button */}
          <button
            type="button"
            onClick={() => setShowTimePicker(true)}
            className="py-3 px-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center justify-center gap-2 shadow-xs hover:border-blue-400 transition-colors"
          >
            <ClockIcon className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <span>{timeDisplay}</span>
          </button>
        </div>

        {/* Row 2: Type Switcher: Income | Expense */}
        <div className="grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={() => {
              setType('income');
              if (selectedTag === 'ব্যয়' || selectedTag === 'Expense' || selectedTag === 'খাবার') {
                setSelectedTag(isEn ? 'Salary' : 'বেতন');
              }
            }}
            className={`py-3 rounded-xl font-bold text-xs transition-all ${
              type === 'income'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
            }`}
          >
            {isEn ? 'Income' : 'আয়'}
          </button>

          <button
            type="button"
            onClick={() => {
              setType('expense');
              if (selectedTag === 'আয়' || selectedTag === 'Income' || selectedTag === 'বেতন') {
                setSelectedTag(isEn ? 'Food' : 'খাবার');
              }
            }}
            className={`py-3 rounded-xl font-bold text-xs transition-all ${
              type === 'expense'
                ? 'bg-[#f44336] text-white shadow-xs'
                : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
            }`}
          >
            {isEn ? 'Expense' : 'ব্যয়'}
          </button>
        </div>

        {/* Row 3: Category / Tag Row */}
        <div className="flex items-center gap-2">
          {/* Round Search button */}
          <button
            type="button"
            onClick={() => setShowCatSheet(true)}
            className="w-10 h-10 rounded-full border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 flex items-center justify-center text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 shadow-xs flex-shrink-0"
            title={isEn ? 'Choose Category' : 'ক্যাটাগরি খুঁজুন'}
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Tag Pill / Input */}
          {isEditingTag ? (
            <div className="flex-1 flex items-center bg-white dark:bg-slate-900 border border-blue-400 rounded-full px-3 py-1.5 shadow-xs">
              <input
                type="text"
                value={selectedTag}
                onChange={(e) => setSelectedTag(e.target.value)}
                className="w-full text-xs font-semibold bg-transparent focus:outline-none"
                autoFocus
              />
              <button
                type="button"
                onClick={() => setIsEditingTag(false)}
                className="p-1 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <div
              onClick={() => setIsEditingTag(true)}
              className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-white text-xs font-bold shadow-xs transition-transform active:scale-95"
              style={{
                backgroundColor: type === 'expense' ? '#f44336' : '#10b981',
              }}
            >
              <span>{selectedTag}</span>
            </div>
          )}
        </div>

        {/* Row 4: Floating Label Amount Input + In-App Calculator Button */}
        <div className="space-y-2">
          <div className="relative border border-slate-200 dark:border-slate-700 rounded-xl px-3 pt-2.5 pb-2 bg-white dark:bg-slate-900 focus-within:ring-2 focus-within:ring-blue-500 shadow-xs transition-all flex items-center justify-between">
            <label className="absolute -top-2.5 left-3 px-1.5 bg-white dark:bg-slate-900 text-[11px] font-semibold text-slate-500 dark:text-slate-400">
              {isEn ? 'Amount (৳ / BDT)' : 'টাকার পরিমাণ'}
            </label>
            <div className="flex items-center gap-2.5 flex-1">
              <span className="text-slate-400 font-bold text-xs">৳</span>
              <input
                type="text"
                inputMode="decimal"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="500.0"
                className="w-full text-sm font-bold text-slate-900 dark:text-white bg-transparent focus:outline-none"
                required
              />
            </div>
            {/* Calculator Toggle Button */}
            <button
              type="button"
              onClick={() => setShowCalculator((c) => !c)}
              className={`p-1.5 rounded-lg transition-colors ${
                showCalculator
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-400 hover:text-blue-600 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
              title={isEn ? 'Toggle Calculator Keypad' : 'ক্যালকুলেটর কিপ্যাড'}
            >
              <Calculator className="w-4 h-4" />
            </button>
          </div>

          {/* In-App Calculator Keypad */}
          {showCalculator && (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-3 shadow-lg space-y-2 animate-in fade-in">
              <div className="bg-slate-50 dark:bg-slate-800/60 rounded-xl px-3 py-2 text-right">
                <span className="text-[11px] text-slate-400 block font-mono">
                  {calcExpression || (isEn ? 'Calculate...' : 'হিসাব করুন')}
                </span>
                <span className="text-base font-bold text-slate-900 dark:text-white">
                  ৳ {amount || (isEn ? '0' : '০')}
                </span>
              </div>
              <div className="grid grid-cols-4 gap-1.5 text-xs font-bold text-slate-700 dark:text-slate-200">
                <button
                  type="button"
                  onClick={() => handleCalcPress('AC')}
                  className="py-2.5 rounded-xl bg-rose-50 text-rose-600 dark:bg-rose-950/40 dark:text-rose-400 hover:bg-rose-100"
                >
                  AC
                </button>
                <button
                  type="button"
                  onClick={() => handleCalcPress('(')}
                  className="py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200"
                >
                  (
                </button>
                <button
                  type="button"
                  onClick={() => handleCalcPress(')')}
                  className="py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200"
                >
                  )
                </button>
                <button
                  type="button"
                  onClick={() => handleCalcPress('÷')}
                  className="py-2.5 rounded-xl bg-blue-50 text-blue-600 dark:bg-blue-950/60 dark:text-blue-400 hover:bg-blue-100"
                >
                  ÷
                </button>

                <button
                  type="button"
                  onClick={() => handleCalcPress('7')}
                  className="py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200"
                >
                  7
                </button>
                <button
                  type="button"
                  onClick={() => handleCalcPress('8')}
                  className="py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200"
                >
                  8
                </button>
                <button
                  type="button"
                  onClick={() => handleCalcPress('9')}
                  className="py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200"
                >
                  9
                </button>
                <button
                  type="button"
                  onClick={() => handleCalcPress('×')}
                  className="py-2.5 rounded-xl bg-blue-50 text-blue-600 dark:bg-blue-950/60 dark:text-blue-400 hover:bg-blue-100"
                >
                  ×
                </button>

                <button
                  type="button"
                  onClick={() => handleCalcPress('4')}
                  className="py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200"
                >
                  4
                </button>
                <button
                  type="button"
                  onClick={() => handleCalcPress('5')}
                  className="py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200"
                >
                  5
                </button>
                <button
                  type="button"
                  onClick={() => handleCalcPress('6')}
                  className="py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200"
                >
                  6
                </button>
                <button
                  type="button"
                  onClick={() => handleCalcPress('-')}
                  className="py-2.5 rounded-xl bg-blue-50 text-blue-600 dark:bg-blue-950/60 dark:text-blue-400 hover:bg-blue-100"
                >
                  -
                </button>

                <button
                  type="button"
                  onClick={() => handleCalcPress('1')}
                  className="py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200"
                >
                  1
                </button>
                <button
                  type="button"
                  onClick={() => handleCalcPress('2')}
                  className="py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200"
                >
                  2
                </button>
                <button
                  type="button"
                  onClick={() => handleCalcPress('3')}
                  className="py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200"
                >
                  3
                </button>
                <button
                  type="button"
                  onClick={() => handleCalcPress('+')}
                  className="py-2.5 rounded-xl bg-blue-50 text-blue-600 dark:bg-blue-950/60 dark:text-blue-400 hover:bg-blue-100"
                >
                  +
                </button>

                <button
                  type="button"
                  onClick={() => handleCalcPress('0')}
                  className="py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200"
                >
                  0
                </button>
                <button
                  type="button"
                  onClick={() => handleCalcPress('.')}
                  className="py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200"
                >
                  .
                </button>
                <button
                  type="button"
                  onClick={() => handleCalcPress('⌫')}
                  className="py-2.5 rounded-xl bg-amber-50 text-amber-600 dark:bg-amber-950/40 dark:text-amber-400 hover:bg-amber-100"
                >
                  ⌫
                </button>
                <button
                  type="button"
                  onClick={() => handleCalcPress('=')}
                  className="py-2.5 rounded-xl bg-blue-600 text-white font-bold hover:bg-blue-700 shadow-sm"
                >
                  =
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Row 5: Description Input with Note Icon */}
        <div className="border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-3 bg-white dark:bg-slate-900 flex items-center gap-2.5 shadow-xs focus-within:ring-2 focus-within:ring-blue-500 transition-all">
          <FileText className="w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder={isEn ? 'Description / Note' : 'বিবরণ লিখুন'}
            className="w-full text-xs text-slate-800 dark:text-slate-100 bg-transparent focus:outline-none"
          />
        </div>

        {/* Row 6: Receipt Memo / Voucher Attachment */}
        <div className="space-y-2">
          {!receiptImage ? (
            <label className="flex items-center justify-center gap-2 py-3 px-4 border border-dashed border-slate-300 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:border-blue-500 cursor-pointer transition-colors shadow-xs">
              <Camera className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <span>{isEn ? 'Attach Voucher / Receipt Photo' : 'মেমো / ভাউচারের ছবি যুক্ত করুন'}</span>
              <input
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                className="hidden"
              />
            </label>
          ) : (
            <div className="flex items-center justify-between p-2.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl">
              <div
                onClick={() => setShowReceiptPreview(true)}
                className="flex items-center gap-2.5 cursor-pointer flex-1"
              >
                <img
                  src={receiptImage}
                  alt="Receipt"
                  className="w-10 h-10 object-cover rounded-lg border border-slate-200 dark:border-slate-700"
                />
                <div>
                  <span className="text-xs font-bold text-slate-800 dark:text-white block">
                    {isEn ? 'Attached Voucher' : 'সংযুক্ত ভাউচার'}
                  </span>
                  <span className="text-[10px] text-blue-600 dark:text-blue-400">
                    {isEn ? 'Click to view full size' : 'বড় করে দেখতে ক্লিক করুন'}
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setReceiptImage(null)}
                className="p-1.5 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors"
                title={isEn ? 'Delete photo' : 'ছবি মুছুন'}
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>

        {/* Row 7: Big Primary Blue Button: Update / Add */}
        <div className="pt-2">
          <button
            type="submit"
            className="w-full py-3.5 rounded-xl bg-[#1a73e8] hover:bg-blue-600 text-white font-bold text-sm shadow-md shadow-blue-500/20 transition-all active:scale-95"
          >
            {isEn
              ? editingTransaction
                ? 'Update Transaction'
                : 'Save Transaction'
              : editingTransaction
              ? 'আপডেট'
              : 'অ্যাড'}
          </button>
        </div>
      </form>

      {/* Receipt Image Full Preview Modal */}
      {showReceiptPreview && receiptImage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 max-w-sm w-full space-y-3 shadow-2xl border border-slate-100 dark:border-slate-800">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-800 dark:text-white">
                {isEn ? 'Voucher / Receipt Image' : 'ভাউচার / মেমোর ছবি'}
              </h4>
              <button
                type="button"
                onClick={() => setShowReceiptPreview(false)}
                className="p-1 text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <img
              src={receiptImage}
              alt="Receipt Preview"
              className="w-full max-h-[60vh] object-contain rounded-2xl bg-black/5"
            />
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* Material Design Date Picker Modal matching video 00:12 exactly */}
      {/* ============================================================== */}
      {showDatePicker && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl overflow-hidden shadow-2xl border border-slate-100 dark:border-slate-800 max-w-xs w-full">
            {/* Header */}
            <div className="bg-white dark:bg-slate-900 px-6 pt-5 pb-3 border-b border-slate-100 dark:border-slate-800">
              <span className="text-xs text-slate-400 block font-medium">Select date</span>
              <div className="flex items-center justify-between mt-1">
                <h3 className="text-xl font-bold text-slate-900 dark:text-white">
                  {displayedDate.toLocaleDateString(isEn ? 'en-US' : 'bn-BD', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })}
                </h3>
                <button
                  type="button"
                  className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Calendar Controls */}
            <div className="p-4 space-y-3">
              <div className="flex items-center justify-between px-2">
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                  {displayedDate.toLocaleDateString(isEn ? 'en-US' : 'bn-BD', { month: 'long', year: 'numeric' })}
                </span>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => {
                      const nextMonth = selectedMonth === 1 ? 12 : selectedMonth - 1;
                      const nextYear = selectedMonth === 1 ? selectedYear - 1 : selectedYear;
                      setSelectedMonth(nextMonth); setSelectedYear(nextYear);
                      setSelectedDay((day) => Math.min(day, new Date(nextYear, nextMonth, 0).getDate()));
                    }}
                    className="p-1 rounded-full text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const nextMonth = selectedMonth === 12 ? 1 : selectedMonth + 1;
                      const nextYear = selectedMonth === 12 ? selectedYear + 1 : selectedYear;
                      setSelectedMonth(nextMonth); setSelectedYear(nextYear);
                      setSelectedDay((day) => Math.min(day, new Date(nextYear, nextMonth, 0).getDate()));
                    }}
                    className="p-1 rounded-full text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Day headers: S M T W T F S */}
              <div className="grid grid-cols-7 text-center text-[10px] font-semibold text-slate-400">
                <span>S</span>
                <span>M</span>
                <span>T</span>
                <span>W</span>
                <span>T</span>
                <span>F</span>
                <span>S</span>
              </div>

              {/* Days Grid */}
              <div className="grid grid-cols-7 gap-1 text-center">
                {calendarCells.map((cell, idx) => {
                  if (cell === null) {
                    return <div key={`empty-${idx}`} className="h-8" />;
                  }

                  const isSelected = cell === selectedDay;
                  return (
                    <button
                      key={`day-${cell}`}
                      type="button"
                      onClick={() => setSelectedDay(cell)}
                      className={`h-8 w-8 mx-auto rounded-full text-xs font-medium flex items-center justify-center transition-all ${
                        isSelected
                          ? 'bg-[#f44336] text-white font-bold shadow-xs'
                          : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                      }`}
                    >
                      {cell}
                    </button>
                  );
                })}
              </div>

              {/* Footer Buttons */}
              <div className="flex justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800 text-xs font-bold">
                <button
                  type="button"
                  onClick={() => setShowDatePicker(false)}
                  className="px-3 py-1.5 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/40 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => setShowDatePicker(false)}
                  className="px-3 py-1.5 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/40 rounded-lg"
                >
                  OK
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* Material Design Time Picker Modal matching video 00:14 - 00:21 */}
      {/* ============================================================== */}
      {showTimePicker && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 shadow-2xl border border-slate-100 dark:border-slate-800 max-w-xs w-full space-y-4">
            {/* Header */}
            <div>
              <span className="text-xs text-slate-400 font-medium">
                {isTimeInputMode ? 'Enter time' : 'Select time'}
              </span>
            </div>

            {/* Time Digit Boxes + AM/PM Toggle matching video 00:14 */}
            <div className="flex items-center justify-center gap-2">
              {/* Hour Box */}
              <button
                type="button"
                onClick={() => setTimePickerTarget('hour')}
                className={`w-16 h-16 rounded-xl flex items-center justify-center text-3xl font-bold transition-all ${
                  timePickerTarget === 'hour' && !isTimeInputMode
                    ? 'bg-blue-500 text-white shadow-xs'
                    : isTimeInputMode
                    ? 'bg-slate-100 dark:bg-slate-800 border border-blue-500 text-slate-900 dark:text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                }`}
              >
                {String(timeHour).padStart(2, '0')}
              </button>

              <span className="text-2xl font-bold text-slate-400">:</span>

              {/* Minute Box */}
              <button
                type="button"
                onClick={() => setTimePickerTarget('minute')}
                className={`w-16 h-16 rounded-xl flex items-center justify-center text-3xl font-bold transition-all ${
                  timePickerTarget === 'minute' && !isTimeInputMode
                    ? 'bg-blue-500 text-white shadow-xs'
                    : isTimeInputMode
                    ? 'bg-slate-100 dark:bg-slate-800 border border-slate-300 text-slate-900 dark:text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                }`}
              >
                {String(timeMinute).padStart(2, '0')}
              </button>

              {/* AM / PM Column */}
              <div className="flex flex-col rounded-xl border border-slate-200 dark:border-slate-700 overflow-hidden ml-1">
                <button
                  type="button"
                  onClick={() => setTimePeriod('AM')}
                  className={`px-3 py-1.5 text-xs font-bold transition-colors ${
                    timePeriod === 'AM'
                      ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50'
                  }`}
                >
                  AM
                </button>
                <button
                  type="button"
                  onClick={() => setTimePeriod('PM')}
                  className={`px-3 py-1.5 text-xs font-bold border-t border-slate-200 dark:border-slate-700 transition-colors ${
                    timePeriod === 'PM'
                      ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50'
                  }`}
                >
                  PM
                </button>
              </div>
            </div>

            {/* Mode A: Analog Circular Clock Face matching video 00:14 */}
            {!isTimeInputMode ? (
              <div className="relative w-52 h-52 mx-auto rounded-full bg-slate-100 dark:bg-slate-800/80 flex items-center justify-center my-2 select-none">
                {/* Center dot */}
                <div className="w-2 h-2 rounded-full bg-blue-500 z-10" />

                {timePickerTarget === 'hour' ? (
                  // 1-12 Hour Dial
                  <>
                    {[12, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].map((h, idx) => {
                      const { x, y } = getClockCoordinates(idx, 12, 75);
                      const isSelected = timeHour === h;
                      return (
                        <button
                          key={`hour-${h}`}
                          type="button"
                          onClick={() => {
                            setTimeHour(h);
                            setTimePickerTarget('minute');
                          }}
                          style={{
                            transform: `translate(${x}px, ${y}px)`,
                          }}
                          className={`absolute w-7 h-7 rounded-full text-xs font-semibold flex items-center justify-center transition-all ${
                            isSelected
                              ? 'bg-blue-500 text-white font-bold scale-110 z-20 shadow-xs'
                              : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                          }`}
                        >
                          {h}
                        </button>
                      );
                    })}
                  </>
                ) : (
                  // 00-55 Minute Dial
                  <>
                    {[0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55].map((m, idx) => {
                      const { x, y } = getClockCoordinates(idx, 12, 75);
                      const isSelected = Math.abs(timeMinute - m) <= 2;
                      return (
                        <button
                          key={`min-${m}`}
                          type="button"
                          onClick={() => setTimeMinute(m)}
                          style={{
                            transform: `translate(${x}px, ${y}px)`,
                          }}
                          className={`absolute w-7 h-7 rounded-full text-xs font-semibold flex items-center justify-center transition-all ${
                            isSelected
                              ? 'bg-blue-500 text-white font-bold scale-110 z-20 shadow-xs'
                              : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                          }`}
                        >
                          {String(m).padStart(2, '0')}
                        </button>
                      );
                    })}
                  </>
                )}
              </div>
            ) : (
              // Mode B: Digital Input Mode matching video 00:18
              <div className="py-6 flex justify-center items-center gap-4">
                <div className="text-center">
                  <input
                    type="number"
                    min="1"
                    max="12"
                    value={timeHour}
                    onChange={(e) => setTimeHour(Math.min(12, Math.max(1, parseInt(e.target.value, 10) || 1)))}
                    className="w-16 h-12 text-center text-xl font-bold bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  />
                  <span className="text-[10px] text-slate-400 block mt-1">Hour</span>
                </div>
                <span className="text-xl font-bold">:</span>
                <div className="text-center">
                  <input
                    type="number"
                    min="0"
                    max="59"
                    value={timeMinute}
                    onChange={(e) => setTimeMinute(Math.min(59, Math.max(0, parseInt(e.target.value, 10) || 0)))}
                    className="w-16 h-12 text-center text-xl font-bold bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  />
                  <span className="text-[10px] text-slate-400 block mt-1">Minute</span>
                </div>
              </div>
            )}

            {/* Footer Buttons + Mode Switcher */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setIsTimeInputMode(!isTimeInputMode)}
                className="p-2 text-slate-500 hover:text-blue-600 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                title={isTimeInputMode ? 'ডায়াল মোড' : 'কীবোর্ড মোড'}
              >
                {isTimeInputMode ? (
                  <ClockIcon className="w-5 h-5" />
                ) : (
                  <Keyboard className="w-5 h-5" />
                )}
              </button>

              <div className="flex gap-2 text-xs font-bold">
                <button
                  type="button"
                  onClick={() => setShowTimePicker(false)}
                  className="px-3 py-1.5 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/40 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => setShowTimePicker(false)}
                  className="px-3 py-1.5 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/40 rounded-lg"
                >
                  OK
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Category Bottom Sheet */}
      {showCatSheet && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-t-3xl p-5 space-y-4 max-h-[70vh] flex flex-col shadow-2xl border-t border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-800 dark:text-white">
                {isEn ? 'Select Category' : 'ক্যাটাগরি বেছে নিন'} ({isEn ? (type === 'income' ? 'Income' : 'Expense') : (type === 'income' ? 'আয়' : 'ব্যয়')})
              </h4>
              <button
                onClick={() => setShowCatSheet(false)}
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={catSearch}
                onChange={(e) => setCatSearch(e.target.value)}
                placeholder={isEn ? 'Search category...' : 'ক্যাটাগরি খুঁজুন...'}
                className="w-full pl-9 pr-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
              {(() => {
                const typeCategories = categories.filter((c) => c.type === type);
                const list = typeCategories.length > 0 ? typeCategories : categories;
                const filtered = list.filter((c) =>
                  c.name.toLowerCase().includes(catSearch.toLowerCase())
                );

                if (filtered.length === 0 && catSearch.trim()) {
                  return (
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedTag(catSearch.trim());
                        setShowCatSheet(false);
                      }}
                      className="w-full py-3 text-left text-xs font-medium text-blue-600 dark:text-blue-400 flex items-center justify-between"
                    >
                      <span>
                        {isEn ? `Use custom: "${catSearch.trim()}"` : `কাস্টম ব্যবহার করুন: "${catSearch.trim()}"`}
                      </span>
                      <Plus className="w-4 h-4" />
                    </button>
                  );
                }

                return filtered.map((cat) => (
                  <button
                    key={cat.id || cat.name}
                    type="button"
                    onClick={() => {
                      setSelectedTag(cat.name);
                      setShowCatSheet(false);
                    }}
                    className="w-full py-2.5 text-left text-xs font-medium text-slate-800 dark:text-slate-200 hover:text-blue-600 dark:hover:text-blue-400 flex items-center justify-between"
                  >
                    <div className="flex items-center gap-2.5">
                      <span
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: cat.color || '#2563eb' }}
                      />
                      <span>{cat.name}</span>
                    </div>
                    {selectedTag === cat.name && (
                      <Check className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                    )}
                  </button>
                ));
              })()}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
