import React, { useState, useEffect } from 'react';
import {
  ArrowLeft,
  Plus,
  Zap,
  Coffee,
  Bus,
  Utensils,
  ShoppingBag,
  Smartphone,
  Briefcase,
  CheckCircle2,
  Trash2,
  Tag,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import {
  formatCurrency,
  toBanglaNumber,
  getTodayString,
  getCurrentTimeString,
} from '../utils/formatters';

interface QuickPreset {
  id: string;
  title: string;
  titleEn: string;
  amount: number;
  type: 'income' | 'expense';
  categoryId: string;
  categoryName: string;
  icon: string;
  color: string;
}

const DEFAULT_PRESETS: QuickPreset[] = [
  {
    id: 'qp_tea',
    title: 'সকালের চা ও নাস্তা',
    titleEn: 'Morning Tea & Snack',
    amount: 30,
    type: 'expense',
    categoryId: 'cat_food',
    categoryName: 'খাবার ও পানীয়',
    icon: 'Coffee',
    color: '#f97316',
  },
  {
    id: 'qp_bus',
    title: 'রিকশা / বাস ভাড়া',
    titleEn: 'Bus / Rickshaw Fare',
    amount: 60,
    type: 'expense',
    categoryId: 'cat_transport',
    categoryName: 'যাতায়াত',
    icon: 'Bus',
    color: '#06b6d4',
  },
  {
    id: 'qp_lunch',
    title: 'দুপুরের খাবার',
    titleEn: 'Office Lunch',
    amount: 150,
    type: 'expense',
    categoryId: 'cat_food',
    categoryName: 'খাবার ও পানীয়',
    icon: 'Utensils',
    color: '#10b981',
  },
  {
    id: 'qp_recharge',
    title: 'মোবাইল রিচার্জ',
    titleEn: 'Mobile Recharge',
    amount: 100,
    type: 'expense',
    categoryId: 'cat_bill',
    categoryName: 'বিল ও ইউটিলিটি',
    icon: 'Smartphone',
    color: '#8b5cf6',
  },
  {
    id: 'qp_bazaar',
    title: 'কাঁচা বাজার ও মুদি',
    titleEn: 'Grocery & Market',
    amount: 500,
    type: 'expense',
    categoryId: 'cat_shopping',
    categoryName: 'কেনাকাটা',
    icon: 'ShoppingBag',
    color: '#ec4899',
  },
  {
    id: 'qp_salary',
    title: 'মাসিক বেতন',
    titleEn: 'Monthly Salary',
    amount: 35000,
    type: 'income',
    categoryId: 'cat_salary',
    categoryName: 'বেতন',
    icon: 'Briefcase',
    color: '#22c55e',
  },
];

const STORAGE_KEY_PRESETS = 'ay_byay_quick_presets_v2';

export const QuickEntryScreen: React.FC = () => {
  const { setActiveTab, addTransaction, categories, accounts, settings } = useApp();
  const isEn = settings.language === 'en';

  const [presets, setPresets] = useState<QuickPreset[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_PRESETS);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return DEFAULT_PRESETS;
  });

  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newAmount, setNewAmount] = useState('');
  const [newType, setNewType] = useState<'income' | 'expense'>('expense');
  const [newCatId, setNewCatId] = useState('');

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY_PRESETS, JSON.stringify(presets)); } catch (error) { console.warn('Could not save quick-entry presets locally.', error); }
  }, [presets]);

  const handleExecutePreset = (preset: QuickPreset) => {
    const acc = accounts[0] || { id: 'acc_cash', name: isEn ? 'Cash' : 'নগদ' };
    addTransaction({
      type: preset.type,
      amount: preset.amount,
      categoryId: preset.categoryId,
      categoryName: preset.categoryName,
      categoryColor: preset.color,
      categoryIcon: preset.icon,
      accountId: acc.id,
      accountName: acc.name,
      date: getTodayString(),
      time: getCurrentTimeString(),
      note: isEn ? (preset.titleEn || preset.title) : preset.title,
    });

    const formattedAmt = formatCurrency(preset.amount, settings.useBanglaNumerals && !isEn);
    const titleText = isEn ? (preset.titleEn || preset.title) : preset.title;
    setToastMessage(
      isEn
        ? `Added 1-Tap Entry: ${titleText} (${formattedAmt})`
        : `যুক্ত হয়েছে: ${titleText} (${formattedAmt})`
    );
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleCreatePreset = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(newAmount);
    if (!newTitle.trim() || isNaN(val) || val <= 0) return;

    const cat = categories.find((c) => c.id === newCatId) || {
      id: 'cat_general',
      name: isEn ? 'General' : 'সাধারণ',
      color: '#3b82f6',
      icon: 'Tag',
    };

    const newP: QuickPreset = {
      id: `qp_${Date.now()}`,
      title: newTitle.trim(),
      titleEn: newTitle.trim(),
      amount: val,
      type: newType,
      categoryId: cat.id,
      categoryName: cat.name,
      icon: cat.icon || 'Zap',
      color: cat.color || '#3b82f6',
    };

    setPresets([newP, ...presets]);
    setIsModalOpen(false);
    setNewTitle('');
    setNewAmount('');
    setToastMessage(isEn ? 'Quick preset created!' : 'কুইক এন্ট্রি টেমপ্লেট তৈরি হয়েছে!');
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleDeletePreset = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setPresets(presets.filter((p) => p.id !== id));
  };

  const renderPresetIcon = (iconName: string) => {
    switch (iconName) {
      case 'Coffee':
        return <Coffee className="w-5 h-5" />;
      case 'Bus':
        return <Bus className="w-5 h-5" />;
      case 'Utensils':
        return <Utensils className="w-5 h-5" />;
      case 'ShoppingBag':
        return <ShoppingBag className="w-5 h-5" />;
      case 'Smartphone':
        return <Smartphone className="w-5 h-5" />;
      case 'Briefcase':
        return <Briefcase className="w-5 h-5" />;
      default:
        return <Zap className="w-5 h-5" />;
    }
  };

  return (
    <div className="space-y-4 pb-24 pt-1">
      {/* Header */}
      <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setActiveTab('dashboard')}
            className="p-1 rounded-full text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title={isEn ? 'Back' : 'পেছনে যান'}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-amber-500 fill-amber-500" />
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              {isEn ? 'Quick 1-Tap Entry' : 'কুইক এন্ট্রি (১-ট্যাপ)'}
            </h2>
          </div>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="border border-blue-200 dark:border-blue-800 text-blue-600 dark:text-blue-400 bg-blue-50/20 hover:bg-blue-50/80 dark:hover:bg-blue-950/40 rounded-xl px-3 py-1.5 text-xs font-semibold flex items-center gap-1 transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>{isEn ? 'New Template' : 'নতুন টেমপ্লেট'}</span>
        </button>
      </div>

      <p className="text-xs text-slate-500 dark:text-slate-400 px-1">
        {isEn
          ? 'Tap any card below to instantly record the transaction with 1 tap!'
          : 'নিচের যেকোনো কার্ডে ১-ট্যাপ করলেই স্বয়ংক্রিয়ভাবে লেনদেন যুক্ত হয়ে যাবে!'}
      </p>

      {/* Grid of Quick Entries */}
      <div className="grid grid-cols-2 gap-3 px-1">
        {presets.map((preset) => (
          <div
            key={preset.id}
            onClick={() => handleExecutePreset(preset)}
            className="group relative bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-100 dark:border-slate-800 shadow-xs hover:border-blue-500 dark:hover:border-blue-500 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between active:scale-98"
          >
            <div className="flex items-start justify-between">
              <div
                className="w-10 h-10 rounded-2xl flex items-center justify-center text-white shadow-xs"
                style={{ backgroundColor: preset.color }}
              >
                {renderPresetIcon(preset.icon)}
              </div>
              <button
                onClick={(e) => handleDeletePreset(preset.id, e)}
                className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-rose-500 rounded-lg transition-opacity"
                title={isEn ? 'Delete preset' : 'মুছে ফেলুন'}
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="mt-3">
              <h4 className="text-xs font-bold text-slate-800 dark:text-white line-clamp-1">
                {isEn ? (preset.titleEn || preset.title) : preset.title}
              </h4>
              <p
                className={`text-sm font-extrabold mt-0.5 ${
                  preset.type === 'income' ? 'text-emerald-500' : 'text-rose-500'
                }`}
              >
                {preset.type === 'income' ? '+' : '-'}
                {formatCurrency(preset.amount, settings.useBanglaNumerals && !isEn)}
              </p>
              <span className="text-[10px] text-slate-400 block mt-1">
                {isEn ? '1-Tap to add' : '১-ট্যাপে এন্ট্রি'}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Create Preset Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-5 shadow-2xl space-y-3.5 border border-slate-100 dark:border-slate-800 animate-in fade-in">
            <h3 className="text-sm font-bold text-slate-800 dark:text-white">
              {isEn ? 'New Quick Entry Preset' : 'নতুন কুইক এন্ট্রি টেমপ্লেট'}
            </h3>

            {/* Income / Expense Switcher */}
            <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs font-bold text-center">
              <button
                type="button"
                onClick={() => setNewType('expense')}
                className={`py-1.5 rounded-lg transition-all ${
                  newType === 'expense'
                    ? 'bg-rose-500 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                {isEn ? 'Expense' : 'ব্যয়'}
              </button>
              <button
                type="button"
                onClick={() => setNewType('income')}
                className={`py-1.5 rounded-lg transition-all ${
                  newType === 'income'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                {isEn ? 'Income' : 'আয়'}
              </button>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-500 dark:text-slate-400 block mb-1">
                {isEn ? 'Preset Name / Label' : 'টেমপ্লেটের নাম'}
              </label>
              <input
                type="text"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder={isEn ? 'e.g. Evening Coffee, Daily Fuel' : 'যেমন: সান্ধ্যকালীন কফি, বাইক ফুয়েল'}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                autoFocus
                required
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-500 dark:text-slate-400 block mb-1">
                {isEn ? 'Amount (৳)' : 'টাকার পরিমাণ (৳)'}
              </label>
              <input
                type="number"
                value={newAmount}
                onChange={(e) => setNewAmount(e.target.value)}
                placeholder={isEn ? 'e.g. 50' : 'যেমন: ৫০'}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-500 dark:text-slate-400 block mb-1">
                {isEn ? 'Category' : 'ক্যাটাগরি'}
              </label>
              <select
                value={newCatId}
                onChange={(e) => setNewCatId(e.target.value)}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">{isEn ? 'Select a category...' : 'ক্যাটাগরি নির্বাচন করুন...'}</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {isEn ? (c.nameEn || c.name) : c.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
              >
                {isEn ? 'Cancel' : 'বাতিল'}
              </button>
              <button
                type="button"
                onClick={handleCreatePreset}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
              >
                {isEn ? 'Create Preset' : 'তৈরি করুন'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast message */}
      {toastMessage && (
        <div className="fixed bottom-10 left-1/2 -translate-x-1/2 bg-white dark:bg-slate-900 border border-emerald-300 dark:border-emerald-700 text-slate-800 dark:text-slate-100 text-xs px-4 py-2.5 rounded-full shadow-xl flex items-center gap-2 animate-in fade-in z-50">
          <CheckCircle2 className="w-4 h-4 text-emerald-500 fill-emerald-500" />
          <span className="font-semibold">{toastMessage}</span>
        </div>
      )}
    </div>
  );
};
