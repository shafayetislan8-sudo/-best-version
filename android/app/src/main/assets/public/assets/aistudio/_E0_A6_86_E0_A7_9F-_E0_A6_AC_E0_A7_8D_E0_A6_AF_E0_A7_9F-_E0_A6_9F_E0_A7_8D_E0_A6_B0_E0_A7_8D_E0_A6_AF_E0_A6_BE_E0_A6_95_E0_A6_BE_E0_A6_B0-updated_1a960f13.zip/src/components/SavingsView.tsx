import React, { useState } from 'react';
import {
  Plus,
  Calendar,
  Tag,
  Target,
  Trash2,
  Search,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatCurrency, toBanglaNumber, getTodayString } from '../utils/formatters';

export const SavingsView: React.FC = () => {
  const { savings, addSavings, deleteSavings, settings } = useApp();
  const isEn = settings.language === 'en';

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [name, setName] = useState('');
  const [targetAmount, setTargetAmount] = useState('');
  const [date, setDate] = useState(() => new Date().toLocaleDateString(isEn ? 'en-GB' : 'bn-BD', { day: 'numeric', month: 'long', year: 'numeric' }));

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    addSavings({
      name: name.trim(),
      targetAmount: parseFloat(targetAmount) || 0,
      date,
    });

    setIsModalOpen(false);
    setName('');
    setTargetAmount('');
  };

  const [filterType, setFilterType] = useState<'all' | 'active' | 'completed'>('all');
  const [showSearchBar, setShowSearchBar] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const totalTarget = savings.reduce((sum, s) => sum + s.targetAmount, 0);

  const filteredSavings = savings.filter((s) => {
    if (searchQuery.trim() && !s.name.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    return true;
  });

  return (
    <div className="space-y-4 pb-24 pt-1">
      {/* 1. Main Summary Card */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200/90 dark:border-slate-800 shadow-xs space-y-4">
        {/* Segmented Pill Selector: All | Active | Completed */}
        <div className="bg-[#f0f3f8] dark:bg-slate-800/80 rounded-xl p-1 flex items-center text-xs font-semibold">
          <button
            onClick={() => setFilterType('all')}
            className={`flex-1 py-1.5 rounded-lg text-center transition-all ${
              filterType === 'all'
                ? 'bg-blue-600 text-white shadow-xs font-bold'
                : 'text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {isEn ? 'All' : 'সকল'}
          </button>
          <button
            onClick={() => setFilterType('active')}
            className={`flex-1 py-1.5 rounded-lg text-center transition-all ${
              filterType === 'active'
                ? 'bg-blue-600 text-white shadow-xs font-bold'
                : 'text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {isEn ? 'In Progress' : 'চলমান'}
          </button>
          <button
            onClick={() => setFilterType('completed')}
            className={`flex-1 py-1.5 rounded-lg text-center transition-all ${
              filterType === 'completed'
                ? 'bg-blue-600 text-white shadow-xs font-bold'
                : 'text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {isEn ? 'Achieved' : 'অর্জিত'}
          </button>
        </div>

        {/* 3 Metric Columns: Total Target | Funds | Active */}
        <div className="grid grid-cols-3 gap-2 items-center">
          {/* Total Target */}
          <div className="text-center">
            <span className="text-xs font-semibold text-blue-600 dark:text-blue-400 block mb-0.5">
              {isEn ? 'Total Target' : 'মোট লক্ষ্য'}
            </span>
            <span className="text-base font-bold text-blue-600 dark:text-blue-400 block truncate">
              {totalTarget > 0 ? (
                formatCurrency(totalTarget, settings.useBanglaNumerals && !isEn)
              ) : (
                settings.useBanglaNumerals && !isEn ? '০' : '0'
              )}
            </span>
          </div>

          {/* Total Funds */}
          <div className="text-center">
            <span className="text-xs font-semibold text-emerald-500 block mb-0.5">
              {isEn ? 'Total Goals' : 'মোট খাত'}
            </span>
            <span className="text-base font-bold text-emerald-500 block truncate">
              {settings.useBanglaNumerals && !isEn ? toBanglaNumber(savings.length) : savings.length}{' '}
              {isEn ? 'Goals' : 'টি'}
            </span>
          </div>

          {/* Active Goals */}
          <div className="bg-[#e4efff] dark:bg-blue-950/60 rounded-xl py-2 px-3 text-center">
            <span className="text-xs font-semibold text-[#1a73e8] dark:text-blue-400 block mb-0.5">
              {isEn ? 'Active' : 'সক্রিয়'}
            </span>
            <span className="text-base font-bold text-[#1a73e8] dark:text-blue-400 block truncate">
              {settings.useBanglaNumerals && !isEn ? toBanglaNumber(savings.length) : savings.length}{' '}
              {isEn ? 'Active' : 'টি'}
            </span>
          </div>
        </div>
      </div>

      {/* 2. Action Bar */}
      <div className="flex items-center justify-between px-1 relative">
        <button
          onClick={() => setIsModalOpen(true)}
          className="border border-blue-200 dark:border-blue-800 text-blue-600 dark:text-blue-400 bg-blue-50/20 hover:bg-blue-50/80 rounded-xl px-3 py-1.5 text-xs font-semibold flex items-center gap-1 transition-colors"
        >
          <span className="text-sm leading-none font-bold">+</span>
          <span>{isEn ? 'Add Goal' : 'নতুন সঞ্চয়'}</span>
        </button>

        <div className="flex items-center gap-4 text-slate-400 dark:text-slate-500">
          <button
            onClick={() => setShowSearchBar((s) => !s)}
            className={`hover:text-slate-600 dark:hover:text-slate-300 transition-colors ${
              showSearchBar ? 'text-blue-600 dark:text-blue-400' : ''
            }`}
            title={isEn ? 'Search' : 'সার্চ'}
          >
            <Search className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Search Input Bar */}
      {showSearchBar && (
        <div className="relative px-1 animate-in fade-in">
          <Search className="w-4 h-4 text-slate-400 absolute left-4 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={isEn ? 'Search savings goal...' : 'সঞ্চয়ের খাত খুঁজুন...'}
            className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-xs"
            autoFocus
          />
        </div>
      )}

      {/* Empty State */}
      {filteredSavings.length === 0 ? (
        <div className="py-20 flex flex-col items-center justify-center text-center">
          <div className="text-amber-700/80 dark:text-amber-500/80 mb-3">
            <svg
              className="w-16 h-16"
              viewBox="0 0 48 48"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M10 18h28l-3 20H13L10 18z" />
              <path d="M18 18V12a6 6 0 0 1 12 0v6" />
              <circle cx="24" cy="26" r="2" />
            </svg>
          </div>
          <p className="text-xs font-bold text-slate-800 dark:text-white">
            {isEn ? 'No savings goals added yet' : 'কোন সঞ্চয়ের খাত নেই'}
          </p>
          <p className="text-[11px] text-slate-400 mt-1">
            {isEn ? 'Click the + button to add a new goal' : 'নতুন সঞ্চয়ের খাত যোগ করুন'}
          </p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {filteredSavings.map((s) => (
            <div
              key={s.id}
              className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-100 dark:border-slate-800 shadow-xs flex items-center justify-between hover:border-blue-200 dark:hover:border-slate-700 transition-colors"
            >
              <div>
                <h4 className="text-xs font-bold text-slate-800 dark:text-white">
                  {s.name}
                </h4>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  {isEn ? 'Date' : 'তারিখ'}: {s.date}
                </p>
              </div>

              <div className="flex items-center gap-3">
                <span className="text-xs font-bold text-blue-600 dark:text-blue-400">
                  {isEn ? 'Target' : 'লক্ষ্য'}: {formatCurrency(s.targetAmount, settings.useBanglaNumerals && !isEn)}
                </span>
                <button
                  onClick={() => deleteSavings(s.id)}
                  className="p-1 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 rounded-lg"
                  title={isEn ? 'Delete Goal' : 'মুছুন'}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Floating Action Button */}
      <button
        onClick={() => setIsModalOpen(true)}
        className="fixed bottom-6 right-6 z-40 w-14 h-14 rounded-full bg-[#1877f2] hover:bg-blue-600 active:scale-95 text-white shadow-xl shadow-blue-500/30 flex items-center justify-center transition-all focus:outline-none"
        title={isEn ? 'Add Savings Goal' : 'নতুন সঞ্চয়ের খাত যোগ করুন'}
        aria-label="Add savings goal"
      >
        <Plus className="w-7 h-7 stroke-[2.5]" />
      </button>

      {/* Add Savings Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-2xl border border-slate-100 dark:border-slate-800 space-y-3.5">
            <h3 className="text-sm font-bold text-slate-800 dark:text-white text-center">
              {isEn ? 'Add New Savings Goal' : 'নতুন সঞ্চয়ের খাত'}
            </h3>

            {/* Date Field */}
            <div className="flex items-center gap-2 p-2.5 bg-slate-50 dark:bg-slate-800 rounded-xl text-xs text-slate-700 dark:text-slate-300">
              <Calendar className="w-4 h-4 text-slate-400" />
              <span>{date}</span>
            </div>

            {/* Goal Name */}
            <div className="flex items-center gap-2 px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs">
              <Tag className="w-4 h-4 text-slate-400" />
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={isEn ? 'Goal name (e.g. Hajj, Emergency fund)' : 'খাতের নাম (যেমন: হজ ফান্ড, জরুরি সঞ্চয়)'}
                className="w-full bg-transparent text-slate-800 dark:text-slate-100 focus:outline-none"
                required
              />
            </div>

            {/* Target Amount */}
            <div className="flex items-center gap-2 px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs">
              <Target className="w-4 h-4 text-slate-400" />
              <input
                type="number"
                value={targetAmount}
                onChange={(e) => setTargetAmount(e.target.value)}
                placeholder={isEn ? 'Target amount (৳ / BDT)' : 'লক্ষ্যের পরিমাণ (৳)'}
                className="w-full bg-transparent text-slate-800 dark:text-slate-100 focus:outline-none"
                required
              />
            </div>

            {/* Buttons: Cancel | Add */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200"
              >
                {isEn ? 'Cancel' : 'বাতিল'}
              </button>
              <button
                type="button"
                onClick={handleSave}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
              >
                {isEn ? 'Add Goal' : 'অ্যাড'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
