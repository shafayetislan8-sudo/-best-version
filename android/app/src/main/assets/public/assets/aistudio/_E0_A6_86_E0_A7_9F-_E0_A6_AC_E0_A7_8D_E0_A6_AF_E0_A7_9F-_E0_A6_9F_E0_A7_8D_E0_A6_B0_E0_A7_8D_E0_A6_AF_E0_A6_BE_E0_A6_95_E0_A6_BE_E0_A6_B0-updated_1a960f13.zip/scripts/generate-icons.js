import fs from 'fs';
import path from 'path';
import sharp from 'sharp';

const srcImg = path.resolve('src/assets/images/app_icon_logo_1792345248559.jpg');
const publicDir = path.resolve('public');

async function run() {
  if (fs.existsSync(srcImg)) {
    // Resize to 512x512
    await sharp(srcImg)
      .resize(512, 512)
      .png()
      .toFile(path.join(publicDir, 'pwa-512x512.png'));

    // 192x192
    await sharp(srcImg)
      .resize(192, 192)
      .png()
      .toFile(path.join(publicDir, 'pwa-192x192.png'));

    // 180x180 apple touch icon
    await sharp(srcImg)
      .resize(180, 180)
      .png()
      .toFile(path.join(publicDir, 'apple-touch-icon.png'));

    // app-icon.png for direct user download
    await sharp(srcImg)
      .resize(512, 512)
      .png()
      .toFile(path.join(publicDir, 'app-icon.png'));

    console.log('Successfully updated public icons with generated 3D logo!');
  } else {
    console.log('Source image not found');
  }
}

run().catch(console.error);
