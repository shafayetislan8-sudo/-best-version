import React, { useState } from 'react';
import { ArrowLeft, Plus, Trash2, BookOpen, Search } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface NoteItem {
  id: string;
  title: string;
  content: string;
  date: string;
  isPinned?: boolean;
}

export const NotesScreen: React.FC = () => {
  const { setActiveTab, notes, addNote, updateNote, deleteNote, settings } = useApp();
  const isEn = settings.language === 'en';

  const [search, setSearch] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<NoteItem | null>(null);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [deleteCandidateId, setDeleteCandidateId] = useState<string | null>(null);

  const handleOpenAdd = () => {
    setEditingNote(null);
    setTitle('');
    setContent('');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (note: NoteItem) => {
    setEditingNote(note);
    setTitle(note.title);
    setContent(note.content);
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() && !content.trim()) return;

    const defaultTitle = isEn ? 'Untitled Note' : 'শিরোনামহীন নোট';
    if (editingNote) {
      updateNote(editingNote.id, {
        title: title.trim() || defaultTitle,
        content: content.trim(),
      });
    } else {
      addNote({
        title: title.trim() || defaultTitle,
        content: content.trim(),
      });
    }

    setIsModalOpen(false);
    setTitle('');
    setContent('');
  };

  const confirmDelete = () => {
    if (deleteCandidateId) {
      deleteNote(deleteCandidateId);
      setDeleteCandidateId(null);
    }
  };

  const filteredNotes = notes.filter(
    (n) =>
      n.title.toLowerCase().includes(search.toLowerCase()) ||
      n.content.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-4 pb-24 pt-1">
      {/* Top Header */}
      <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setActiveTab('profile_menu')}
            className="p-1.5 rounded-full text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title={isEn ? 'Back' : 'পেছনে যান'}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-amber-500" />
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              {isEn ? 'Drafts & Notes' : 'হিসাবের খসড়া ও নোট'}
            </h2>
          </div>
        </div>

        <button
          onClick={handleOpenAdd}
          className="border border-blue-200 dark:border-blue-800 text-blue-600 dark:text-blue-400 bg-blue-50/20 hover:bg-blue-50/80 dark:hover:bg-blue-950/40 rounded-xl px-3 py-1.5 text-xs font-semibold flex items-center gap-1 transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>{isEn ? 'New Note' : 'নতুন নোট'}</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="relative px-1">
        <Search className="w-4 h-4 text-slate-400 absolute left-4 top-3" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={isEn ? 'Search notes or market lists...' : 'নোট বা বাজারের ফর্দ খুঁজুন...'}
          className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-xs placeholder:text-slate-400"
        />
      </div>

      {/* Notes List */}
      {filteredNotes.length === 0 ? (
        <div className="text-center py-16 text-slate-400">
          <BookOpen className="w-12 h-12 mx-auto text-slate-300 dark:text-slate-600 mb-2 opacity-50" />
          <p className="text-xs">
            {isEn
              ? 'No notes found. Tap New Note button to add one.'
              : 'কোনো নোট নেই। উপরের বাটন দিয়ে নতুন নোট যোগ করুন।'}
          </p>
        </div>
      ) : (
        <div className="space-y-3 px-1">
          {filteredNotes.map((note) => (
            <div
              key={note.id}
              onClick={() => handleOpenEdit(note)}
              className="p-3.5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-xs hover:border-blue-300 dark:hover:border-blue-700 transition-all cursor-pointer space-y-1.5"
            >
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-slate-800 dark:text-white truncate max-w-[80%]">
                  {note.title}
                </h4>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-slate-400">{note.date}</span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setDeleteCandidateId(note.id);
                    }}
                    className="p-1 text-slate-400 hover:text-rose-500 rounded-full transition-colors"
                    title={isEn ? 'Delete' : 'মুছে ফেলুন'}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-300 whitespace-pre-line line-clamp-3 leading-relaxed">
                {note.content}
              </p>
            </div>
          ))}
        </div>
      )}

      {/* Add / Edit Note Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-2xl space-y-3 border border-slate-100 dark:border-slate-800 animate-in fade-in">
            <h3 className="text-sm font-bold text-slate-800 dark:text-white">
              {editingNote
                ? isEn
                  ? 'Edit Note'
                  : 'নোট সম্পাদনা'
                : isEn
                ? 'Add New Note'
                : 'নতুন নোট যোগ করুন'}
            </h3>

            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={isEn ? 'Title (e.g. Shopping List, Mess Rent)' : 'শিরোনাম (যেমন: বাজারের ফর্দ, মেস ফি)'}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
              autoFocus
            />

            <textarea
              rows={6}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder={isEn ? 'Write note details here...' : 'নোটের বিবরণ লিখুন...'}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none leading-relaxed"
            />

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
              >
                {isEn ? 'Cancel' : 'বাতিল'}
              </button>
              <button
                type="button"
                onClick={handleSave}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
              >
                {isEn ? 'Save' : 'সেইভ করুন'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* In-app Confirm Delete Note Modal */}
      {deleteCandidateId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-xs bg-white dark:bg-slate-900 rounded-3xl p-5 shadow-2xl space-y-4 border border-slate-100 dark:border-slate-800 animate-in fade-in">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-rose-50 dark:bg-rose-950/60 text-rose-500 flex items-center justify-center flex-shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-800 dark:text-white">
                  {isEn ? 'Delete Note?' : 'নোটটি মুছতে চান?'}
                </h3>
                <p className="text-[11px] text-slate-400">
                  {isEn ? 'This note will be permanently removed.' : 'এই নোটটি তালিকা থেকে বাদ দেয়া হবে।'}
                </p>
              </div>
            </div>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setDeleteCandidateId(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200"
              >
                {isEn ? 'Cancel' : 'বাতিল'}
              </button>
              <button
                onClick={confirmDelete}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
              >
                {isEn ? 'Delete' : 'মুছুন'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
