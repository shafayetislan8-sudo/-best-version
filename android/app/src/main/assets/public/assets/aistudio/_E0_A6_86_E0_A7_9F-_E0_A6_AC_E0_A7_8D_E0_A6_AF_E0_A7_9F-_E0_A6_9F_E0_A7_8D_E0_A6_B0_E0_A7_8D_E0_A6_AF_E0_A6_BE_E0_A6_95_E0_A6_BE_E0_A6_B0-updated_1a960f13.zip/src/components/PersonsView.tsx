import React, { useState, useMemo } from 'react';
import {
  ArrowDownLeft,
  ArrowUpRight,
  User,
  Search,
  MoreVertical,
  Plus,
  ArrowLeft,
  Calendar,
  Phone,
  MapPin,
  Image as ImageIcon,
  RotateCw,
  FileText,
  Trash2,
  Check,
  X,
  MessageCircle,
  Copy,
  ExternalLink,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatCurrency, toBanglaNumber, getTodayString } from '../utils/formatters';
import { PersonRecord } from '../types';

export const PersonsView: React.FC = () => {
  const {
    persons,
    addPerson,
    deletePerson,
    totalReceivable,
    totalPayable,
    totalPersonsCount,
    settings,
    setActiveTab,
  } = useApp();

  const isEn = settings.language === 'en';
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'receive' | 'give'>('all');
  const [showSearchBar, setShowSearchBar] = useState(false);
  const [isAddPersonOpen, setIsAddPersonOpen] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [showCalendarModal, setShowCalendarModal] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [reminderPerson, setReminderPerson] = useState<PersonRecord | null>(null);
  const [copiedReminder, setCopiedReminder] = useState(false);

  const handleDownloadReport = () => {
    setShowMenu(false);
    if (persons.length === 0) {
      setToastMessage(isEn ? 'No records to download' : 'ডাউনলোড করার মতো কোনো তথ্য নেই');
      setTimeout(() => setToastMessage(null), 2500);
      return;
    }
    const headers = isEn
      ? ['Name,Phone,Address,Type,Amount,Date']
      : ['নাম,ফোন,ঠিকানা,ধরন,পরিমাণ,তারিখ'];
    const rows = persons.map(
      (p) =>
        `"${p.name}","${p.phoneNumber || ''}","${p.address || ''}","${
          p.type === 'receive'
            ? isEn
              ? 'Receivable'
              : 'পাবো'
            : isEn
            ? 'Payable'
            : 'দিবো'
        }","${p.amount}","${p.date}"`
    );
    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers, ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `debts_ledger_${getTodayString()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setToastMessage(isEn ? 'Report downloaded as CSV' : 'রিপোর্ট CSV আকারে ডাউনলোড হয়েছে');
    setTimeout(() => setToastMessage(null), 2500);
  };

  // Form states for new person
  const [name, setName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [address, setAddress] = useState('');
  const [date, setDate] = useState(() => new Date().toLocaleDateString(isEn ? 'en-GB' : 'bn-BD', { day: 'numeric', month: 'long', year: 'numeric' }));
  const [type, setType] = useState<'receive' | 'give'>('receive');
  const [amount, setAmount] = useState('');

  const filteredPersons = useMemo(() => {
    let list = persons;
    if (filterType === 'receive') {
      list = list.filter((p) => p.type === 'receive');
    } else if (filterType === 'give') {
      list = list.filter((p) => p.type === 'give');
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) || (p.phoneNumber && p.phoneNumber.includes(q))
      );
    }
    return list;
  }, [persons, filterType, searchQuery]);

  const handleSavePerson = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    addPerson({
      name: name.trim(),
      phoneNumber: phoneNumber.trim() || undefined,
      address: address.trim() || undefined,
      date,
      type,
      amount: parseFloat(amount) || 0,
    });

    setIsAddPersonOpen(false);
    setName('');
    setPhoneNumber('');
    setAddress('');
    setAmount('');
  };

  if (isAddPersonOpen) {
    return (
      <div className="space-y-4 pb-20 pt-1">
        {/* Top Header */}
        <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsAddPersonOpen(false)}
              className="p-1 rounded-full text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              {isEn ? 'Add Person / Debt Record' : 'নতুন ব্যক্তি'}
            </h2>
          </div>

          <button
            onClick={handleSavePerson}
            className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold transition-colors shadow-xs"
          >
            {isEn ? 'Save' : 'সেইভ'}
          </button>
        </div>

        {/* Circular Avatar placeholder */}
        <div className="flex justify-center py-4">
          <div className="w-24 h-24 rounded-full bg-blue-50 dark:bg-blue-950/60 border-2 border-dashed border-blue-400 flex flex-col items-center justify-center text-blue-600 dark:text-blue-400 cursor-pointer hover:bg-blue-100 dark:hover:bg-blue-900/40 transition-colors">
            <ImageIcon className="w-8 h-8" />
            <span className="text-[10px] font-bold mt-1">
              {isEn ? '+ Photo' : '+ ছবি'}
            </span>
          </div>
        </div>

        {/* Form Inputs */}
        <form onSubmit={handleSavePerson} className="space-y-3 px-1">
          {/* Name */}
          <div className="relative flex items-center">
            <User className="w-4 h-4 text-slate-400 absolute left-3.5" />
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder={isEn ? 'Person name' : 'নাম লিখুন'}
              className="w-full pl-10 pr-4 py-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-xs"
              required
            />
          </div>

          {/* Phone */}
          <div className="relative flex items-center">
            <Phone className="w-4 h-4 text-slate-400 absolute left-3.5" />
            <input
              type="tel"
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
              placeholder={isEn ? 'Phone number (optional)' : 'ফোন নম্বর (ঐচ্ছিক)'}
              className="w-full pl-10 pr-4 py-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-xs"
            />
          </div>

          {/* Address */}
          <div className="relative flex items-center">
            <MapPin className="w-4 h-4 text-slate-400 absolute left-3.5" />
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder={isEn ? 'Address / Location (optional)' : 'ঠিকানা (ঐচ্ছিক)'}
              className="w-full pl-10 pr-4 py-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-xs"
            />
          </div>

          {/* Type Toggle: Receive | Give */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              type="button"
              onClick={() => setType('receive')}
              className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all ${
                type === 'receive'
                  ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border-emerald-400 ring-1 ring-emerald-400'
                  : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700'
              }`}
            >
              {isEn ? '↓ Receivable (I will get)' : '↓ পাবো (টাকা)'}
            </button>
            <button
              type="button"
              onClick={() => setType('give')}
              className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all ${
                type === 'give'
                  ? 'bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border-rose-400 ring-1 ring-rose-400'
                  : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700'
              }`}
            >
              {isEn ? '↑ Payable (I will give)' : '↑ দিবো (টাকা)'}
            </button>
          </div>

          {/* Amount */}
          <div>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder={isEn ? 'Amount (৳ / BDT)' : 'টাকার পরিমাণ (৳)'}
              className="w-full px-4 py-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-xs"
              required
            />
          </div>

          {/* Date Picker Button */}
          <button
            type="button"
            onClick={() => setShowCalendarModal(true)}
            className="w-full px-4 py-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-700 dark:text-slate-200 flex items-center gap-2 shadow-xs"
          >
            <Calendar className="w-4 h-4 text-slate-400" />
            <span>
              {isEn ? 'Date' : 'তারিখ'}: {date}
            </span>
          </button>

          {/* Save Button */}
          <div className="pt-4">
            <button
              type="submit"
              className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs transition-colors shadow-xs"
            >
              {isEn ? 'Save Person' : 'সেইভ'}
            </button>
          </div>
        </form>

        {/* Toast Warning */}
        {toastMessage && (
          <div className="fixed bottom-10 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-xs px-4 py-2.5 rounded-full shadow-lg flex items-center gap-2 animate-in fade-in z-50">
            <span className="w-4 h-4 rounded-full bg-rose-500 text-white flex items-center justify-center text-[10px] font-bold">!</span>
            <span>{toastMessage}</span>
          </div>
        )}

        {/* Calendar Picker Modal */}
        {showCalendarModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-2xl border border-slate-100 dark:border-slate-800 max-w-xs w-full space-y-4">
              <div className="border-b border-slate-100 dark:border-slate-800 pb-2">
                <span className="text-[10px] text-slate-400">
                  {isEn ? 'Select date' : 'তারিখ বেছে নিন'}
                </span>
                <h4 className="text-sm font-bold text-slate-800 dark:text-white">
                  {new Date().toLocaleDateString(isEn ? 'en-US' : 'bn-BD', { month: 'short', year: 'numeric' })}
                </h4>
              </div>
              <div className="text-center py-4 text-xs font-semibold text-slate-600 dark:text-slate-300">
                {new Date().toLocaleDateString(isEn ? 'en-US' : 'bn-BD', { month: 'long', year: 'numeric' })}
              </div>
              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs font-bold">
                <button
                  type="button"
                  onClick={() => setShowCalendarModal(false)}
                  className="px-3 py-1.5 text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
                >
                  {isEn ? 'Cancel' : 'বাতিল করুন'}
                </button>
                <button
                  type="button"
                  onClick={() => setShowCalendarModal(false)}
                  className="px-3 py-1.5 text-blue-600 dark:text-blue-400"
                >
                  {isEn ? 'OK' : 'ঠিক আছে'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-4 pb-24 pt-1">
      {/* 1. Main Summary Card */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200/90 dark:border-slate-800 shadow-xs">
        {/* Segmented Pill Selector: All | Receivable | Payable */}
        <div className="bg-[#f0f3f8] dark:bg-slate-800/80 rounded-xl p-1 flex items-center text-xs font-semibold">
          <button
            onClick={() => setFilterType('all')}
            className={`flex-1 py-1.5 rounded-lg text-center transition-all ${
              filterType === 'all'
                ? 'bg-blue-600 text-white shadow-xs font-bold'
                : 'text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {isEn ? 'All' : 'সকল'}
          </button>
          <button
            onClick={() => setFilterType('receive')}
            className={`flex-1 py-1.5 rounded-lg text-center transition-all ${
              filterType === 'receive'
                ? 'bg-blue-600 text-white shadow-xs font-bold'
                : 'text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {isEn ? 'Receivable' : 'পাবো'}
          </button>
          <button
            onClick={() => setFilterType('give')}
            className={`flex-1 py-1.5 rounded-lg text-center transition-all ${
              filterType === 'give'
                ? 'bg-blue-600 text-white shadow-xs font-bold'
                : 'text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {isEn ? 'Payable' : 'দিবো'}
          </button>
        </div>

        {/* 3 Metric Columns: ↓ Receivable | ↑ Payable | Total */}
        <div className="grid grid-cols-3 gap-2 mt-4 items-center">
          {/* Receivable */}
          <div
            onClick={() => setFilterType(filterType === 'receive' ? 'all' : 'receive')}
            className={`text-center cursor-pointer p-1.5 rounded-xl transition-all ${
              filterType === 'receive'
                ? 'bg-emerald-50 dark:bg-emerald-950/40 ring-1 ring-emerald-400'
                : ''
            }`}
          >
            <span className="text-xs font-semibold text-emerald-500 block mb-0.5">
              {isEn ? 'Receivable' : 'পাবো'}
            </span>
            <span className="text-base font-bold text-emerald-500 block truncate">
              {totalReceivable > 0 ? (
                formatCurrency(totalReceivable, settings.useBanglaNumerals && !isEn)
              ) : (
                settings.useBanglaNumerals && !isEn ? '০' : '0'
              )}
            </span>
          </div>

          {/* Payable */}
          <div
            onClick={() => setFilterType(filterType === 'give' ? 'all' : 'give')}
            className={`text-center cursor-pointer p-1.5 rounded-xl transition-all ${
              filterType === 'give'
                ? 'bg-rose-50 dark:bg-rose-950/40 ring-1 ring-rose-400'
                : ''
            }`}
          >
            <span className="text-xs font-semibold text-rose-500 block mb-0.5">
              {isEn ? 'Payable' : 'দিবো'}
            </span>
            <span className="text-base font-bold text-rose-500 block truncate">
              {totalPayable > 0 ? (
                formatCurrency(totalPayable, settings.useBanglaNumerals && !isEn)
              ) : (
                settings.useBanglaNumerals && !isEn ? '০' : '0'
              )}
            </span>
          </div>

          {/* Total Persons */}
          <div
            onClick={() => setFilterType('all')}
            className={`rounded-xl py-2 px-3 text-center cursor-pointer transition-all ${
              filterType === 'all'
                ? 'bg-[#e4efff] dark:bg-blue-950/60 ring-1 ring-blue-400'
                : 'bg-slate-50 dark:bg-slate-800/60'
            }`}
          >
            <span className="text-xs font-semibold text-[#1a73e8] dark:text-blue-400 block mb-0.5">
              {isEn ? 'Total' : 'মোট'}
            </span>
            <span className="text-base font-bold text-[#1a73e8] dark:text-blue-400 block truncate">
              {settings.useBanglaNumerals && !isEn ? toBanglaNumber(totalPersonsCount) : totalPersonsCount}{' '}
              {isEn ? 'Persons' : 'জন'}
            </span>
          </div>
        </div>
      </div>

      {/* 2. Action Bar */}
      <div className="flex items-center justify-between px-1 relative">
        <button
          onClick={() => setIsAddPersonOpen(true)}
          className="border border-blue-200 dark:border-blue-800 text-blue-600 dark:text-blue-400 bg-blue-50/20 hover:bg-blue-50/80 rounded-xl px-3 py-1.5 text-xs font-semibold flex items-center gap-1 transition-colors"
        >
          <span className="text-sm leading-none font-bold">+</span>
          <span>{isEn ? 'Add Person' : 'নতুন ব্যক্তি'}</span>
        </button>

        <div className="flex items-center gap-4 text-slate-400 dark:text-slate-500">
          <button
            onClick={() => setShowSearchBar((s) => !s)}
            className={`hover:text-slate-600 dark:hover:text-slate-300 transition-colors ${
              showSearchBar ? 'text-blue-600 dark:text-blue-400' : ''
            }`}
            title={isEn ? 'Search' : 'সার্চ'}
          >
            <Search className="w-5 h-5" />
          </button>

          <button
            onClick={() => setShowMenu((m) => !m)}
            className="hover:text-slate-600 dark:hover:text-slate-300 transition-colors"
            title={isEn ? 'Menu' : 'মেনু'}
          >
            <MoreVertical className="w-5 h-5" />
          </button>
        </div>

        {/* Dropdown Menu */}
        {showMenu && (
          <div className="absolute right-1 top-10 z-30 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xl py-2 w-52 text-xs font-semibold animate-in fade-in">
            <button
              onClick={handleDownloadReport}
              className="w-full px-4 py-2.5 text-left hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2.5 text-slate-700 dark:text-slate-200"
            >
              <FileText className="w-4 h-4 text-slate-400" />
              <span>{isEn ? 'Download CSV Report' : 'রিপোর্ট ডাউনলোড (CSV)'}</span>
            </button>
            <button
              onClick={() => {
                setShowMenu(false);
                setActiveTab('reports');
              }}
              className="w-full px-4 py-2.5 text-left hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2.5 text-blue-600 dark:text-blue-400"
            >
              <FileText className="w-4 h-4" />
              <span>{isEn ? 'Full Statement' : 'পূর্ণাঙ্গ স্টেটমেন্ট'}</span>
            </button>
            <button
              onClick={() => {
                setShowMenu(false);
                setActiveTab('trash');
              }}
              className="w-full px-4 py-2.5 text-left hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2.5 text-rose-600 dark:text-rose-400"
            >
              <Trash2 className="w-4 h-4" />
              <span>{isEn ? 'Trash Bin' : 'ট্র্যাশ'}</span>
            </button>
          </div>
        )}
      </div>

      {/* Search Input Bar */}
      {showSearchBar && (
        <div className="relative px-1 animate-in fade-in">
          <Search className="w-4 h-4 text-slate-400 absolute left-4 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={isEn ? 'Search person by name or phone...' : 'নাম বা ফোন নম্বর দিয়ে খুঁজুন...'}
            className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-xs"
            autoFocus
          />
        </div>
      )}

      {/* 3. Empty State */}
      {filteredPersons.length === 0 ? (
        <div className="py-20 flex flex-col items-center justify-center text-center">
          <div className="relative text-slate-300 dark:text-slate-600 mb-3">
            <svg
              className="w-20 h-20"
              viewBox="0 0 48 48"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M12 8L4 16v24h40V16L36 8H12z" />
              <path d="M4 16h40" />
              <path d="M20 22h8" />
            </svg>
            <RotateCw className="w-4 h-4 absolute bottom-0 right-2 text-slate-400" />
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
            {isEn ? 'No person records found' : 'কোন ব্যক্তি নেই'}
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {filteredPersons.map((p) => (
            <div
              key={p.id}
              className="bg-white dark:bg-slate-900 rounded-xl p-3 border border-slate-100 dark:border-slate-800 shadow-xs flex items-center justify-between hover:border-blue-200 dark:hover:border-slate-700 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 font-bold text-xs flex items-center justify-center">
                  {p.name.charAt(0)}
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-800 dark:text-white">
                    {p.name}
                  </h4>
                  <p className="text-[10px] text-slate-400">
                    {p.phoneNumber || p.address || p.date}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span
                  className={`text-xs font-bold mr-1 ${
                    p.type === 'receive' ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
                  }`}
                >
                  {p.type === 'receive' ? '↓' : '↑'}{' '}
                  {formatCurrency(p.amount, settings.useBanglaNumerals && !isEn)}
                </span>

                {/* Reminder button */}
                <button
                  onClick={() => {
                    setReminderPerson(p);
                    setCopiedReminder(false);
                  }}
                  className="p-1.5 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/50 rounded-lg transition-colors"
                  title={isEn ? 'Send Payment Reminder' : 'তাগাদা বার্তা পাঠান'}
                >
                  <MessageCircle className="w-4 h-4" />
                </button>

                <button
                  onClick={() => deletePerson(p.id)}
                  className="p-1.5 text-slate-400 hover:text-rose-500 rounded-lg transition-colors"
                  title={isEn ? 'Delete Record' : 'মুছে ফেলুন'}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Reminder SMS / WhatsApp Modal */}
      {reminderPerson && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-5 shadow-2xl space-y-4 border border-slate-100 dark:border-slate-800">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2.5">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-emerald-50 dark:bg-emerald-950/60 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
                  <MessageCircle className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-800 dark:text-white">
                    {isEn ? 'Payment Reminder Message' : 'বাকির তাগাদা বার্তা'}
                  </h3>
                  <p className="text-[10px] text-slate-400">{reminderPerson.name}</p>
                </div>
              </div>
              <button
                onClick={() => setReminderPerson(null)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Generated Reminder Text */}
            <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 text-xs text-slate-700 dark:text-slate-200 leading-relaxed">
              {isEn
                ? reminderPerson.type === 'receive'
                  ? `Dear ${reminderPerson.name}, this is a gentle reminder that ৳${reminderPerson.amount} is currently due. Please settle it at your earliest convenience. Thank you - ${
                      settings.userName || 'Ay-Byay'
                    }`
                  : `Dear ${reminderPerson.name}, regarding our transaction of ৳${reminderPerson.amount}, I will settle this payment very soon. Thank you - ${
                      settings.userName || 'Ay-Byay'
                    }`
                : reminderPerson.type === 'receive'
                ? `আসসালামু আলাইকুম ${reminderPerson.name}, আশা করি ভালো আছেন। হিসাব অনুযায়ী আপনার কাছে ${formatCurrency(
                    reminderPerson.amount,
                    settings.useBanglaNumerals
                  )} বাকি রয়েছে। সুবিধাজনক সময়ে পরিশোধ করলে খুব উপকৃত হব। ধন্যবাদ - ${
                    settings.userName || 'আয় ব্যয়'
                  }`
                : `আসসালামু আলাইকুম ${reminderPerson.name}, হিসাব অনুযায়ী আপনার পাওনা ${formatCurrency(
                    reminderPerson.amount,
                    settings.useBanglaNumerals
                  )} খুব শীঘ্রই পরিশোধ করার চেষ্টা করছি। ধন্যবাদ - ${
                    settings.userName || 'আয় ব্যয়'
                  }`}
            </div>

            {/* Actions */}
            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                onClick={() => {
                  const msg = isEn
                    ? reminderPerson.type === 'receive'
                      ? `Dear ${reminderPerson.name}, this is a gentle reminder that ৳${reminderPerson.amount} is currently due. Please settle it at your earliest convenience. Thank you - ${
                          settings.userName || 'Ay-Byay'
                        }`
                      : `Dear ${reminderPerson.name}, regarding our transaction of ৳${reminderPerson.amount}, I will settle this payment very soon. Thank you - ${
                          settings.userName || 'Ay-Byay'
                        }`
                    : reminderPerson.type === 'receive'
                    ? `আসসালামু আলাইকুম ${reminderPerson.name}, আশা করি ভালো আছেন। হিসাব অনুযায়ী আপনার কাছে ${formatCurrency(
                        reminderPerson.amount,
                        settings.useBanglaNumerals
                      )} বাকি রয়েছে। সুবিধাজনক সময়ে পরিশোধ করলে খুব উপকৃত হব। ধন্যবাদ - ${
                        settings.userName || 'আয় ব্যয়'
                      }`
                    : `আসসালামু আলাইকুম ${reminderPerson.name}, হিসাব অনুযায়ী আপনার পাওনা ${formatCurrency(
                        reminderPerson.amount,
                        settings.useBanglaNumerals
                      )} খুব শীঘ্রই পরিশোধ করার চেষ্টা করছি। ধন্যবাদ - ${
                        settings.userName || 'আয় ব্যয়'
                      }`;
                  navigator.clipboard.writeText(msg);
                  setCopiedReminder(true);
                  setTimeout(() => setCopiedReminder(false), 2000);
                }}
                className="py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center justify-center gap-1.5 transition-colors"
              >
                {copiedReminder ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-500" />
                    <span className="text-emerald-500">{isEn ? 'Copied!' : 'কপি হয়েছে'}</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 text-slate-500" />
                    <span>{isEn ? 'Copy Text' : 'কপি করুন'}</span>
                  </>
                )}
              </button>

              {/* WhatsApp direct link without window.open */}
              {(() => {
                const msg = isEn
                  ? reminderPerson.type === 'receive'
                    ? `Dear ${reminderPerson.name}, this is a gentle reminder that ৳${reminderPerson.amount} is currently due. Please settle it at your earliest convenience. Thank you - ${
                        settings.userName || 'Ay-Byay'
                      }`
                    : `Dear ${reminderPerson.name}, regarding our transaction of ৳${reminderPerson.amount}, I will settle this payment very soon. Thank you - ${
                        settings.userName || 'Ay-Byay'
                      }`
                  : reminderPerson.type === 'receive'
                  ? `আসসালামু আলাইকুম ${reminderPerson.name}, আশা করি ভালো আছেন। হিসাব অনুযায়ী আপনার কাছে ${formatCurrency(
                      reminderPerson.amount,
                      settings.useBanglaNumerals
                    )} বাকি রয়েছে। সুবিধাজনক সময়ে পরিশোধ করলে খুব উপকৃত হব। ধন্যবাদ - ${
                      settings.userName || 'আয় ব্যয়'
                    }`
                  : `আসসালামু আলাইকুম ${reminderPerson.name}, হিসাব অনুযায়ী আপনার পাওনা ${formatCurrency(
                      reminderPerson.amount,
                      settings.useBanglaNumerals
                    )} খুব শীঘ্রই পরিশোধ করার চেষ্টা করছি। ধন্যবাদ - ${
                      settings.userName || 'আয় ব্যয়'
                    }`;
                const phone = reminderPerson.phoneNumber
                  ? reminderPerson.phoneNumber.replace(/[^0-9]/g, '')
                  : '';
                const url = phone
                  ? `https://wa.me/${phone}?text=${encodeURIComponent(msg)}`
                  : `https://wa.me/?text=${encodeURIComponent(msg)}`;

                return (
                  <a
                    href={url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-colors shadow-xs"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>WhatsApp</span>
                  </a>
                );
              })()}
            </div>
          </div>
        </div>
      )}

      {/* Floating Action Button */}
      <button
        onClick={() => setIsAddPersonOpen(true)}
        className="fixed bottom-6 right-6 z-40 w-14 h-14 rounded-full bg-[#1877f2] hover:bg-blue-600 active:scale-95 text-white shadow-xl shadow-blue-500/30 flex items-center justify-center transition-all focus:outline-none"
        title={isEn ? 'Add Person' : 'নতুন ব্যক্তি যোগ করুন'}
        aria-label="Add person"
      >
        <Plus className="w-7 h-7 stroke-[2.5]" />
      </button>
    </div>
  );
};
