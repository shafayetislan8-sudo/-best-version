import React from 'react';
import {
  ArrowLeftRight,
  ArrowUpDown,
  TrendingUp,
  PlusSquare,
  ListTodo,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const TopIconNav: React.FC = () => {
  const { activeTab, setActiveTab, settings } = useApp();

  return (
    <div className="bg-white dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800 transition-colors">
      <div className="max-w-md mx-auto px-4 py-2 flex items-center justify-between">
        {/* 1. Dashboard (⇄) */}
        <div className="flex flex-col items-center">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
              activeTab === 'dashboard'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'border border-slate-300 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:border-slate-400'
            }`}
            title={settings.language === 'en' ? 'Home Dashboard' : 'আয়-ব্যয় ড্যাশবোর্ড'}
          >
            <ArrowLeftRight className="w-4 h-4 stroke-[2.2]" />
          </button>
          {activeTab === 'dashboard' && (
            <div className="w-5 h-1 bg-blue-600 rounded-full mt-1.5" />
          )}
        </div>

        {/* 2. Persons / Baki (⇅) */}
        <div className="flex flex-col items-center">
          <button
            onClick={() => setActiveTab('persons')}
            className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
              activeTab === 'persons'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'border border-slate-300 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:border-slate-400'
            }`}
            title={settings.language === 'en' ? 'Borrow & Lend Ledger' : 'বাকি ও ব্যক্তি তালিকা'}
          >
            <ArrowUpDown className="w-4 h-4 stroke-[2.2]" />
          </button>
          {activeTab === 'persons' && (
            <div className="w-5 h-1 bg-blue-600 rounded-full mt-1.5" />
          )}
        </div>

        {/* 3. Budget Management (📈 / ~) */}
        <div className="flex flex-col items-center">
          <button
            onClick={() => setActiveTab('budget')}
            className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
              activeTab === 'budget'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'border border-slate-300 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:border-slate-400'
            }`}
            title={settings.language === 'en' ? 'Budget' : 'বাজেট ম্যানেজমেন্ট'}
          >
            <TrendingUp className="w-4 h-4 stroke-[2.2]" />
          </button>
          {activeTab === 'budget' && (
            <div className="w-5 h-1 bg-blue-600 rounded-full mt-1.5" />
          )}
        </div>

        {/* 4. Savings Accounts (⊞ / [+]) */}
        <div className="flex flex-col items-center">
          <button
            onClick={() => setActiveTab('savings')}
            className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
              activeTab === 'savings'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'border border-slate-300 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:border-slate-400'
            }`}
            title={settings.language === 'en' ? 'Savings & Goals' : 'সঞ্চয়ের খাত'}
          >
            <PlusSquare className="w-4 h-4 stroke-[2.2]" />
          </button>
          {activeTab === 'savings' && (
            <div className="w-5 h-1 bg-blue-600 rounded-full mt-1.5" />
          )}
        </div>

        {/* 5. Tasks (📋) */}
        <div className="flex flex-col items-center">
          <button
            onClick={() => setActiveTab('tasks')}
            className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
              activeTab === 'tasks'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'border border-slate-300 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:border-slate-400'
            }`}
            title={settings.language === 'en' ? 'Tasks & Checklist' : 'টাস্ক ও রিমাইন্ডার'}
          >
            <ListTodo className="w-4 h-4 stroke-[2.2]" />
          </button>
          {activeTab === 'tasks' && (
            <div className="w-5 h-1 bg-blue-600 rounded-full mt-1.5" />
          )}
        </div>

        {/* 6. Profile Avatar Badge (S) */}
        <div className="flex flex-col items-center">
          <button
            onClick={() => setActiveTab('profile_menu')}
            className={`w-8 h-8 rounded-full bg-emerald-600 text-white font-bold text-sm flex items-center justify-center shadow-xs transition-transform ${
              activeTab === 'profile_menu' ? 'ring-2 ring-emerald-500 ring-offset-2' : ''
            }`}
            title={settings.language === 'en' ? 'Tools & Menu' : 'টুলস ও অ্যাকাউন্ট মেনু'}
          >
            {settings.userName ? settings.userName.charAt(0).toUpperCase() : 'S'}
          </button>
          {activeTab === 'profile_menu' && (
            <div className="w-5 h-1 bg-emerald-600 rounded-full mt-1.5" />
          )}
        </div>
      </div>
    </div>
  );
};
