import React, { useState, useMemo } from 'react';
import { ArrowLeft, Calendar as CalendarIcon, ChevronLeft, ChevronRight } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatCurrency, toBanglaNumber, BANGLA_MONTHS } from '../utils/formatters';
import { CashMemoModal } from './CashMemoModal';
import { Transaction } from '../types';

export const CalendarHeatmapScreen: React.FC = () => {
  const { transactions, setActiveTab, settings, selectedYear, selectedMonth } = useApp();
  const isEn = settings.language === 'en';

  const [currentYear, setCurrentYear] = useState(selectedYear || new Date().getFullYear());
  const [currentMonth, setCurrentMonth] = useState(selectedMonth || new Date().getMonth() + 1); // 1-indexed
  const [selectedDay, setSelectedDay] = useState<number | null>(new Date().getDate());
  const [activeCashMemoTx, setActiveCashMemoTx] = useState<Transaction | null>(null);

  const enMonthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];
  const monthName = isEn ? enMonthNames[currentMonth - 1] : (BANGLA_MONTHS[currentMonth - 1] || 'অক্টোবর');

  // Days in month
  const daysInMonth = new Date(currentYear, currentMonth, 0).getDate();
  const firstDayWeekday = new Date(currentYear, currentMonth - 1, 1).getDay(); // 0 = Sun

  // Aggregate daily expenses and incomes for the month
  const dailyData = useMemo(() => {
    const data: Record<number, { expense: number; income: number; count: number }> = {};
    for (let d = 1; d <= daysInMonth; d++) {
      data[d] = { expense: 0, income: 0, count: 0 };
    }

    transactions.forEach((tx) => {
      const [y, m, d] = tx.date.split('-').map(Number);
      if (y === currentYear && m === currentMonth) {
        if (!data[d]) data[d] = { expense: 0, income: 0, count: 0 };
        if (tx.type === 'expense') data[d].expense += tx.amount;
        if (tx.type === 'income') data[d].income += tx.amount;
        data[d].count += 1;
      }
    });

    return data;
  }, [transactions, currentYear, currentMonth, daysInMonth]);

  // Selected Day's Transactions
  const dayTransactions = useMemo(() => {
    if (!selectedDay) return [];
    return transactions.filter((tx) => {
      const [y, m, d] = tx.date.split('-').map(Number);
      return y === currentYear && m === currentMonth && d === selectedDay;
    });
  }, [transactions, currentYear, currentMonth, selectedDay]);

  const handlePrevMonth = () => {
    if (currentMonth === 1) {
      setCurrentMonth(12);
      setCurrentYear((y) => y - 1);
    } else {
      setCurrentMonth((m) => m - 1);
    }
  };

  const handleNextMonth = () => {
    if (currentMonth === 12) {
      setCurrentMonth(1);
      setCurrentYear((y) => y + 1);
    } else {
      setCurrentMonth((m) => m + 1);
    }
  };

  return (
    <div className="space-y-4 pb-24 pt-1">
      {/* Top Header */}
      <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setActiveTab('profile_menu')}
            className="p-1.5 rounded-full text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title={isEn ? 'Back' : 'পেছনে যান'}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <CalendarIcon className="w-5 h-5 text-blue-600" />
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              {isEn ? 'Calendar Expense Heatmap' : 'ক্যালেন্ডার হিটম্যাপ ভিউ'}
            </h2>
          </div>
        </div>

        {/* Month Navigation */}
        <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 rounded-xl p-1 text-xs font-bold text-slate-700 dark:text-slate-200">
          <button onClick={handlePrevMonth} className="p-1 hover:text-blue-600 dark:hover:text-blue-400">
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="px-1.5">
            {monthName} {settings.useBanglaNumerals && !isEn ? toBanglaNumber(currentYear) : currentYear}
          </span>
          <button onClick={handleNextMonth} className="p-1 hover:text-blue-600 dark:hover:text-blue-400">
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Legend */}
      <div className="flex items-center justify-between px-1 text-[10px] text-slate-500 dark:text-slate-400">
        <span>{isEn ? 'Daily expense level:' : 'দৈনিক খরচের মাত্রা:'}</span>
        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-sm bg-emerald-100 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-700" />
            {isEn ? 'Low' : '০/কম'}
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-sm bg-amber-200 dark:bg-amber-900/60 border border-amber-400 dark:border-amber-700" />
            {isEn ? 'Mid' : 'মাঝারি'}
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-sm bg-rose-300 dark:bg-rose-900/70 border border-rose-500 dark:border-rose-700" />
            {isEn ? 'High' : 'বেশি'}
          </span>
        </div>
      </div>

      {/* Calendar Matrix Card */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 border border-slate-100 dark:border-slate-800 shadow-xs space-y-2">
        {/* Weekday Labels */}
        <div className="grid grid-cols-7 gap-1 text-center text-[10px] font-bold text-slate-400 dark:text-slate-500 pb-1 border-b border-slate-100 dark:border-slate-800">
          <span>{isEn ? 'Sun' : 'রবি'}</span>
          <span>{isEn ? 'Mon' : 'সোম'}</span>
          <span>{isEn ? 'Tue' : 'মঙ্গল'}</span>
          <span>{isEn ? 'Wed' : 'বুধ'}</span>
          <span>{isEn ? 'Thu' : 'বৃহঃ'}</span>
          <span>{isEn ? 'Fri' : 'শুক্র'}</span>
          <span>{isEn ? 'Sat' : 'শনি'}</span>
        </div>

        {/* Days Grid */}
        <div className="grid grid-cols-7 gap-1 pt-1">
          {/* Empty cells for weekday offset */}
          {Array.from({ length: firstDayWeekday }).map((_, i) => (
            <div key={`offset_${i}`} className="h-12 rounded-xl" />
          ))}

          {/* Days */}
          {Array.from({ length: daysInMonth }).map((_, idx) => {
            const dayNum = idx + 1;
            const data = dailyData[dayNum] || { expense: 0, income: 0, count: 0 };
            const isSelected = selectedDay === dayNum;

            // Color coding based on expense
            let bgClass = 'bg-slate-50 dark:bg-slate-800/40 text-slate-700 dark:text-slate-300';
            if (data.expense > 2000) {
              bgClass =
                'bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-200 font-bold border border-rose-200 dark:border-rose-900';
            } else if (data.expense > 500) {
              bgClass =
                'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-200 font-semibold border border-amber-200 dark:border-amber-900';
            } else if (data.expense > 0 || data.income > 0) {
              bgClass =
                'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-200 border border-emerald-200 dark:border-emerald-900';
            }

            return (
              <button
                key={dayNum}
                onClick={() => setSelectedDay(dayNum)}
                className={`h-12 rounded-xl p-1 flex flex-col items-center justify-between transition-all ${bgClass} ${
                  isSelected
                    ? 'ring-2 ring-blue-600 shadow-md scale-105 z-10'
                    : 'hover:scale-98'
                }`}
              >
                <span className="text-xs font-bold leading-none">
                  {settings.useBanglaNumerals && !isEn ? toBanglaNumber(dayNum) : dayNum}
                </span>

                {data.expense > 0 && (
                  <span className="text-[8px] font-extrabold truncate max-w-full text-rose-600 dark:text-rose-400">
                    -{settings.useBanglaNumerals && !isEn
                      ? toBanglaNumber(Math.round(data.expense))
                      : Math.round(data.expense)}
                  </span>
                )}
                {data.expense === 0 && data.income > 0 && (
                  <span className="text-[8px] font-extrabold truncate max-w-full text-emerald-600 dark:text-emerald-400">
                    +{settings.useBanglaNumerals && !isEn
                      ? toBanglaNumber(Math.round(data.income))
                      : Math.round(data.income)}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Day Transaction Breakdown */}
      {selectedDay && (
        <div className="space-y-2 px-1 animate-in fade-in">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-800 dark:text-white">
              {settings.useBanglaNumerals && !isEn ? toBanglaNumber(selectedDay) : selectedDay}{' '}
              {monthName} {isEn ? 'Transactions' : 'এর লেনদেন'} (
              {settings.useBanglaNumerals && !isEn ? toBanglaNumber(dayTransactions.length) : dayTransactions.length}{' '}
              {isEn ? 'items' : 'টি'})
            </h3>
            <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
              {isEn ? 'Total Exp' : 'মোট ব্যয়'}:{' '}
              {formatCurrency(
                dailyData[selectedDay]?.expense || 0,
                settings.useBanglaNumerals && !isEn
              )}
            </span>
          </div>

          {dayTransactions.length === 0 ? (
            <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 text-center text-xs text-slate-400">
              {isEn ? 'No transactions on this date' : 'এই দিনে কোনো লেনদেন নেই'}
            </div>
          ) : (
            <div className="space-y-2">
              {dayTransactions.map((tx) => (
                <div
                  key={tx.id}
                  onClick={() => setActiveCashMemoTx(tx)}
                  className="p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-xs flex items-center justify-between cursor-pointer hover:border-blue-300 dark:hover:border-blue-700 transition-all"
                >
                  <div className="space-y-0.5">
                    <h4 className="text-xs font-bold text-slate-800 dark:text-white">
                      {tx.categoryName}
                    </h4>
                    <p className="text-[10px] text-slate-400">
                      {tx.note || tx.accountName} • {tx.time}
                    </p>
                  </div>

                  <div className="text-right">
                    <span
                      className={`text-xs font-bold ${
                        tx.type === 'income'
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : 'text-rose-600 dark:text-rose-400'
                      }`}
                    >
                      {tx.type === 'income' ? '+' : '-'}{' '}
                      {formatCurrency(tx.amount, settings.useBanglaNumerals && !isEn)}
                    </span>
                    <span className="text-[9px] text-blue-500 block">
                      {isEn ? 'View Memo' : 'ক্যাশ মেমো দেখুন'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Cash Memo Modal when clicking any transaction */}
      <CashMemoModal
        transaction={activeCashMemoTx}
        onClose={() => setActiveCashMemoTx(null)}
        currencySymbol={settings.currencySymbol}
        useBanglaNumerals={settings.useBanglaNumerals && !isEn}
      />
    </div>
  );
};
