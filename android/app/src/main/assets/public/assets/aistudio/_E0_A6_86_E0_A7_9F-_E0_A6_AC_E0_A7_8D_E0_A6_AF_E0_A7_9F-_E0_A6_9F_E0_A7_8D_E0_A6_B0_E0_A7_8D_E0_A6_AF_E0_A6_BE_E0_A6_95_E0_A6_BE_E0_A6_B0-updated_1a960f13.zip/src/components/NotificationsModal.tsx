import React from 'react';
import {
  Bell,
  X,
  AlertTriangle,
  HandCoins,
  CheckCircle,
  Sparkles,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatCurrency, toBanglaNumber } from '../utils/formatters';

export const NotificationsModal: React.FC = () => {
  const {
    isNotificationsOpen,
    setIsNotificationsOpen,
    persons,
    monthlyExpense,
    settings,
    setActiveTab,
  } = useApp();

  if (!isNotificationsOpen) return null;

  const isEn = settings.language === 'en';

  const isBudgetAlert =
    settings.enableBudgetAlerts &&
    settings.monthlyBudget > 0 &&
    monthlyExpense >= settings.monthlyBudget * 0.85;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-2xl shadow-2xl border border-gray-100 dark:border-slate-800 p-5 space-y-4 max-h-[85vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400 flex items-center justify-center">
              <Bell className="w-4 h-4" />
            </div>
            <h3 className="text-base font-bold text-slate-800 dark:text-white">
              {isEn ? 'Notifications & Alerts' : 'বিজ্ঞপ্তি ও সতর্কতা'}
            </h3>
          </div>
          <button
            onClick={() => setIsNotificationsOpen(false)}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
            title={isEn ? 'Close' : 'বন্ধ করুন'}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-3">
          {isBudgetAlert && (
            <div className="p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 space-y-1">
              <div className="flex items-center gap-2 text-amber-800 dark:text-amber-300 font-bold text-xs">
                <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0" />
                <span>{isEn ? 'Budget Alert Warning!' : 'বাজেট সতর্কতা!'}</span>
              </div>
              <p className="text-xs text-amber-700 dark:text-amber-400">
                {isEn
                  ? `Your monthly expense has reached ${formatCurrency(monthlyExpense, false)}.`
                  : `চলতি মাসে আপনার মোট খরচ ${formatCurrency(monthlyExpense, settings.useBanglaNumerals)}।`}
              </p>
            </div>
          )}

          {persons.length > 0 ? (
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wide">
                {isEn ? 'Debts & Person Ledger' : 'ব্যক্তি ও বাকি তালিকা'} ({settings.useBanglaNumerals && !isEn ? toBanglaNumber(persons.length) : persons.length})
              </h4>
              {persons.map((p) => (
                <div
                  key={p.id}
                  onClick={() => {
                    setIsNotificationsOpen(false);
                    setActiveTab('persons');
                  }}
                  className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-100 dark:border-slate-800 hover:border-blue-300 cursor-pointer transition-colors flex items-center justify-between"
                >
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`w-8 h-8 rounded-lg flex items-center justify-center text-white text-xs font-bold ${
                        p.type === 'receive' ? 'bg-emerald-500' : 'bg-rose-500'
                      }`}
                    >
                      <HandCoins className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-slate-800 dark:text-slate-100">
                        {p.name}
                      </p>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">
                        {p.type === 'receive' ? (isEn ? 'Receivable:' : 'পাবো:') : (isEn ? 'Payable:' : 'দিবো:')}{' '}
                        {formatCurrency(p.amount, settings.useBanglaNumerals && !isEn)}
                      </p>
                    </div>
                  </div>

                  <span className="text-[10px] text-blue-600 dark:text-blue-400 font-semibold">
                    {isEn ? 'View →' : 'দেখুন →'}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-4 text-center text-slate-400 text-xs">
              <CheckCircle className="w-8 h-8 mx-auto text-emerald-500 mb-2" />
              <p>{isEn ? 'No unpaid dues or pending debts' : 'কোনো অপরিশোধিত বাকি বা দেনা নেই'}</p>
            </div>
          )}

          <div className="p-3.5 rounded-xl bg-blue-50/60 dark:bg-blue-950/30 border border-blue-100 dark:border-blue-900 space-y-1">
            <div className="flex items-center gap-1.5 text-xs font-bold text-blue-800 dark:text-blue-300">
              <Sparkles className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
              <span>{isEn ? 'Smart Tip of the Day' : 'আজকের হিসাব টিপ'}</span>
            </div>
            <p className="text-xs text-blue-700 dark:text-blue-300">
              {isEn
                ? 'Record every expense right when it occurs to keep accounts transparent and accurate.'
                : 'প্রতিটি ছোট খরচের সাথে সাথেই এন্ট্রি করে রাখুন। এতে হিসাব পরিষ্কার থাকবে।'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
