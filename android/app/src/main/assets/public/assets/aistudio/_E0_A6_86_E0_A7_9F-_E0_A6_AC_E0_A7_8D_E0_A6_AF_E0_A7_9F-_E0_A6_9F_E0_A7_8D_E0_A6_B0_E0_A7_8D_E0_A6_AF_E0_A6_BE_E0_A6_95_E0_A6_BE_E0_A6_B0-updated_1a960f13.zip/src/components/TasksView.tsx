import React, { useState } from 'react';
import {
  Plus,
  CheckCircle2,
  Circle,
  Bell,
  Trash2,
  Calendar,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { toBanglaNumber } from '../utils/formatters';

export const TasksView: React.FC = () => {
  const { tasks, addTask, toggleTask, deleteTask, settings } = useApp();
  const isEn = settings.language === 'en';

  const [tabFilter, setTabFilter] = useState<'all' | 'ongoing' | 'completed'>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [taskText, setTaskText] = useState('');
  const [hasReminder, setHasReminder] = useState(false);
  const [dueDate, setDueDate] = useState('');
  const [showReminderDialog, setShowReminderDialog] = useState(false);
  const [showSearchBar, setShowSearchBar] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const ongoingCount = tasks.filter((t) => !t.completed).length;
  const completedCount = tasks.filter((t) => t.completed).length;

  const displayedTasks = tasks.filter((t) => {
    if (tabFilter === 'ongoing' && t.completed) return false;
    if (tabFilter === 'completed' && !t.completed) return false;
    if (searchQuery.trim() && !t.text.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    return true;
  });

  const handleSaveTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskText.trim()) return;

    addTask(taskText.trim(), dueDate || undefined, hasReminder);
    setIsModalOpen(false);
    setTaskText('');
    setHasReminder(false);
    setDueDate('');
  };

  return (
    <div className="space-y-4 pb-24 pt-1">
      {/* 1. Main Summary Card */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200/90 dark:border-slate-800 shadow-xs space-y-4">
        {/* Segmented Pill Selector: All | Ongoing | Completed */}
        <div className="bg-[#f0f3f8] dark:bg-slate-800/80 rounded-xl p-1 flex items-center text-xs font-semibold">
          <button
            onClick={() => setTabFilter('all')}
            className={`flex-1 py-1.5 rounded-lg text-center transition-all ${
              tabFilter === 'all'
                ? 'bg-blue-600 text-white shadow-xs font-bold'
                : 'text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {isEn ? 'All' : 'সকল'}
          </button>
          <button
            onClick={() => setTabFilter('ongoing')}
            className={`flex-1 py-1.5 rounded-lg text-center transition-all ${
              tabFilter === 'ongoing'
                ? 'bg-blue-600 text-white shadow-xs font-bold'
                : 'text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {isEn ? 'Pending' : 'চলমান'}
          </button>
          <button
            onClick={() => setTabFilter('completed')}
            className={`flex-1 py-1.5 rounded-lg text-center transition-all ${
              tabFilter === 'completed'
                ? 'bg-blue-600 text-white shadow-xs font-bold'
                : 'text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {isEn ? 'Completed' : 'সম্পন্ন'}
          </button>
        </div>

        {/* 3 Metric Columns: Total | Pending | Done */}
        <div className="grid grid-cols-3 gap-2 items-center">
          {/* Total Tasks */}
          <div
            onClick={() => setTabFilter('all')}
            className="text-center cursor-pointer p-1.5 rounded-xl transition-all"
          >
            <span className="text-xs font-semibold text-blue-600 dark:text-blue-400 block mb-0.5">
              {isEn ? 'Total Tasks' : 'মোট টাস্ক'}
            </span>
            <span className="text-base font-bold text-blue-600 dark:text-blue-400 block truncate">
              {settings.useBanglaNumerals && !isEn ? toBanglaNumber(tasks.length) : tasks.length}{' '}
              {isEn ? 'Tasks' : 'টি'}
            </span>
          </div>

          {/* Pending Tasks */}
          <div
            onClick={() => setTabFilter('ongoing')}
            className={`text-center cursor-pointer p-1.5 rounded-xl transition-all ${
              tabFilter === 'ongoing' ? 'bg-amber-50 dark:bg-amber-950/40 ring-1 ring-amber-400' : ''
            }`}
          >
            <span className="text-xs font-semibold text-amber-500 block mb-0.5">
              {isEn ? 'Pending' : 'চলমান'}
            </span>
            <span className="text-base font-bold text-amber-500 block truncate">
              {settings.useBanglaNumerals && !isEn ? toBanglaNumber(ongoingCount) : ongoingCount}{' '}
              {isEn ? 'Pending' : 'টি'}
            </span>
          </div>

          {/* Completed Tasks */}
          <div
            onClick={() => setTabFilter('completed')}
            className={`rounded-xl py-2 px-3 text-center cursor-pointer transition-all ${
              tabFilter === 'completed'
                ? 'bg-[#e4efff] dark:bg-blue-950/60 ring-1 ring-blue-400'
                : 'bg-slate-50 dark:bg-slate-800/60'
            }`}
          >
            <span className="text-xs font-semibold text-[#1a73e8] dark:text-blue-400 block mb-0.5">
              {isEn ? 'Done' : 'সম্পন্ন'}
            </span>
            <span className="text-base font-bold text-[#1a73e8] dark:text-blue-400 block truncate">
              {settings.useBanglaNumerals && !isEn ? toBanglaNumber(completedCount) : completedCount}{' '}
              {isEn ? 'Done' : 'টি'}
            </span>
          </div>
        </div>
      </div>

      {/* 2. Action Bar */}
      <div className="flex items-center justify-between px-1 relative">
        <button
          onClick={() => setIsModalOpen(true)}
          className="border border-blue-200 dark:border-blue-800 text-blue-600 dark:text-blue-400 bg-blue-50/20 hover:bg-blue-50/80 rounded-xl px-3 py-1.5 text-xs font-semibold flex items-center gap-1 transition-colors"
        >
          <span className="text-sm leading-none font-bold">+</span>
          <span>{isEn ? 'Add Task' : 'নতুন টাস্ক'}</span>
        </button>

        <div className="flex items-center gap-4 text-slate-400 dark:text-slate-500">
          <button
            onClick={() => setShowSearchBar((s) => !s)}
            className={`hover:text-slate-600 dark:hover:text-slate-300 transition-colors ${
              showSearchBar ? 'text-blue-600 dark:text-blue-400' : ''
            }`}
            title={isEn ? 'Search' : 'সার্চ'}
          >
            <span className="text-xs font-semibold">{isEn ? 'Search' : 'খুঁজুন'}</span>
          </button>
        </div>
      </div>

      {/* Search Input Bar */}
      {showSearchBar && (
        <div className="relative px-1 animate-in fade-in">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={isEn ? 'Search tasks...' : 'টাস্ক খুঁজুন...'}
            className="w-full px-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-xs"
            autoFocus
          />
        </div>
      )}

      {/* 3. Empty State */}
      {displayedTasks.length === 0 ? (
        <div className="py-20 flex flex-col items-center justify-center text-center">
          <div className="text-slate-300 dark:text-slate-600 mb-3">
            <svg
              className="w-16 h-16"
              viewBox="0 0 48 48"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <circle cx="24" cy="24" r="18" />
              <polyline points="16 24 22 30 32 18" />
            </svg>
          </div>
          <p className="text-xs font-medium text-slate-400 dark:text-slate-500">
            {tabFilter === 'completed'
              ? isEn
                ? 'No completed tasks yet'
                : 'কোনো সম্পন্ন টাস্ক নেই'
              : tabFilter === 'ongoing'
              ? isEn
                ? 'No pending tasks'
                : 'কোনো চলমান টাস্ক নেই'
              : isEn
              ? 'No tasks in checklist'
              : 'কোনো টাস্ক নেই'}
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {displayedTasks.map((t) => (
            <div
              key={t.id}
              className="bg-white dark:bg-slate-900 rounded-xl p-3 border border-slate-100 dark:border-slate-800 shadow-xs flex items-center justify-between hover:border-blue-200 dark:hover:border-slate-700 transition-colors"
            >
              <div className="flex items-center gap-3">
                <button
                  onClick={() => toggleTask(t.id)}
                  className="text-blue-600 dark:text-blue-400 focus:outline-none"
                  title={t.completed ? (isEn ? 'Mark as incomplete' : 'অসম্পন্ন করুন') : (isEn ? 'Mark as completed' : 'সম্পন্ন করুন')}
                >
                  {t.completed ? (
                    <CheckCircle2 className="w-5 h-5 fill-blue-600 text-white" />
                  ) : (
                    <Circle className="w-5 h-5 text-slate-400 hover:text-blue-500" />
                  )}
                </button>
                <div>
                  <p
                    className={`text-xs font-medium ${
                      t.completed ? 'line-through text-slate-400' : 'text-slate-800 dark:text-white'
                    }`}
                  >
                    {t.text}
                  </p>
                  {t.dueDate && (
                    <p className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5">
                      <Calendar className="w-3 h-3" />
                      <span>{t.dueDate}</span>
                    </p>
                  )}
                </div>
              </div>

              <button
                onClick={() => deleteTask(t.id)}
                className="p-1 text-slate-400 hover:text-rose-500 rounded-lg transition-colors"
                title={isEn ? 'Delete Task' : 'মুছে ফেলুন'}
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Floating Action Button */}
      <button
        onClick={() => setIsModalOpen(true)}
        className="fixed bottom-6 right-6 z-40 w-14 h-14 rounded-full bg-[#1877f2] hover:bg-blue-600 active:scale-95 text-white shadow-xl shadow-blue-500/30 flex items-center justify-center transition-all focus:outline-none"
        title={isEn ? 'Add Task' : 'নতুন টাস্ক যোগ করুন'}
        aria-label="Add task"
      >
        <Plus className="w-7 h-7 stroke-[2.5]" />
      </button>

      {/* New Task Dialog */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-2xl border border-slate-100 dark:border-slate-800 space-y-4">
            <h3 className="text-sm font-bold text-slate-800 dark:text-white text-center">
              {isEn ? 'New Task' : 'নতুন টাস্ক'}
            </h3>

            <div>
              <textarea
                value={taskText}
                onChange={(e) => setTaskText(e.target.value)}
                placeholder={isEn ? 'Type task details or shopping item...' : 'টাস্ক লিখুন...'}
                rows={3}
                className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                autoFocus
                required
              />
            </div>

            {/* Reminder Button */}
            <div>
              <button
                type="button"
                onClick={() => setShowReminderDialog(true)}
                className="flex items-center gap-1.5 text-xs text-blue-600 dark:text-blue-400 font-semibold hover:underline"
              >
                <Bell className="w-3.5 h-3.5" />
                <span>
                  {dueDate
                    ? `${isEn ? 'Due Date' : 'রিমাইন্ডার'}: ${dueDate}`
                    : isEn
                    ? 'Set Due Date / Reminder'
                    : 'রিমাইন্ডার সেট করুন'}
                </span>
              </button>
            </div>

            {/* Buttons: Cancel | Add */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200"
              >
                {isEn ? 'Cancel' : 'বাতিল'}
              </button>
              <button
                type="button"
                onClick={handleSaveTask}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
              >
                {isEn ? 'Add Task' : 'অ্যাড'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reminder Permission / Date dialog */}
      {showReminderDialog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="w-full max-w-xs bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-2xl space-y-3 border border-slate-100 dark:border-slate-800">
            <h4 className="text-xs font-bold text-slate-800 dark:text-white">
              {isEn ? 'Task Due Date & Reminder' : 'রিমাইন্ডার ও তারিখ'}
            </h4>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              {isEn ? 'Pick a target deadline date for this task' : 'টাস্কটির জন্য তারিখ নির্ধারণ করুন'}
            </p>
            <input
              type="date"
              value={dueDate}
              onChange={(e) => {
                setDueDate(e.target.value);
                setHasReminder(true);
              }}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-800 dark:text-slate-100"
            />
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowReminderDialog(false)}
                className="px-3 py-1.5 text-xs text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
              >
                {isEn ? 'Close' : 'পরে'}
              </button>
              <button
                type="button"
                onClick={() => setShowReminderDialog(false)}
                className="px-4 py-1.5 bg-blue-600 text-white rounded-lg text-xs font-bold shadow-xs"
              >
                {isEn ? 'Set Date' : 'সংরক্ষণ'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
