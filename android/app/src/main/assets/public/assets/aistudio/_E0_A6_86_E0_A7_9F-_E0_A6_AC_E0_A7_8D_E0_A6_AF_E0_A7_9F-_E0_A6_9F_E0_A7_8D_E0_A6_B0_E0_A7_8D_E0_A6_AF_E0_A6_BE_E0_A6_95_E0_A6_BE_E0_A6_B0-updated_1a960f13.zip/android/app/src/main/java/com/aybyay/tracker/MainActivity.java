package com.aybyay.tracker;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
