import React, { useState, useRef } from 'react';
import {
  Moon,
  Sun,
  Globe,
  DollarSign,
  Cloud,
  Download,
  Upload,
  RefreshCw,
  Trash2,
  Check,
  Bell,
  Shield,
  HelpCircle,
  FileText,
  User,
  ExternalLink,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatCurrency, toBanglaNumber } from '../utils/formatters';

export const SettingsView: React.FC = () => {
  const {
    settings,
    updateSettings,
    exportJSON,
    importJSON,
    loadSampleData,
    resetAllData,
    setIsFirebaseModalOpen,
    setActiveTab,
    currentUser,
  } = useApp();

  const isEn = settings.language === 'en';
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [budgetInput, setBudgetInput] = useState(String(settings.monthlyBudget));
  const [userNameInput, setUserNameInput] = useState(settings.userName);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  const handleSaveBudget = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(budgetInput);
    if (!isNaN(val) && val >= 0) {
      updateSettings({ monthlyBudget: val });
      setMessage({
        text: isEn ? 'Monthly budget saved successfully' : 'মাসিক বাজেট সফলভাবে সংরক্ষিত হয়েছে',
        type: 'success',
      });
      setTimeout(() => setMessage(null), 3000);
    }
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (userNameInput.trim()) {
      updateSettings({ userName: userNameInput.trim() });
      setMessage({
        text: isEn ? 'Profile information updated' : 'প্রোফাইল তথ্য আপডেট করা হয়েছে',
        type: 'success',
      });
      setTimeout(() => setMessage(null), 3000);
    }
  };

  const handleExport = () => {
    const dataStr = exportJSON();
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `ay_byay_backup_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    setMessage({
      text: isEn ? 'Backup file downloaded successfully' : 'ব্যাকআপ ফাইল সফলভাবে ডাউনলোড হয়েছে',
      type: 'success',
    });
    setTimeout(() => setMessage(null), 3000);
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        const success = importJSON(content);
        if (success) {
          setMessage({
            text: isEn ? 'Backup data restored successfully' : 'ব্যাকআপ ডাটা সফলভাবে রিস্টোর করা হয়েছে',
            type: 'success',
          });
        } else {
          setMessage({
            text: isEn ? 'Could not read backup file format' : 'ফাইলটি সঠিকভাবে পড়া যায়নি',
            type: 'error',
          });
        }
        setTimeout(() => setMessage(null), 3000);
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="space-y-4 pb-24">
      {/* Toast Alert */}
      {message && (
        <div
          className={`p-3 rounded-2xl text-xs font-semibold flex items-center gap-2 animate-in fade-in ${
            message.type === 'success'
              ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
              : 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 border border-rose-200 dark:border-rose-800'
          }`}
        >
          <Check className="w-4 h-4 flex-shrink-0" />
          <span>{message.text}</span>
        </div>
      )}

      {/* Cloud Sync Status Card */}
      <div className="bg-gradient-to-r from-blue-600/10 via-indigo-600/10 to-purple-600/10 dark:from-blue-950/40 dark:via-indigo-950/40 dark:to-purple-950/40 rounded-2xl p-4 border border-blue-100 dark:border-blue-900 shadow-xs flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
            <Cloud className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-800 dark:text-white flex items-center gap-1.5">
              {isEn ? 'Firebase Cloud Sync' : 'Firebase ক্লাউড সিঙ্ক'}
              <span className={`w-2 h-2 rounded-full ${currentUser ? 'bg-emerald-500 animate-pulse' : 'bg-amber-400'}`} />
            </h4>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              {currentUser
                ? isEn
                  ? `Active for ${currentUser.displayName || currentUser.email}`
                  : `সক্রিয়: ${currentUser.displayName || currentUser.email}`
                : isEn
                ? 'Offline mode (Safe local storage)'
                : 'ডাটা স্থানীয়ভাবে অফলাইন মোডে সংরক্ষিত'}
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsFirebaseModalOpen(true)}
          className="px-3 py-1.5 bg-blue-600 text-white rounded-xl text-xs font-bold hover:bg-blue-700 transition-colors shadow-xs"
        >
          {isEn ? 'Manage' : 'সেটআপ দেখুন'}
        </button>
      </div>

      {/* Profile Section */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-100 dark:border-slate-800 shadow-xs space-y-3">
        <h3 className="text-xs font-bold text-slate-800 dark:text-white flex items-center gap-1.5">
          <User className="w-4 h-4 text-blue-600 dark:text-blue-400" />
          {isEn ? 'Profile Settings' : 'প্রোফাইল সেটিংস'}
        </h3>
        <form onSubmit={handleSaveProfile} className="space-y-3">
          <div>
            <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">
              {isEn ? 'Your Name' : 'ব্যবহারকারীর নাম'}
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={userNameInput}
                onChange={(e) => setUserNameInput(e.target.value)}
                placeholder={isEn ? 'Enter your name' : 'আপনার নাম লিখুন'}
                className="flex-1 px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                type="submit"
                className="px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
              >
                {isEn ? 'Save' : 'সংরক্ষণ'}
              </button>
            </div>
          </div>
        </form>
      </div>

      {/* Appearance & Themes */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-100 dark:border-slate-800 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-slate-800 dark:text-white flex items-center gap-1.5">
            <Sun className="w-4 h-4 text-amber-500" />
            {isEn ? 'Theme & Appearance' : 'থিম ও প্রদর্শন (Theme)'}
          </h3>
          <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
            {settings.theme === 'dark' ? (isEn ? 'Dark' : 'ডার্ক') : settings.theme === 'system' ? (isEn ? 'System' : 'সিস্টেম') : (isEn ? 'Light' : 'লাইট')}
          </span>
        </div>

        <div className="grid grid-cols-3 gap-2">
          {[
            { id: 'light', labelBn: 'লাইট মোড', labelEn: 'Light Mode', icon: Sun },
            { id: 'dark', labelBn: 'ডার্ক মোড', labelEn: 'Dark Mode', icon: Moon },
            { id: 'system', labelBn: 'সিস্টেম', labelEn: 'System', icon: Globe },
          ].map((item) => {
            const Icon = item.icon;
            const isSelected = settings.theme === item.id;
            return (
              <button
                key={item.id}
                onClick={() => updateSettings({ theme: item.id as any })}
                className={`p-2.5 rounded-xl border flex flex-col items-center justify-center gap-1 text-xs font-bold transition-all ${
                  isSelected
                    ? 'border-blue-500 bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 ring-1 ring-blue-500'
                    : 'border-slate-100 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{isEn ? item.labelEn : item.labelBn}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Language & Number Format */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-100 dark:border-slate-800 shadow-xs space-y-3">
        <h3 className="text-xs font-bold text-slate-800 dark:text-white flex items-center gap-1.5">
          <Globe className="w-4 h-4 text-blue-600 dark:text-blue-400" />
          {isEn ? 'Language & Numerals' : 'ভাষা ও সংখ্যা বিন্যাস'}
        </h3>

        {/* Language selector */}
        <div className="flex items-center justify-between py-1">
          <div>
            <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">
              {isEn ? 'App Language' : 'অ্যাপের ভাষা'}
            </p>
            <p className="text-[11px] text-slate-500">
              {isEn ? 'English or Bengali (বাংলা)' : 'বাংলা বা ইংরেজি'}
            </p>
          </div>
          <div className="flex gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs font-bold">
            <button
              onClick={() => updateSettings({ language: 'bn', useBanglaNumerals: true })}
              className={`px-3 py-1 rounded-lg transition-colors ${
                settings.language === 'bn'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              বাংলা
            </button>
            <button
              onClick={() => updateSettings({ language: 'en', useBanglaNumerals: false })}
              className={`px-3 py-1 rounded-lg transition-colors ${
                settings.language === 'en'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              English
            </button>
          </div>
        </div>

        {/* Number Format Switcher */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800">
          <div>
            <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">
              {isEn ? 'Bengali Numerals (১২৩৪৫)' : 'বাংলা সংখ্যা প্রদর্শন (১২৩৪৫)'}
            </p>
            <p className="text-[11px] text-slate-500">
              {isEn ? 'Show amounts & dates using Bengali digits' : 'টাকার অংক এবং তারিখে বাংলা সংখ্যা'}
            </p>
          </div>
          <button
            onClick={() =>
              updateSettings({ useBanglaNumerals: !settings.useBanglaNumerals })
            }
            className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors ${
              settings.useBanglaNumerals ? 'bg-blue-600' : 'bg-slate-300 dark:bg-slate-700'
            }`}
          >
            <div
              className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                settings.useBanglaNumerals ? 'translate-x-6' : 'translate-x-0'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Monthly Budget Setter */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-100 dark:border-slate-800 shadow-xs space-y-3">
        <h3 className="text-xs font-bold text-slate-800 dark:text-white flex items-center gap-1.5">
          <Bell className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
          {isEn ? 'Monthly Budget & Alerts' : 'মাসিক বাজেট ও সতর্কতা'}
        </h3>

        <form onSubmit={handleSaveBudget} className="space-y-3">
          <div>
            <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">
              {isEn ? 'Monthly Budget Limit (৳ / BDT)' : 'মাসিক বাজেটের সর্বোচ্চ সীমা (টাকা)'}
            </label>
            <div className="flex gap-2">
              <input
                type="number"
                value={budgetInput}
                onChange={(e) => setBudgetInput(e.target.value)}
                className="flex-1 px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                type="submit"
                className="px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
              >
                {isEn ? 'Update' : 'আপডেট'}
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800">
            <div>
              <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                {isEn ? 'Budget Alert Notifications' : 'বাজেট সতর্কতা নোটিফিকেশন'}
              </p>
              <p className="text-[11px] text-slate-500">
                {isEn ? 'Alerts when spending crosses 85% of budget' : 'বাজেটের ৮৫% পার হলে সতর্কতা দেখাবে'}
              </p>
            </div>
            <button
              type="button"
              onClick={() =>
                updateSettings({ enableBudgetAlerts: !settings.enableBudgetAlerts })
              }
              className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors ${
                settings.enableBudgetAlerts ? 'bg-blue-600' : 'bg-slate-300 dark:bg-slate-700'
              }`}
            >
              <div
                className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                  settings.enableBudgetAlerts ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </form>
      </div>

      {/* Category Management Shortcut */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-100 dark:border-slate-800 shadow-xs flex items-center justify-between">
        <div>
          <h4 className="text-xs font-bold text-slate-800 dark:text-white">
            {isEn ? 'Category Management' : 'ক্যাটাগরি ব্যবস্থাপনা'}
          </h4>
          <p className="text-[11px] text-slate-500">
            {isEn ? 'Create, edit & customize income and expense categories' : 'আয় ও ব্যয়ের ক্যাটাগরি তৈরি, সম্পাদনা ও পরিবর্তন করুন'}
          </p>
        </div>
        <button
          onClick={() => setActiveTab('categories')}
          className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-800 dark:text-slate-200 rounded-xl text-xs font-bold transition-colors"
        >
          {isEn ? 'Open Categories →' : 'ক্যাটাগরি খুলুন →'}
        </button>
      </div>

      {/* Data Management & Backup */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-100 dark:border-slate-800 shadow-xs space-y-3">
        <h3 className="text-xs font-bold text-slate-800 dark:text-white flex items-center gap-1.5">
          <Download className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          {isEn ? 'Data Backup & Restore' : 'ডাটা ব্যাকআপ ও রিস্টোর'}
        </h3>

        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={handleExport}
            className="p-3 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 rounded-xl text-xs font-bold flex flex-col items-center justify-center gap-1 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 transition-colors"
          >
            <Download className="w-4 h-4" />
            {isEn ? 'Download Backup (JSON)' : 'ব্যাকআপ ডাউনলোড (JSON)'}
          </button>

          <label className="p-3 bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 rounded-xl text-xs font-bold flex flex-col items-center justify-center gap-1 hover:bg-blue-100 dark:hover:bg-blue-900/50 transition-colors cursor-pointer">
            <Upload className="w-4 h-4" />
            {isEn ? 'Restore Backup (JSON)' : 'ব্যাকআপ রিস্টোর (JSON)'}
            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              onChange={handleImportFile}
              className="hidden"
            />
          </label>
        </div>

        {/* Load Demo Data & Reset */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800">
          <button
            onClick={() => {
              loadSampleData();
              setMessage({
                text: isEn ? 'Demo transactions loaded' : 'ডেমো লেনদেনের তথ্য লোড করা হয়েছে',
                type: 'success',
              });
              setTimeout(() => setMessage(null), 3000);
            }}
            className="flex items-center gap-1 text-xs text-blue-600 dark:text-blue-400 font-bold hover:underline"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            {isEn ? 'Load Demo Data' : 'ডেমো ডাটা লোড করুন'}
          </button>

          {!showResetConfirm ? (
            <button
              onClick={() => setShowResetConfirm(true)}
              className="flex items-center gap-1 text-xs text-rose-600 dark:text-rose-400 font-semibold hover:underline"
            >
              <Trash2 className="w-3.5 h-3.5" />
              {isEn ? 'Reset All Data' : 'সমস্ত ডাটা মুছুন'}
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <span className="text-[11px] text-rose-600 dark:text-rose-400 font-bold">
                {isEn ? 'Delete all?' : 'মুছে ফেলবেন?'}
              </span>
              <button
                onClick={() => {
                  resetAllData();
                  setShowResetConfirm(false);
                  setMessage({
                    text: isEn ? 'All data has been wiped' : 'সমস্ত তথ্য মুছে ফেলা হয়েছে',
                    type: 'success',
                  });
                  setTimeout(() => setMessage(null), 3000);
                }}
                className="px-2 py-1 bg-rose-600 text-white rounded-md text-[11px] font-bold"
              >
                {isEn ? 'Yes' : 'হ্যাঁ'}
              </button>
              <button
                onClick={() => setShowResetConfirm(false)}
                className="px-2 py-1 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-md text-[11px]"
              >
                {isEn ? 'Cancel' : 'বাতিল'}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* App Info Footer */}
      <div className="text-center py-4 text-xs text-slate-400 dark:text-slate-500 space-y-1">
        <p className="font-bold text-slate-600 dark:text-slate-400">
          {isEn ? 'Income Expense (Ay-Byay) - Version 1.0' : 'আয় ব্যয় (Ay-Byay) - সংস্করণ ১.০'}
        </p>
        <p>
          {isEn ? 'Your personal financial records are securely protected' : 'আপনার সকল ব্যক্তিগত আর্থিক হিসাব নিরাপদে সুরক্ষিত'}
        </p>
      </div>
    </div>
  );
};
