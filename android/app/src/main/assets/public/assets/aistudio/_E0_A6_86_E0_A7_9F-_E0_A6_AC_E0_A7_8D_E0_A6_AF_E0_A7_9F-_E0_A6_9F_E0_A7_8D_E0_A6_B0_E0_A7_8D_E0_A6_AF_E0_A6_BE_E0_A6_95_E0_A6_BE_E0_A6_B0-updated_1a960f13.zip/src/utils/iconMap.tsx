import React from 'react';
import {
  Utensils,
  ShoppingBasket,
  Home,
  Car,
  Zap,
  Wifi,
  HeartPulse,
  ShoppingBag,
  GraduationCap,
  Film,
  Gift,
  HandCoins,
  MoreHorizontal,
  Briefcase,
  Building2,
  Laptop,
  Store,
  TrendingUp,
  PartyPopper,
  PlusCircle,
  Wallet,
  Smartphone,
  Landmark,
  CreditCard,
  Coffee,
  Bus,
  Plane,
  Baby,
  Dumbbell,
  Book,
  Camera,
  Shirt,
  PiggyBank,
  ArrowDownLeft,
  ArrowUpRight,
  RefreshCw,
  LucideProps,
} from 'lucide-react';

const iconRegistry: Record<string, React.FC<LucideProps>> = {
  Utensils,
  ShoppingBasket,
  Home,
  Car,
  Zap,
  Wifi,
  HeartPulse,
  ShoppingBag,
  GraduationCap,
  Film,
  Gift,
  HandCoins,
  MoreHorizontal,
  Briefcase,
  Building2,
  Laptop,
  Store,
  TrendingUp,
  PartyPopper,
  PlusCircle,
  Wallet,
  Smartphone,
  Landmark,
  CreditCard,
  Coffee,
  Bus,
  Plane,
  Baby,
  Dumbbell,
  Book,
  Camera,
  Shirt,
  PiggyBank,
  ArrowDownLeft,
  ArrowUpRight,
  RefreshCw,
};

export const AVAILABLE_CATEGORY_ICONS = [
  'Utensils',
  'ShoppingBasket',
  'Home',
  'Car',
  'Zap',
  'Wifi',
  'HeartPulse',
  'ShoppingBag',
  'GraduationCap',
  'Film',
  'Gift',
  'HandCoins',
  'Briefcase',
  'Building2',
  'Laptop',
  'Store',
  'TrendingUp',
  'PartyPopper',
  'Coffee',
  'Bus',
  'Plane',
  'Baby',
  'Dumbbell',
  'Book',
  'Shirt',
  'PiggyBank',
  'MoreHorizontal',
];

export const AVAILABLE_COLORS = [
  '#ef4444', // red
  '#f97316', // orange
  '#f59e0b', // amber
  '#10b981', // emerald
  '#06b6d4', // cyan
  '#3b82f6', // blue
  '#6366f1', // indigo
  '#8b5cf6', // violet
  '#ec4899', // pink
  '#14b8a6', // teal
  '#64748b', // slate
  '#84cc16', // lime
];

export const renderCategoryIcon = (
  iconName?: string,
  className = 'w-5 h-5',
  color?: string
) => {
  const IconComponent = (iconName && iconRegistry[iconName]) || MoreHorizontal;
  return <IconComponent className={className} style={color ? { color } : undefined} />;
};
