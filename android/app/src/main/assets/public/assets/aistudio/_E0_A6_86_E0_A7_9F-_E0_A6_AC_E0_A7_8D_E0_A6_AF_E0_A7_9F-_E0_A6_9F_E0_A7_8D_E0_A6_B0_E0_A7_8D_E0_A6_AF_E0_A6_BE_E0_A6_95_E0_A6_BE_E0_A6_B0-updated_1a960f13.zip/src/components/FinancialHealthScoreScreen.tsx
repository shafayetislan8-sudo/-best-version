import React, { useMemo } from 'react';
import { ArrowLeft, Award, TrendingUp, ShieldCheck, AlertCircle, Lightbulb, CheckCircle2 } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatCurrency, toBanglaNumber } from '../utils/formatters';

export const FinancialHealthScoreScreen: React.FC = () => {
  const {
    monthlyIncome,
    monthlyExpense,
    monthlyBalance,
    totalReceivable,
    totalPayable,
    budgets,
    settings,
    setActiveTab,
  } = useApp();

  const isEn = settings.language === 'en';

  // Dynamic Score Calculation (0 to 100)
  const healthData = useMemo(() => {
    let score = 50; // base

    // 1. Savings Rate (+/- 25 pts)
    const savingsRate = monthlyIncome > 0 ? (monthlyBalance / monthlyIncome) * 100 : 0;
    if (savingsRate >= 30) score += 25;
    else if (savingsRate >= 15) score += 15;
    else if (savingsRate >= 5) score += 5;
    else score -= 15;

    // 2. Budget adherence (+/- 20 pts)
    const totalBudget = budgets.reduce((sum, b) => sum + b.value, 0) || settings.monthlyBudget || 0;
    if (totalBudget > 0) {
      if (monthlyExpense <= totalBudget * 0.8) score += 20;
      else if (monthlyExpense <= totalBudget) score += 10;
      else score -= 20;
    } else {
      score += 10;
    }

    // 3. Debt to Income ratio (+/- 15 pts)
    if (totalPayable <= totalReceivable) score += 15;
    else score -= 10;

    const finalScore = Math.min(100, Math.max(10, Math.round(score)));

    // Status Label & Color
    let statusText = isEn ? 'Satisfactory Financial Condition' : 'সন্তোষজনক অবস্থা';
    let statusColor = 'text-blue-600 dark:text-blue-400';
    let badgeBg = 'bg-blue-50 dark:bg-blue-950/60 border-blue-200 dark:border-blue-800';

    if (finalScore >= 80) {
      statusText = isEn ? 'Excellent Financial Discipline 🌟' : 'চমৎকার আর্থিক শৃঙ্খলা 🌟';
      statusColor = 'text-emerald-600 dark:text-emerald-400';
      badgeBg = 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-200 dark:border-emerald-800';
    } else if (finalScore < 60) {
      statusText = isEn ? 'Caution & Budgeting Recommended ⚠️' : 'সতর্কতা ও মিতব্যয়িতা প্রয়োজন ⚠️';
      statusColor = 'text-amber-600 dark:text-amber-400';
      badgeBg = 'bg-amber-50 dark:bg-amber-950/60 border-amber-200 dark:border-amber-800';
    }

    // Actionable smart tips
    const tips: string[] = [];
    if (savingsRate < 20) {
      tips.push(
        isEn
          ? 'Your savings rate is below 20%. Trim discretionary spending to build an emergency fund.'
          : 'আপনার সঞ্চয়ের হার ২০% এর কম। অপ্রয়োজনীয় কেনাকাটা সীমিত করে জরুরি ফান্ড গড়ে তুলুন।'
      );
    } else {
      tips.push(
        isEn
          ? 'Great savings discipline! Consider putting surplus savings into high-yield accounts or DPS.'
          : 'আপনার সঞ্চয়ের হার চমৎকার! বাড়তি সঞ্চয় কোনো লাভজনক খাতে বা ডিপিএসে বিনিয়োগ করতে পারেন।'
      );
    }

    if (totalPayable > totalReceivable) {
      tips.push(
        isEn
          ? 'Your payables (debt) exceed receivables. Focus on clearing outstanding liabilities first.'
          : 'পাওনার চেয়ে আপনার দায়ের (দিতে হবে) পরিমাণ বেশি। দ্রুত ঋণ বা বাকি পরিশোধের চেষ্টা করুন।'
      );
    }

    if (monthlyExpense > 0) {
      tips.push(
        isEn
          ? 'Setting monthly budget caps helps households save 15% to 20% more on average.'
          : 'মাসিক বাজেট তৈরি করে খরচ করলে গড়ে ১৫%-২০% বেশি টাকা সাশ্রয় করা সম্ভব।'
      );
    }

    return {
      score: finalScore,
      savingsRate: Math.max(0, Math.round(savingsRate)),
      statusText,
      statusColor,
      badgeBg,
      tips,
    };
  }, [monthlyIncome, monthlyExpense, monthlyBalance, totalReceivable, totalPayable, budgets, settings, isEn]);

  return (
    <div className="space-y-4 pb-24 pt-1">
      {/* Top Header */}
      <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setActiveTab('profile_menu')}
            className="p-1.5 rounded-full text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title={isEn ? 'Back' : 'পেছনে যান'}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              {isEn ? 'Financial Health Score' : 'আর্থিক স্বাস্থ্য স্কোর'}
            </h2>
          </div>
        </div>
      </div>

      {/* Main Score Hero Card */}
      <div className={`p-6 rounded-3xl border shadow-xs text-center space-y-3 ${healthData.badgeBg}`}>
        <div className="w-24 h-24 rounded-full mx-auto bg-white dark:bg-slate-900 shadow-md border-4 border-emerald-500 flex flex-col items-center justify-center">
          <span className="text-3xl font-black text-slate-900 dark:text-white leading-none">
            {settings.useBanglaNumerals && !isEn ? toBanglaNumber(healthData.score) : healthData.score}
          </span>
          <span className="text-[10px] text-slate-400 font-bold mt-1">
            {isEn ? '/ 100' : '/ ১০০'}
          </span>
        </div>

        <div>
          <h3 className={`text-base font-black ${healthData.statusColor}`}>
            {healthData.statusText}
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">
            {isEn
              ? 'Overall financial discipline evaluation based on your income, spending & debts.'
              : 'আপনার আয়, ব্যয় ও সঞ্চয়ের শৃঙ্খলার সামগ্রিক মূল্যায়ন'}
          </p>
        </div>
      </div>

      {/* 4 Pillars Grid */}
      <div className="grid grid-cols-2 gap-2.5">
        <div className="p-3.5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-xs space-y-1">
          <span className="text-[10px] text-slate-400 block">{isEn ? 'Savings Rate' : 'সঞ্চয়ের হার'}</span>
          <p className="text-sm font-bold text-emerald-600 dark:text-emerald-400">
            {settings.useBanglaNumerals && !isEn ? toBanglaNumber(healthData.savingsRate) : healthData.savingsRate}%
          </p>
          <p className="text-[9px] text-slate-400">{isEn ? 'Target: > 20%' : 'লক্ষ্য: ২০% এর বেশি'}</p>
        </div>

        <div className="p-3.5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-xs space-y-1">
          <span className="text-[10px] text-slate-400 block">{isEn ? 'Net Balance' : 'চলতি ব্যালেন্স'}</span>
          <p
            className={`text-sm font-bold truncate ${
              monthlyBalance >= 0 ? 'text-blue-600 dark:text-blue-400' : 'text-rose-600 dark:text-rose-400'
            }`}
          >
            {formatCurrency(monthlyBalance, settings.useBanglaNumerals && !isEn)}
          </p>
          <p className="text-[9px] text-slate-400">{isEn ? 'Monthly Surplus' : 'মাসিক উদ্বৃত্ত'}</p>
        </div>

        <div className="p-3.5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-xs space-y-1">
          <span className="text-[10px] text-slate-400 block">{isEn ? 'Receivables' : 'মোট পাওনা (পাবো)'}</span>
          <p className="text-sm font-bold text-emerald-600 dark:text-emerald-400">
            {formatCurrency(totalReceivable, settings.useBanglaNumerals && !isEn)}
          </p>
          <p className="text-[9px] text-slate-400">{isEn ? 'Money Lent Out' : 'ধার দেওয়া টাকা'}</p>
        </div>

        <div className="p-3.5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-xs space-y-1">
          <span className="text-[10px] text-slate-400 block">{isEn ? 'Payables' : 'মোট দায় (দিবো)'}</span>
          <p className="text-sm font-bold text-rose-600 dark:text-rose-400">
            {formatCurrency(totalPayable, settings.useBanglaNumerals && !isEn)}
          </p>
          <p className="text-[9px] text-slate-400">{isEn ? 'Due to Pay' : 'পরিশোধযোগ্য বাকি'}</p>
        </div>
      </div>

      {/* Smart Personalized Advice */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 border border-slate-100 dark:border-slate-800 shadow-xs space-y-3">
        <div className="flex items-center gap-2">
          <Lightbulb className="w-4 h-4 text-amber-500" />
          <h3 className="text-xs font-bold text-slate-800 dark:text-white">
            {isEn ? 'Financial Growth Tips & Advice' : 'আর্থিক উন্নতির পরামর্শ ও টিপস'}
          </h3>
        </div>

        <div className="space-y-2">
          {healthData.tips.map((tip, idx) => (
            <div
              key={idx}
              className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 flex items-start gap-2.5 leading-relaxed"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
              <span>{tip}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
