import React from 'react';
import {
  User,
  X,
  Mail,
  Receipt,
  Wallet,
  Settings,
  Download,
  ShieldCheck,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatCurrency, toBanglaNumber } from '../utils/formatters';

export const ProfileModal: React.FC = () => {
  const {
    isProfileOpen,
    setIsProfileOpen,
    settings,
    transactions,
    accounts,
    totalAccountBalance,
    exportJSON,
    setActiveTab,
    currentUser,
    setIsFirebaseModalOpen,
    lastCloudSyncTime,
  } = useApp();

  if (!isProfileOpen) return null;

  const isEn = settings.language === 'en';

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-2xl shadow-2xl border border-gray-100 dark:border-slate-800 p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <h3 className="text-base font-bold text-slate-800 dark:text-white">
            {isEn ? 'Profile Overview' : 'প্রোফাইল বিবরণ'}
          </h3>
          <button
            onClick={() => setIsProfileOpen(false)}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
            title={isEn ? 'Close' : 'বন্ধ করুন'}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Profile Header */}
        <div className="flex items-center gap-3.5 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60">
          {currentUser?.photoURL ? (
            <img
              src={currentUser.photoURL}
              alt={currentUser.displayName || 'User'}
              className="w-14 h-14 rounded-2xl ring-2 ring-blue-500 shadow-md object-cover"
            />
          ) : (
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white font-bold text-xl flex items-center justify-center shadow-md">
              {currentUser?.displayName
                ? currentUser.displayName.charAt(0)
                : settings.userName
                ? settings.userName.charAt(0)
                : 'S'}
            </div>
          )}
          <div>
            <h4 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              {currentUser?.displayName || settings.userName}
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
            </h4>
            <p className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1 mt-0.5">
              <Mail className="w-3.5 h-3.5" />
              {currentUser?.email || settings.userEmail || 'user@example.com'}
            </p>
          </div>
        </div>

        {/* Cloud Sync Status Banner */}
        <div
          onClick={() => {
            setIsProfileOpen(false);
            setIsFirebaseModalOpen(true);
          }}
          className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-colors ${
            currentUser
              ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300'
              : 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300'
          }`}
        >
          <div className="flex items-center gap-2">
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                currentUser ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'
              }`}
            />
            <div className="text-left">
              <p className="text-xs font-bold">
                {currentUser
                  ? isEn
                    ? 'Cloud Backup & Sync Active'
                    : 'অনলাইন ক্লাউড ব্যাকআপ সক্রিয়'
                  : isEn
                  ? 'Cloud Backup Disabled'
                  : 'ফ্রি অনলাইন ক্লাউড ব্যাকআপ বন্ধ'}
              </p>
              <p className="text-[10px] opacity-80">
                {currentUser
                  ? isEn
                    ? `Last Sync: ${lastCloudSyncTime || 'Real-time'}`
                    : `সর্বশেষ সিঙ্ক: ${lastCloudSyncTime || 'রিয়েল-টাইম'}`
                  : isEn
                  ? 'Sign in to keep your data safe even if you uninstall'
                  : 'আনইনস্টল করলেও ডাটা সুরক্ষিত রাখতে লগইন করুন'}
              </p>
            </div>
          </div>
          <span className="text-xs font-bold underline">
            {isEn ? 'Manage →' : 'পরিচালনা →'}
          </span>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-2 gap-2 text-center">
          <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-100 dark:border-slate-800">
            <span className="text-[11px] text-slate-500 dark:text-slate-400 block">
              {isEn ? 'Total Transactions' : 'মোট লিপিবদ্ধ লেনদেন'}
            </span>
            <span className="text-base font-bold text-slate-900 dark:text-white">
              {settings.useBanglaNumerals && !isEn
                ? toBanglaNumber(transactions.length)
                : transactions.length}{' '}
              {isEn ? 'items' : 'টি'}
            </span>
          </div>

          <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-100 dark:border-slate-800">
            <span className="text-[11px] text-slate-500 dark:text-slate-400 block">
              {isEn ? 'Wallets & Accounts' : 'সংযুক্ত ওয়ালেট ও ব্যাংক'}
            </span>
            <span className="text-base font-bold text-slate-900 dark:text-white">
              {settings.useBanglaNumerals && !isEn ? toBanglaNumber(accounts.length) : accounts.length}{' '}
              {isEn ? 'accounts' : 'টি'}
            </span>
          </div>
        </div>

        {/* Quick Links */}
        <div className="space-y-2 pt-1">
          <button
            onClick={() => {
              setIsProfileOpen(false);
              setActiveTab('settings');
            }}
            className="w-full p-2.5 rounded-xl border border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-slate-300 transition-colors"
          >
            <span className="flex items-center gap-2">
              <Settings className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              {isEn ? 'Open App Settings' : 'অ্যাপ সেটিংস পরিবর্তন করুন'}
            </span>
            <span>→</span>
          </button>
        </div>
      </div>
    </div>
  );
};
