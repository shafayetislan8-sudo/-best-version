import React, { useState } from 'react';
import { ArrowLeft, Trash2, AlertCircle } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const TrashScreen: React.FC = () => {
  const { trash, emptyTrash, setActiveTab, settings } = useApp();
  const isEn = settings.language === 'en';
  const [showConfirmModal, setShowConfirmModal] = useState(false);

  const handleConfirmEmpty = () => {
    emptyTrash();
    setShowConfirmModal(false);
  };

  return (
    <div className="space-y-4 pb-20 pt-1">
      {/* Header */}
      <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setActiveTab('persons')}
            className="p-1 rounded-full text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title={isEn ? 'Back' : 'পেছনে যান'}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="text-base font-bold text-slate-900 dark:text-white">
            {isEn ? 'Trash' : 'ট্র্যাশ'}
          </h2>
        </div>

        {trash.length > 0 && (
          <button
            onClick={() => setShowConfirmModal(true)}
            className="text-xs text-rose-600 dark:text-rose-400 font-bold hover:underline"
          >
            {isEn ? 'Empty Trash' : 'খালি করুন'}
          </button>
        )}
      </div>

      {/* Empty State */}
      {trash.length === 0 ? (
        <div className="py-24 flex flex-col items-center justify-center text-center">
          <div className="text-slate-300 dark:text-slate-600 mb-3">
            <svg
              className="w-16 h-16"
              viewBox="0 0 48 48"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <polyline points="6 12 10 12 42 12" />
              <path d="M38 12l-2 26a3 3 0 0 1-3 3H15a3 3 0 0 1-3-3L10 12" />
              <path d="M18 12V8a3 3 0 0 1 3-3h6a3 3 0 0 1 3 3v4" />
              <line x1="20" y1="20" x2="20" y2="32" />
              <line x1="28" y1="20" x2="28" y2="32" />
            </svg>
          </div>
          <p className="text-xs font-medium text-slate-400 dark:text-slate-500">
            {isEn ? 'Trash is empty' : 'ট্র্যাশ খালি আছে'}
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {trash.map((item, index) => (
            <div
              key={index}
              className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-800 shadow-xs flex items-center justify-between"
            >
              <div>
                <h4 className="text-xs font-bold text-slate-800 dark:text-white">
                  {item.name || item.categoryName || (isEn ? 'Deleted Record' : 'মুছে ফেলা এন্ট্রি')}
                </h4>
                <p className="text-[10px] text-slate-400 dark:text-slate-500">{item.deletedAt || ''}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* In-app Confirmation Modal for Empty Trash (replacing window.confirm) */}
      {showConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-xs bg-white dark:bg-slate-900 rounded-3xl p-5 shadow-2xl space-y-4 border border-slate-100 dark:border-slate-800 animate-in fade-in">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-rose-50 dark:bg-rose-950/60 text-rose-500 flex items-center justify-center flex-shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-800 dark:text-white">
                  {isEn ? 'Empty Trash?' : 'ট্র্যাশ খালি করতে চান?'}
                </h3>
                <p className="text-[11px] text-slate-400">
                  {isEn ? 'All items in trash will be permanently removed.' : 'সকল মুছে ফেলা তথ্য স্থায়ীভাবে ডিলিট হয়ে যাবে।'}
                </p>
              </div>
            </div>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowConfirmModal(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200"
              >
                {isEn ? 'Cancel' : 'বাতিল'}
              </button>
              <button
                onClick={handleConfirmEmpty}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
              >
                {isEn ? 'Yes, Delete' : 'হ্যাঁ, মুছুন'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
