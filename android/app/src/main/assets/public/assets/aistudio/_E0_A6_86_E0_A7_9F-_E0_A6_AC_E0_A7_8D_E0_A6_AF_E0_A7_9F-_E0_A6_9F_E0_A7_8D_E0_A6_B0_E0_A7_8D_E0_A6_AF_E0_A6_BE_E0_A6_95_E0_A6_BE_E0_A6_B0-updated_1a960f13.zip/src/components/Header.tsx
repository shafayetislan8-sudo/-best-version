import React from 'react';
import {
  Bell,
  Sun,
  Moon,
  Settings,
  Zap,
  Mic,
  Cloud,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const Header: React.FC = () => {
  const {
    settings,
    updateSettings,
    setIsNotificationsOpen,
    setIsVoiceModalOpen,
    setIsFirebaseModalOpen,
    setActiveTab,
    persons,
    monthlyExpense,
    currentUser,
    isCloudSyncing,
  } = useApp();

  const isDarkActive =
    settings.theme === 'dark' ||
    (settings.theme === 'system' &&
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-color-scheme: dark)').matches);

  const toggleTheme = () => {
    const nextTheme = isDarkActive ? 'light' : 'dark';
    updateSettings({ theme: nextTheme });
  };

  const pendingCount = persons.length;
  const isBudgetWarning =
    settings.enableBudgetAlerts &&
    settings.monthlyBudget > 0 &&
    monthlyExpense >= settings.monthlyBudget * 0.85;
  const totalAlerts = pendingCount + (isBudgetWarning ? 1 : 0);

  return (
    <header className="sticky top-0 z-30 bg-white dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800 transition-colors">
      <div className="max-w-md mx-auto px-4 py-3 flex items-center justify-between">
        {/* App Title & Logo matching screenshot: ⚡ আয় ব্যয় */}
        <div className="flex items-center gap-1.5">
          <div className="text-blue-600 dark:text-blue-500">
            {/* Custom stylized bolt matching screenshot */}
            <svg
              className="w-6 h-6 fill-blue-600 text-blue-600"
              viewBox="0 0 24 24"
              fill="currentColor"
            >
              <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" />
            </svg>
          </div>
          <h1 className="text-xl font-bold tracking-tight text-blue-600 dark:text-blue-500 leading-none">
            {settings.language === 'en' ? 'Income Expense' : 'আয় ব্যয়'}
          </h1>
        </div>

        {/* Action Icons: Mic, Cloud, Bell, Moon/Sun, Lang, Gear */}
        <div className="flex items-center gap-2">
          {/* Quick Language Switcher Pill */}
          <button
            onClick={() =>
              updateSettings({
                language: settings.language === 'en' ? 'bn' : 'en',
                useBanglaNumerals: settings.language === 'en',
              })
            }
            className="px-2 py-0.5 rounded-lg text-[11px] font-bold border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:border-blue-500 text-slate-700 dark:text-slate-200 transition-colors shadow-2xs"
            title={settings.language === 'en' ? 'বাংলা ভাষায় পরিবর্তন করুন' : 'Switch to English'}
          >
            {settings.language === 'en' ? 'বাং' : 'EN'}
          </button>

          {/* Bangla Voice Entry Mic Button */}
          <button
            onClick={() => setIsVoiceModalOpen(true)}
            className="p-1.5 rounded-full text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/50 transition-colors animate-pulse"
            title={settings.language === 'en' ? 'Voice Entry' : 'মুখে বলে এন্ট্রি (ভয়েস)'}
            aria-label="Voice input"
          >
            <Mic className="w-4 h-4 stroke-[2.3]" />
          </button>

          {/* Cloud Sync Button with Live Status */}
          <button
            onClick={() => setIsFirebaseModalOpen(true)}
            className="relative p-1.5 text-slate-700 dark:text-slate-300 hover:text-blue-600 transition-colors"
            title={
              currentUser
                ? settings.language === 'en'
                  ? `Cloud Sync Active (${currentUser.displayName || currentUser.email})`
                  : `অনলাইন ক্লাউড সিঙ্ক সক্রিয় (${currentUser.displayName || currentUser.email})`
                : settings.language === 'en'
                ? 'Free Cloud Backup & Sync'
                : 'ফ্রি অনলাইন ক্লাউড ব্যাকআপ চালু করুন'
            }
            aria-label="Cloud Sync"
          >
            <Cloud
              className={`w-4 h-4 ${
                isCloudSyncing ? 'animate-pulse text-blue-600' : currentUser ? 'text-emerald-600' : ''
              }`}
            />
            <span
              className={`absolute top-1 right-1 w-2 h-2 rounded-full ring-1 ring-white dark:ring-slate-900 ${
                currentUser ? 'bg-emerald-500 animate-pulse' : 'bg-amber-400'
              }`}
            />
          </button>

          {/* Notifications Bell */}
          <button
            onClick={() => setIsNotificationsOpen(true)}
            className="relative p-1 text-slate-800 dark:text-slate-200 hover:text-blue-600 transition-colors"
            title={settings.language === 'en' ? 'Notifications' : 'বিজ্ঞপ্তি'}
            aria-label="Notifications"
          >
            <Bell className="w-5 h-5 fill-slate-800 dark:fill-slate-200 text-slate-800 dark:text-slate-200" />
            <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center ring-2 ring-white dark:ring-slate-900">
              {totalAlerts > 0 ? totalAlerts : 1}
            </span>
          </button>

          {/* Theme Toggle Moon/Sun */}
          <button
            onClick={toggleTheme}
            className="p-1 text-slate-800 dark:text-slate-200 hover:text-amber-500 transition-colors"
            title={
              isDarkActive
                ? settings.language === 'en'
                  ? 'Switch to Light Mode'
                  : 'লাইট মোড'
                : settings.language === 'en'
                ? 'Switch to Dark Mode'
                : 'ডার্ক মোড'
            }
            aria-label="Toggle theme"
          >
            {isDarkActive ? (
              <Sun className="w-5 h-5 text-amber-400" />
            ) : (
              <Moon className="w-5 h-5 fill-slate-800 dark:fill-slate-200" />
            )}
          </button>

          {/* Settings Cog */}
          <button
            onClick={() => setActiveTab('settings')}
            className="p-1 text-slate-800 dark:text-slate-200 hover:text-blue-600 transition-colors"
            title={settings.language === 'en' ? 'Settings' : 'সেটিংস'}
            aria-label="Settings"
          >
            <Settings className="w-5 h-5 fill-slate-800 dark:fill-slate-200" />
          </button>
        </div>
      </div>
    </header>
  );
};
