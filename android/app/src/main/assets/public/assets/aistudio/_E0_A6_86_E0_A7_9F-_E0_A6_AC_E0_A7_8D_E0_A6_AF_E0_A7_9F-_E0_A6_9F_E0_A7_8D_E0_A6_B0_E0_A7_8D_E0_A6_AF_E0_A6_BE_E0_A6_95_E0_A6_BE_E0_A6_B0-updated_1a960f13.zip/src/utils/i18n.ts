export type AppLanguage = 'bn' | 'en';

export const translations = {
  // App Header & Branding
  appTitle: {
    bn: 'আয় ব্যয়',
    en: 'Income & Expense',
  },
  voiceInput: {
    bn: 'মুখে বলে এন্ট্রি (ভয়েস)',
    en: 'Voice Entry',
  },
  cloudSync: {
    bn: 'অনলাইন ক্লাউড সিঙ্ক ও ব্যাকআপ',
    en: 'Cloud Sync & Backup',
  },
  notifications: {
    bn: 'বিজ্ঞপ্তি',
    en: 'Notifications',
  },
  lightMode: {
    bn: 'লাইট মোড',
    en: 'Light Mode',
  },
  darkMode: {
    bn: 'ডার্ক মোড',
    en: 'Dark Mode',
  },
  systemTheme: {
    bn: 'সিস্টেম থিম',
    en: 'System Theme',
  },
  settings: {
    bn: 'সেটিংস',
    en: 'Settings',
  },

  // Main Nav Tabs
  dashboard: {
    bn: 'ড্যাশবোর্ড',
    en: 'Dashboard',
  },
  persons: {
    bn: 'দেনা-পাওনা',
    en: 'Debts & Ledger',
  },
  budget: {
    bn: 'বাজেট',
    en: 'Budget',
  },
  savings: {
    bn: 'সঞ্চয়',
    en: 'Savings',
  },
  tasks: {
    bn: 'চেকলিস্ট',
    en: 'Tasks',
  },
  profileMenu: {
    bn: 'টুলস ও মেনু',
    en: 'Tools & Menu',
  },
  reports: {
    bn: 'রিপোর্ট',
    en: 'Reports',
  },
  notes: {
    bn: 'নোটবুক',
    en: 'Notebook',
  },
  categories: {
    bn: 'ক্যাটাগরি',
    en: 'Categories',
  },
  trash: {
    bn: 'ট্র্যাশ বিন',
    en: 'Trash Bin',
  },
  graphView: {
    bn: 'গ্রাফ ও চার্ট',
    en: 'Analytics',
  },
  quickEntry: {
    bn: 'কুইক এন্ট্রি',
    en: 'Quick Entry',
  },
  recurring: {
    bn: 'নিয়মিত রিকারিং',
    en: 'Recurring',
  },
  mess: {
    bn: 'মেস ও মিল হিসাব',
    en: 'Mess Splitter',
  },
  smsParse: {
    bn: 'SMS ট্র্যাকার',
    en: 'SMS Parser',
  },
  calendarHeatmap: {
    bn: 'ক্যালেন্ডার হিটম্যাপ',
    en: 'Calendar',
  },
  healthScore: {
    bn: 'আর্থিক স্বাস্থ্য',
    en: 'Health Score',
  },

  // Periods
  today: {
    bn: 'আজ',
    en: 'Today',
  },
  month: {
    bn: 'মাস',
    en: 'Month',
  },
  total: {
    bn: 'মোট',
    en: 'Total',
  },

  // Dashboard & Metrics
  totalIncome: {
    bn: 'মোট আয়',
    en: 'Total Income',
  },
  totalExpense: {
    bn: 'মোট ব্যয়',
    en: 'Total Expense',
  },
  netBalance: {
    bn: 'অবশিষ্ট স্থিতি',
    en: 'Net Balance',
  },
  dailyAverage: {
    bn: 'দৈনিক গড় ব্যয়',
    en: 'Daily Average',
  },
  searchPlaceholder: {
    bn: 'ক্যাটাগরি বা নোট দিয়ে খুঁজুন...',
    en: 'Search by category or note...',
  },
  recentTransactions: {
    bn: 'সাম্প্রতিক লেনদেন',
    en: 'Recent Transactions',
  },
  noTransactions: {
    bn: 'কোনো লেনদেন লিপিবদ্ধ নেই',
    en: 'No transactions recorded',
  },
  addTransaction: {
    bn: 'নতুন লেনদেন যোগ করুন',
    en: 'Add Transaction',
  },
  income: {
    bn: 'আয়',
    en: 'Income',
  },
  expense: {
    bn: 'ব্যয়',
    en: 'Expense',
  },
  transfer: {
    bn: 'স্থানান্তর',
    en: 'Transfer',
  },
  amount: {
    bn: 'পরিমাণ (টাকা)',
    en: 'Amount',
  },
  category: {
    bn: 'ক্যাটাগরি',
    en: 'Category',
  },
  account: {
    bn: 'অ্যাকাউন্ট',
    en: 'Account',
  },
  paymentMethod: {
    bn: 'পেমেন্ট মাধ্যম',
    en: 'Payment Method',
  },
  date: {
    bn: 'তারিখ',
    en: 'Date',
  },
  time: {
    bn: 'সময়',
    en: 'Time',
  },
  note: {
    bn: 'বিবরণ বা নোট',
    en: 'Description / Note',
  },
  save: {
    bn: 'সংরক্ষণ করুন',
    en: 'Save',
  },
  update: {
    bn: 'আপডেট করুন',
    en: 'Update',
  },
  cancel: {
    bn: 'বাতিল',
    en: 'Cancel',
  },
  edit: {
    bn: 'সম্পাদনা',
    en: 'Edit',
  },
  delete: {
    bn: 'মুছুন',
    en: 'Delete',
  },
  cashMemo: {
    bn: 'ক্যাশ মেমো',
    en: 'Cash Memo',
  },
  calculator: {
    bn: 'ক্যালকুলেটর',
    en: 'Calculator',
  },
  voucherAttach: {
    bn: 'মেমো / ভাউচারের ছবি যুক্ত করুন',
    en: 'Attach Voucher / Receipt Photo',
  },
  voucherAttached: {
    bn: 'সংযুক্ত ভাউচার',
    en: 'Attached Voucher',
  },
  viewVoucher: {
    bn: 'ভাউচার দেখুন',
    en: 'View Voucher',
  },
  removeVoucher: {
    bn: 'ভাউচার সরান',
    en: 'Remove Voucher',
  },

  // Persons / Debts
  personsTitle: {
    bn: 'দেনা ও পাওনার হিসাব',
    en: 'Borrow & Lend Ledger',
  },
  receivable: {
    bn: 'পাবো',
    en: 'Receivable (I will get)',
  },
  payable: {
    bn: 'দিবো',
    en: 'Payable (I have to pay)',
  },
  addPerson: {
    bn: 'নতুন ব্যক্তি যোগ করুন',
    en: 'Add Person',
  },
  name: {
    bn: 'নাম',
    en: 'Name',
  },
  phoneNumber: {
    bn: 'ফোন নম্বর',
    en: 'Phone Number',
  },
  sendReminder: {
    bn: 'তাগাদা বার্তা',
    en: 'Send Reminder',
  },
  copyReminderText: {
    bn: 'বার্তা কপি',
    en: 'Copy Text',
  },
  whatsapp: {
    bn: 'WhatsApp',
    en: 'WhatsApp',
  },
  sms: {
    bn: 'SMS',
    en: 'SMS',
  },
  call: {
    bn: 'কল করুন',
    en: 'Call',
  },
  settle: {
    bn: 'পরিশোধ সম্পন্ন',
    en: 'Mark Settled',
  },
  totalReceivable: {
    bn: 'মোট পাওনা',
    en: 'Total Receivable',
  },
  totalPayable: {
    bn: 'মোট দেনা',
    en: 'Total Payable',
  },
  totalPersons: {
    bn: 'মোট ব্যক্তি',
    en: 'Total Persons',
  },

  // Budget
  monthlyBudgetLimit: {
    bn: 'মাসিক মোট বাজেট লিমিট',
    en: 'Monthly Budget Limit',
  },
  spent: {
    bn: 'ব্যয় হয়েছে',
    en: 'Spent',
  },
  remaining: {
    bn: 'অবশিষ্ট',
    en: 'Remaining',
  },
  addCategoryBudget: {
    bn: 'ক্যাটাগরি অনুযায়ী বাজেট যোগ',
    en: 'Add Category Budget',
  },

  // Savings
  savingsGoals: {
    bn: 'সঞ্চয় লক্ষ্যমাত্রা ও তহবিল',
    en: 'Savings Goals & Funds',
  },
  targetAmount: {
    bn: 'টার্গেট পরিমাণ',
    en: 'Target Amount',
  },
  savedAmount: {
    bn: 'জমাকৃত টাকা',
    en: 'Saved So Far',
  },
  addGoal: {
    bn: 'নতুন সঞ্চয় লক্ষ্য যোগ করুন',
    en: 'Add New Goal',
  },
  depositMoney: {
    bn: 'টাকা জমা দিন',
    en: 'Deposit Money',
  },

  // Tasks
  checklist: {
    bn: 'টাস্ক ও কেনাকাটার তালিকা',
    en: 'Tasks & Checklist',
  },
  addTask: {
    bn: 'নতুন টাস্ক যোগ করুন',
    en: 'Add Task',
  },
  allTasks: {
    bn: 'সকল টাস্ক',
    en: 'All Tasks',
  },
  pendingTasks: {
    bn: 'বাকি আছে',
    en: 'Pending',
  },
  completedTasks: {
    bn: 'সম্পন্ন',
    en: 'Completed',
  },

  // Settings
  language: {
    bn: 'অ্যাপের ভাষা',
    en: 'App Language',
  },
  bangla: {
    bn: 'বাংলা',
    en: 'Bengali',
  },
  english: {
    bn: 'English',
    en: 'English',
  },
  banglaNumerals: {
    bn: 'বাংলা সংখ্যা প্রদর্শন (১২৩৪৫)',
    en: 'Bangla Numerals (১২৩৪৫)',
  },
  banglaNumeralsDesc: {
    bn: 'টাকার অংক এবং তারিখে বাংলা সংখ্যা দেখাবে',
    en: 'Display amounts and dates using Bengali digits',
  },
  privacyMode: {
    bn: 'প্রাইভেসি মোড (টাকা গোপন)',
    en: 'Privacy Mode (Hide Amount)',
  },
  privacyModeDesc: {
    bn: 'হোম স্ক্রিনে ব্যালেন্স ও টাকার অংক মাস্ক থাকবে',
    en: 'Mask amounts on home screen with dots',
  },
  appPinLock: {
    bn: 'অ্যাপ পিন লক (PIN Security)',
    en: 'App PIN Security Lock',
  },
  themeAppearance: {
    bn: 'থিম ও প্রদর্শন (Theme)',
    en: 'Theme & Appearance',
  },
  lightModeDesc: {
    bn: 'উজ্জ্বল ব্যাকগ্রাউন্ড',
    en: 'Clean bright layout',
  },
  darkModeDesc: {
    bn: 'চোখের জন্য আরামদায়ক ডার্ক থিম',
    en: 'Comfortable dark colors',
  },
  systemThemeDesc: {
    bn: 'ডিভাইসের সিস্টেম থিম অনুযায়ী',
    en: 'Follows device system setting',
  },
  cloudBackupSync: {
    bn: 'অনলাইন ক্লাউড ব্যাকআপ ও অটো-সিঙ্ক',
    en: 'Online Cloud Backup & Auto-Sync',
  },
  cloudActive: {
    bn: 'ফ্রি ক্লাউড ব্যাকআপ সক্রিয় রয়েছে',
    en: 'Free cloud backup is active',
  },
  cloudOffline: {
    bn: 'অফলাইন মোড (গুগল লগইন করুন)',
    en: 'Offline Mode (Sign in with Google)',
  },
  exportData: {
    bn: 'ডাটা এক্সপোর্ট (JSON ব্যাকআপ)',
    en: 'Export Data (JSON Backup)',
  },
  importData: {
    bn: 'ডাটা ইমপোর্ট (JSON রিস্টোর)',
    en: 'Import Data (JSON Restore)',
  },
  resetAll: {
    bn: 'সমস্ত ডাটা রিসেট',
    en: 'Reset All Data',
  },
  loadSample: {
    bn: 'নমুনা ডাটা লোড করুন',
    en: 'Load Sample Demo Data',
  },
  successSave: {
    bn: 'সফলভাবে সংরক্ষিত হয়েছে!',
    en: 'Saved successfully!',
  },
  profileSettings: {
    bn: 'প্রোফাইল সেটিংস',
    en: 'Profile Settings',
  },
  userName: {
    bn: 'ব্যবহারকারীর নাম',
    en: 'User Name',
  },
};

export type TranslationKey = keyof typeof translations;

export function t(key: TranslationKey, lang: AppLanguage = 'bn'): string {
  if (translations[key] && translations[key][lang]) {
    return translations[key][lang];
  }
  return String(key);
}

// Helper hook or function to easily get translated strings with fallback
export function getI18nText(isEn: boolean, bnText: string, enText: string): string {
  return isEn ? enText : bnText;
}
