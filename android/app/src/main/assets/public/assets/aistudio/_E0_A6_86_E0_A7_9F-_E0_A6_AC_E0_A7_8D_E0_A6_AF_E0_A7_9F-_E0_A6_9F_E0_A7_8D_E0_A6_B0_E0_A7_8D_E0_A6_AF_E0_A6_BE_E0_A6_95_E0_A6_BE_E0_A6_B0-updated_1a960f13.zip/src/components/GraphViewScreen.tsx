import React, { useState } from 'react';
import { ArrowLeft, Calendar } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatCurrency, toBanglaNumber, BANGLA_MONTHS } from '../utils/formatters';

export const GraphViewScreen: React.FC = () => {
  const {
    monthlyIncome,
    monthlyExpense,
    monthlyBalance,
    selectedMonth,
    selectedYear,
    setSelectedMonth,
    settings,
    setActiveTab,
  } = useApp();

  const isEn = settings.language === 'en';
  const [metricTab, setMetricTab] = useState<'income' | 'expense'>('income');
  const [showMonthModal, setShowMonthModal] = useState(false);

  const enShortMonths = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const currentMonthName = isEn
    ? enShortMonths[selectedMonth - 1]
    : BANGLA_MONTHS[selectedMonth - 1] || 'অক্টোবর';

  const shortMonths = isEn
    ? enShortMonths
    : ['জানু', 'ফেব্রু', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];

  const months5 = [
    { name: isEn ? 'May' : 'মে', inc: 35000, exp: 22000 },
    { name: isEn ? 'Jun' : 'জুন', inc: 42000, exp: 25000 },
    { name: isEn ? 'Jul' : 'জুলাই', inc: 38000, exp: 29000 },
    { name: isEn ? 'Aug' : 'আগস্ট', inc: 45000, exp: 26000 },
    { name: isEn ? 'Sep' : 'সেপ্টেম্বর', inc: 48000, exp: 31000 },
    { name: currentMonthName, inc: monthlyIncome, exp: monthlyExpense },
  ];

  return (
    <div className="space-y-4 pb-20 pt-1">
      {/* Header */}
      <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setActiveTab('dashboard')}
            className="p-1 rounded-full text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title={isEn ? 'Back' : 'পেছনে যান'}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="text-base font-bold text-slate-900 dark:text-white">
            {currentMonthName} {selectedYear}
          </h2>
        </div>
        <button
          onClick={() => setShowMonthModal(true)}
          className="p-1 text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
          title={isEn ? 'Change Month' : 'মাস পরিবর্তন'}
        >
          <Calendar className="w-5 h-5" />
        </button>
      </div>

      {/* Account Calendar */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-100 dark:border-slate-800 shadow-xs space-y-3">
        <h3 className="text-xs font-bold text-slate-800 dark:text-white">
          {isEn ? 'Expense Calendar' : 'হিসাব ক্যালেন্ডার'}
        </h3>

        <div className="grid grid-cols-7 gap-1.5 text-center text-[10px]">
          {Array.from({ length: 31 }, (_, i) => i + 1).map((day) => {
            const isToday = day === 15;
            return (
              <div
                key={day}
                className={`w-7 h-7 mx-auto rounded-full flex items-center justify-center font-medium transition-colors ${
                  isToday
                    ? 'bg-blue-600 text-white font-bold'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                }`}
              >
                {settings.useBanglaNumerals && !isEn ? toBanglaNumber(day) : day}
              </div>
            );
          })}
        </div>

        <div className="flex items-center gap-4 text-[10px] text-slate-500 dark:text-slate-400 pt-1">
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-blue-600" /> {isEn ? 'Recorded' : 'হিসাব আছে'}
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-slate-300 dark:bg-slate-700" /> {isEn ? 'No Entry' : 'হিসাব নেই'}
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-emerald-500" /> {isEn ? 'Today' : 'আজকে'}
          </span>
        </div>
      </div>

      {/* 3 Metric Cards */}
      <div className="grid grid-cols-3 gap-2 text-center text-xs">
        <div className="p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 block mb-0.5">
            {isEn ? 'Income' : 'মোট আয়'}
          </span>
          <span className="font-bold text-emerald-600 dark:text-emerald-400">
            {monthlyIncome > 0 ? formatCurrency(monthlyIncome, settings.useBanglaNumerals && !isEn) : '0'}
          </span>
        </div>

        <div className="p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-rose-500 dark:text-rose-400 block mb-0.5">
            {isEn ? 'Expense' : 'মোট ব্যয়'}
          </span>
          <span className="font-bold text-rose-500 dark:text-rose-400">
            {monthlyExpense > 0 ? formatCurrency(monthlyExpense, settings.useBanglaNumerals && !isEn) : '0'}
          </span>
        </div>

        <div className="p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-blue-600 dark:text-blue-400 block mb-0.5">
            {isEn ? 'Remaining' : 'অবশিষ্ট'}
          </span>
          <span className="font-bold text-blue-600 dark:text-blue-400">
            {monthlyBalance !== 0 ? formatCurrency(monthlyBalance, settings.useBanglaNumerals && !isEn) : '0'}
          </span>
        </div>
      </div>

      {/* [ Income ] vs [ Expense ] Switcher */}
      <div className="grid grid-cols-2 gap-2">
        <button
          onClick={() => setMetricTab('income')}
          className={`py-2 rounded-xl text-xs font-bold transition-all ${
            metricTab === 'income'
              ? 'bg-emerald-600 text-white'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
          }`}
        >
          {isEn ? 'Income' : 'আয়'}
        </button>
        <button
          onClick={() => setMetricTab('expense')}
          className={`py-2 rounded-xl text-xs font-bold transition-all ${
            metricTab === 'expense'
              ? 'bg-rose-500 text-white'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
          }`}
        >
          {isEn ? 'Expense' : 'ব্যয়'}
        </button>
      </div>

      {/* Monthly Trend (Past 5 Months) */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-100 dark:border-slate-800 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-slate-800 dark:text-white">
            {isEn ? 'Monthly Trend (Past 5 Months)' : 'মাসিক প্রবণতা (গত ৫ মাস)'}
          </h3>
          <div className="flex items-center gap-2 text-[10px]">
            <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-500" /> {isEn ? 'Income' : 'আয়'}
            </span>
            <span className="flex items-center gap-1 text-rose-500 dark:text-rose-400">
              <span className="w-2 h-2 rounded-full bg-rose-500" /> {isEn ? 'Expense' : 'ব্যয়'}
            </span>
          </div>
        </div>

        <div className="h-32 flex items-end justify-between gap-2 pt-4 border-b border-slate-100 dark:border-slate-800 pb-2">
          {months5.map((m) => {
            const incH = Math.max(6, Math.min(100, Math.round((m.inc / 50000) * 100)));
            const expH = Math.max(6, Math.min(100, Math.round((m.exp / 50000) * 100)));
            return (
              <div key={m.name} className="flex-1 flex flex-col items-center justify-end h-full">
                <div className="flex items-end gap-1">
                  <div className="w-2.5 bg-emerald-500 rounded-t-sm" style={{ height: `${incH}%` }} />
                  <div className="w-2.5 bg-rose-500 rounded-t-sm" style={{ height: `${expH}%` }} />
                </div>
                <span className="text-[10px] text-slate-400 mt-2">{m.name}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Month Selection Modal */}
      {showMonthModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-xs bg-white dark:bg-slate-900 rounded-3xl overflow-hidden shadow-2xl space-y-4 border border-slate-100 dark:border-slate-800 animate-in fade-in">
            <div className="bg-blue-600 text-white p-4">
              <span className="text-xs opacity-90">{currentMonthName} {selectedYear}</span>
              <h4 className="text-xl font-bold mt-0.5">{selectedYear}</h4>
            </div>

            <div className="p-4 pt-1 space-y-4">
              <div className="grid grid-cols-4 gap-2 text-center text-xs">
                {shortMonths.map((m, index) => {
                  const isSelected = selectedMonth === index + 1;
                  return (
                    <button
                      key={m}
                      onClick={() => {
                        setSelectedMonth(index + 1);
                        setShowMonthModal(false);
                      }}
                      className={`py-2 rounded-full font-medium transition-all ${
                        isSelected
                          ? 'bg-blue-600 text-white font-bold'
                          : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                      }`}
                    >
                      {m}
                    </button>
                  );
                })}
              </div>

              <div className="flex justify-end gap-3 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs font-bold text-blue-600 dark:text-blue-400">
                <button onClick={() => setShowMonthModal(false)}>
                  {isEn ? 'Cancel' : 'বাতিল করুন'}
                </button>
                <button onClick={() => setShowMonthModal(false)}>
                  {isEn ? 'OK' : 'ঠিক আছে'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
