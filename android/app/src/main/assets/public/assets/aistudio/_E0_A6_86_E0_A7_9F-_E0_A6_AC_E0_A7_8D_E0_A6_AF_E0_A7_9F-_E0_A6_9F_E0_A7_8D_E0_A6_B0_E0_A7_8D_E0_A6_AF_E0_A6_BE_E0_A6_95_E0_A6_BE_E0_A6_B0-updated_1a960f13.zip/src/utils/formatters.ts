import { Category, Account, Transaction } from '../types';

const BANGLA_NUMBERS = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];

export const toBanglaNumber = (num: number | string): string => {
  return String(num).replace(/[0-9]/g, (digit) => BANGLA_NUMBERS[parseInt(digit, 10)]);
};

export const formatCurrency = (
  amount: number,
  useBangla = true,
  currency = '৳'
): string => {
  const rounded = Math.round(amount);
  const formatted = new Intl.NumberFormat('en-IN').format(Math.abs(rounded));
  const finalNum = useBangla ? toBanglaNumber(formatted) : formatted;
  const sign = amount < 0 ? '-' : '';
  return `${sign}${currency} ${finalNum}`;
};

export const BANGLA_MONTHS = [
  'জানুয়ারি',
  'ফেব্রুয়ারি',
  'মার্চ',
  'এপ্রিল',
  'মে',
  'জুন',
  'জুলাই',
  'আগস্ট',
  'সেপ্টেম্বর',
  'অক্টোবর',
  'নভেম্বর',
  'ডিসেম্বর',
];

export const BANGLA_WEEKDAYS = [
  'রবিবার',
  'সোমবার',
  'মঙ্গলবার',
  'বুধবার',
  'বৃহস্পতিবার',
  'শুক্রবার',
  'শনিবার',
];

export const formatBengaliDate = (
  dateStr: string,
  useBangla = true,
  includeDay = false
): string => {
  try {
    const [year, month, day] = dateStr.split('-').map(Number);
    const dateObj = new Date(year, month - 1, day);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const checkDate = new Date(year, month - 1, day);
    checkDate.setHours(0, 0, 0, 0);

    const diffDays = Math.round((today.getTime() - checkDate.getTime()) / (1000 * 60 * 60 * 24));

    if (diffDays === 0) return useBangla ? 'আজ' : 'Today';
    if (diffDays === 1) return useBangla ? 'গতকাল' : 'Yesterday';
    if (diffDays === -1) return useBangla ? 'আগামীকাল' : 'Tomorrow';

    const monthName = useBangla
      ? BANGLA_MONTHS[month - 1]
      : dateObj.toLocaleString('default', { month: 'short' });
    const dayStr = useBangla ? toBanglaNumber(day) : String(day);
    const yearStr = useBangla ? toBanglaNumber(year) : String(year);

    if (includeDay) {
      const weekdayName = useBangla
        ? BANGLA_WEEKDAYS[dateObj.getDay()]
        : dateObj.toLocaleString('default', { weekday: 'short' });
      return `${weekdayName}, ${dayStr} ${monthName} ${yearStr}`;
    }

    return `${dayStr} ${monthName} ${yearStr}`;
  } catch {
    return dateStr;
  }
};

export const formatMonthYear = (year: number, month: number, useBangla = true): string => {
  const monthName = useBangla ? BANGLA_MONTHS[month - 1] : new Date(year, month - 1).toLocaleString('default', { month: 'long' });
  const yearStr = useBangla ? toBanglaNumber(year) : String(year);
  return `${monthName} ${yearStr}`;
};

export const getTodayString = (): string => {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

export const getCurrentTimeString = (): string => {
  const now = new Date();
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  return `${hours}:${minutes}`;
};

export const DEFAULT_EXPENSE_CATEGORIES: Category[] = [
  { id: 'cat_food', name: 'খাবার ও রেস্তোরাঁ', nameEn: 'Food & Dining', type: 'expense', icon: 'Utensils', color: '#f97316' },
  { id: 'cat_groceries', name: 'মুদি ও কাঁচাবাজার', nameEn: 'Groceries & Market', type: 'expense', icon: 'ShoppingBasket', color: '#10b981' },
  { id: 'cat_rent', name: 'বাড়ি ভাড়া ও আবাসন', nameEn: 'House Rent', type: 'expense', icon: 'Home', color: '#6366f1' },
  { id: 'cat_transport', name: 'যাতায়াত ও জ্বালানি', nameEn: 'Transport & Fuel', type: 'expense', icon: 'Car', color: '#3b82f6' },
  { id: 'cat_utilities', name: 'বিদ্যুৎ ও পানি বিল', nameEn: 'Utility Bills', type: 'expense', icon: 'Zap', color: '#eab308' },
  { id: 'cat_mobile', name: 'মোবাইল ও ইন্টারনেট', nameEn: 'Mobile & Internet', type: 'expense', icon: 'Wifi', color: '#06b6d4' },
  { id: 'cat_medical', name: 'চিকিৎসা ও ঔষধ', nameEn: 'Medical & Healthcare', type: 'expense', icon: 'HeartPulse', color: '#ef4444' },
  { id: 'cat_shopping', name: 'পোশাক ও কেনাকাটা', nameEn: 'Shopping & Clothes', type: 'expense', icon: 'ShoppingBag', color: '#ec4899' },
  { id: 'cat_education', name: 'শিক্ষা ও বই-খাতা', nameEn: 'Education', type: 'expense', icon: 'GraduationCap', color: '#8b5cf6' },
  { id: 'cat_entertainment', name: 'বিনোদন ও ঘোরাঘুরি', nameEn: 'Entertainment', type: 'expense', icon: 'Film', color: '#14b8a6' },
  { id: 'cat_charity', name: 'দান-সদকা ও উপহার', nameEn: 'Donation & Charity', type: 'expense', icon: 'Gift', color: '#f43f5e' },
  { id: 'cat_debt_paid', name: 'ঋণ বা ধার পরিশোধ', nameEn: 'Debt Repayment', type: 'expense', icon: 'HandCoins', color: '#64748b' },
  { id: 'cat_other_exp', name: 'অন্যান্য খরচ', nameEn: 'Other Expenses', type: 'expense', icon: 'MoreHorizontal', color: '#94a3b8' },
];

export const DEFAULT_INCOME_CATEGORIES: Category[] = [
  { id: 'cat_salary', name: 'মাসিক বেতন', nameEn: 'Salary', type: 'income', icon: 'Briefcase', color: '#10b981' },
  { id: 'cat_business', name: 'ব্যবসা ও মুনাফা', nameEn: 'Business Profit', type: 'income', icon: 'Building2', color: '#2563eb' },
  { id: 'cat_freelance', name: 'ফ্রিল্যান্সিং', nameEn: 'Freelance & Projects', type: 'income', icon: 'Laptop', color: '#06b6d4' },
  { id: 'cat_rental_inc', name: 'বাড়ি/দোকান ভাড়া আয়', nameEn: 'Rent Income', type: 'income', icon: 'Store', color: '#8b5cf6' },
  { id: 'cat_investment', name: 'বিনিয়োগ ও লভ্যাংশ', nameEn: 'Investment Returns', type: 'income', icon: 'TrendingUp', color: '#f59e0b' },
  { id: 'cat_gift_inc', name: 'উপহার ও বোনাস', nameEn: 'Gift & Bonus', type: 'income', icon: 'PartyPopper', color: '#ec4899' },
  { id: 'cat_borrow_in', name: 'ধার বা ঋণ গ্রহণ', nameEn: 'Loan Received', type: 'income', icon: 'HandCoins', color: '#64748b' },
  { id: 'cat_other_inc', name: 'অন্যান্য আয়', nameEn: 'Other Income', type: 'income', icon: 'PlusCircle', color: '#10b981' },
];

export const DEFAULT_ACCOUNTS: Account[] = [
  { id: 'acc_cash', name: 'নগদ ক্যাশ (টাকা)', type: 'cash', initialBalance: 0, currentBalance: 0, color: '#10b981', icon: 'Wallet' },
  { id: 'acc_bkash', name: 'বিকাশ (bKash)', type: 'mobile_wallet', initialBalance: 0, currentBalance: 0, color: '#e2136e', icon: 'Smartphone' },
  { id: 'acc_nagad', name: 'নগদ ওয়ালেট (Nagad)', type: 'mobile_wallet', initialBalance: 0, currentBalance: 0, color: '#f37023', icon: 'Smartphone' },
  { id: 'acc_bank', name: 'ব্যাংক অ্যাকাউন্ট', type: 'bank', initialBalance: 0, currentBalance: 0, color: '#2563eb', icon: 'Landmark' },
];

export const generateSampleTransactions = (): Transaction[] => {
  const today = getTodayString();
  const parts = today.split('-').map(Number);
  const curYear = parts[0];
  const curMonth = String(parts[1]).padStart(2, '0');

  const d1 = `${curYear}-${curMonth}-14`;
  const d2 = `${curYear}-${curMonth}-12`;
  const d3 = `${curYear}-${curMonth}-08`;
  const d4 = `${curYear}-${curMonth}-05`;
  const d5 = `${curYear}-${curMonth}-01`;

  return [
    {
      id: 'tx_today',
      type: 'expense',
      amount: 500,
      categoryId: 'cat_vh',
      categoryName: 'ব্যয়',
      categoryIcon: 'Tag',
      categoryColor: '#ef4444',
      accountId: 'acc_cash',
      accountName: 'নগদ ক্যাশ (টাকা)',
      date: today,
      time: '11:09 AM',
      note: 'ব্যয়',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'tx_1',
      type: 'income',
      amount: 45000,
      categoryId: 'cat_salary',
      categoryName: 'মাসিক বেতন',
      categoryIcon: 'Briefcase',
      categoryColor: '#10b981',
      accountId: 'acc_bank',
      accountName: 'ব্যাংক অ্যাকাউন্ট',
      date: d5,
      time: '10:00',
      note: 'অক্টোবর মাসের মূল বেতন',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'tx_2',
      type: 'expense',
      amount: 15000,
      categoryId: 'cat_rent',
      categoryName: 'বাড়ি ভাড়া ও আবাসন',
      categoryIcon: 'Home',
      categoryColor: '#6366f1',
      accountId: 'acc_bank',
      accountName: 'ব্যাংক অ্যাকাউন্ট',
      date: d4,
      time: '11:30',
      note: 'বাসার মাসিক ভাড়া পরিশোধ',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'tx_3',
      type: 'expense',
      amount: 3250,
      categoryId: 'cat_groceries',
      categoryName: 'মুদি ও কাঁচাবাজার',
      categoryIcon: 'ShoppingBasket',
      categoryColor: '#10b981',
      accountId: 'acc_cash',
      accountName: 'নগদ ক্যাশ (টাকা)',
      date: d3,
      time: '08:45',
      note: 'সাপ্তাহিক মাছ ও শাকসবজির বাজার',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'tx_4',
      type: 'income',
      amount: 12000,
      categoryId: 'cat_freelance',
      categoryName: 'ফ্রিল্যান্সিং',
      categoryIcon: 'Laptop',
      categoryColor: '#06b6d4',
      accountId: 'acc_bkash',
      accountName: 'বিকাশ (bKash)',
      date: d2,
      time: '16:20',
      note: 'ওয়েবসাইট ডিজাইন প্রজেক্ট পেমেন্ট',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'tx_5',
      type: 'expense',
      amount: 850,
      categoryId: 'cat_utilities',
      categoryName: 'বিদ্যুৎ ও পানি বিল',
      categoryIcon: 'Zap',
      categoryColor: '#eab308',
      accountId: 'acc_bkash',
      accountName: 'বিকাশ (bKash)',
      date: d2,
      time: '19:10',
      note: 'ডেসকো বিদ্যুৎ প্রিপেইড মিটার রিচার্জ',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'tx_6',
      type: 'expense',
      amount: 450,
      categoryId: 'cat_food',
      categoryName: 'খাবার ও রেস্তোরাঁ',
      categoryIcon: 'Utensils',
      categoryColor: '#f97316',
      accountId: 'acc_cash',
      accountName: 'নগদ ক্যাশ (টাকা)',
      date: d1,
      time: '14:15',
      note: 'দুপুরের খাবার ও চা-নাস্তা',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'tx_7',
      type: 'expense',
      amount: 180,
      categoryId: 'cat_transport',
      categoryName: 'যাতায়াত ও জ্বালানি',
      categoryIcon: 'Car',
      categoryColor: '#3b82f6',
      accountId: 'acc_cash',
      accountName: 'নগদ ক্যাশ (টাকা)',
      date: today,
      time: '09:30',
      note: 'অফিস যাওয়ার সিএনজি ও রিকশা ভাড়া',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'tx_8',
      type: 'expense',
      amount: 600,
      categoryId: 'cat_mobile',
      categoryName: 'মোবাইল ও ইন্টারনেট',
      categoryIcon: 'Wifi',
      categoryColor: '#06b6d4',
      accountId: 'acc_bkash',
      accountName: 'বিকাশ (bKash)',
      date: today,
      time: '11:00',
      note: 'ওয়াইফাই মাসিক ব্রডব্যান্ড বিল',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
  ];
};
